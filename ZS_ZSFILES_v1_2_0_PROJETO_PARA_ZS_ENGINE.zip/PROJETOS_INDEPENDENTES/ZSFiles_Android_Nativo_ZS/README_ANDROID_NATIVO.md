# Projeto Android nativo na ZS.ENGINE

Abra `project.zeproj` na ZS.ENGINE STUDIO. Use Android Nativo para diagnosticar, compilar e instalar com Gradle/ADB.

O codigo Kotlin/Java permanece em `android_source/` e nao e interpretado pelo runtime 2D/3D da ZS.ENGINE.
A cena inicial e apenas um espaco de trabalho ZS. Compilacao Android requer Android SDK, JDK e Gradle.
