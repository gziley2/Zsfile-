@echo off
setlocal
set "GRADLE_VERSION=8.9"
set "GRADLE_HOME=%USERPROFILE%\.gradle\zs-gradle-%GRADLE_VERSION%"
set "ZIP=%TEMP%\gradle-%GRADLE_VERSION%-bin.zip"
if not exist "%GRADLE_HOME%\gradle-%GRADLE_VERSION%\bin\gradle.bat" (
  echo Baixando Gradle %GRADLE_VERSION%...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP%'"
  if errorlevel 1 exit /b 1
  mkdir "%GRADLE_HOME%" 2>nul
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Path '%ZIP%' -DestinationPath '%GRADLE_HOME%' -Force"
)
call "%GRADLE_HOME%\gradle-%GRADLE_VERSION%\bin\gradle.bat" %*
endlocal
