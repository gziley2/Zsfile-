# ZS Files (v1.1.0)

Gerenciador de arquivos + editor de código (Kotlin / Jetpack Compose).

## Como abrir
1. Extraia o ZIP e abra a pasta `ZSFiles` no Android Studio (File > Open).
2. Aguarde o Gradle Sync terminar.
3. Run no celular/emulador. No primeiro uso, conceda "acesso a todos os arquivos".

## Já funciona
- Navegar pastas, criar pasta/arquivo, renomear, copiar, cortar/colar, excluir
- Compactar em ZIP e extrair ZIP/JAR/APK/AAR
- Editor com abas, realce de sintaxe (Kotlin, Java, JS, Python, XML, JSON...), números de linha,
  desfazer/refazer, buscar/substituir, barra de símbolos { } ( ) ; etc.

- Prévia de layout XML (arquivos em res/layout*): abra o arquivo e use o botão 👁 para alternar
  entre só prévia / só código / dividido. Atualiza enquanto você digita.
  Suporta LinearLayout, FrameLayout, RelativeLayout, ConstraintLayout, ScrollView, CardView,
  TextView, Button, EditText, ImageView, CheckBox, Switch etc., <include>, cores/strings/dimens do
  projeto, shapes e imagens PNG/JPG de res/drawable.

## Análise com IA (etapa 4)
- Gerenciador: selecione UM item (arquivo ou pasta) > ⋮ > "Analisar com IA".
- Editor: ⋮ > "Analisar com IA" (usa o texto atual, mesmo sem salvar).
- O app extrai o contexto localmente e envia para a API da Anthropic:
  - APK/JAR/ZIP: manifest decodificado (permissões, componentes), classes do DEX, pacotes,
    indicadores de comportamento (execução de comandos, carga dinâmica, cripto, SMS...), URLs/IPs/chaves,
    libs nativas (.so: funções JNI), assets suspeitos, certificado de assinatura, SHA-256.
  - Binários (ELF/DEX/outros): hash, entropia, cabeçalho, strings, URLs, funções sensíveis.
  - Texto/código: o próprio conteúdo. Pastas: estrutura + manifest + build.gradle.
- Toque em ⚙, escolha **Gemini** ou **Claude** e informe sua chave de API (fica só no aparelho).
  Modelo padrão do Gemini: gemini-2.5-flash (dá para trocar, ex.: gemini-3.5-flash). Chave grátis: aistudio.google.com
- 📋 mostra o contexto extraído (funciona sem internet). 💾 salva a conversa em .md ao lado do arquivo.

## Visualizador hexadecimal
- Toque em qualquer arquivo binário (ou selecione > ⋮ > "Abrir no hex"). Offset | bytes | ASCII,
  barra de rolagem rápida, buscar texto ou bytes (🔍) e ir para offset (#). Somente leitura; até 2 GB.

## Versão profissional (v1.1.0)
- Navegação por abas: Arquivos, Editor, Ferramentas e Ajustes. Tema claro/escuro/do sistema e ícone próprio do app.
- Ícones de verdade (Material) no lugar de emojis; ícones coloridos por tipo de arquivo.
- Gerenciador: busca na pasta, arquivos ocultos (desligado por padrão), ordenação por nome/data/tamanho e atalhos
  (Download, DCIM, Documents, Pictures, Movies, Music).
- Ajustes: IA (Gemini/Claude), aparência, arquivos, sobre e ajuda. Ferramentas: extrator de APK, hex e análise com IA com seletor de arquivo.
- IA: tentativas automáticas em erros temporários do Google (503 alta demanda, 429) com mensagem clara se persistir.

## Modelo do Gemini (v1.0.3)
- O padrão agora é `gemini-flash-latest` (o Flash mais novo), porque modelos como o gemini-2.5-flash são desligados.
- Em Configurar IA > Gemini, "Buscar modelos" lista os modelos disponíveis para a sua chave; toque em um para usar.
- Se o modelo não existir mais, o erro já diz o que fazer.

## Configurações e ajuda (v1.0.2)
- Menu ⋮ da tela inicial: "Configurar IA (chave da API)" (Gemini ou Claude) e "Ajuda".
- "Novo arquivo" agora já abre o arquivo no editor.

## Recursos do APK (v1.0)
- A decompilação agora também gera `res/`: todos os XMLs binários (layouts, menus, drawables xml) viram XML legível,
  com nomes de recursos (@string/..., @id/..., @color/...) resolvidos a partir do `resources.arsc`.
- Gera `res/values/` (strings, colors, dimens, integers, bools, ids). Layouts decodificados abrem na prévia de layout.
- Modo "Tudo" também copia assets e imagens/binários de res/ (limite de 200 MB). "Só app" decodifica só os XMLs e os values.
- Smali: abra um `.smali` no editor ou selecione no gerenciador e use "Converter para Java (IA)".
- Limites: styles/arrays/plurals não são recriados em values; o config padrão é usado quando há várias traduções/densidades.

## Decompilação (DEX/APK -> smali) e engenharia reversa
- Selecionar um .apk ou .dex > ⋮ > "Decompilar (smali)": gera uma pasta `<nome>_decompilado` com `smali/` (e `smali_classesN/`),
  `AndroidManifest.xml` decodificado e `assets/`. "Só app" ignora bibliotecas conhecidas; "Tudo" inclui tudo.
- É smali (assembly do Dalvik), não Java: é exato e a IA sabe lê-lo e reescrevê-lo como Java/Kotlin legível.
- Na análise com IA de um APK/DEX, o botão "Decompilar e incluir código (smali)" acrescenta ao contexto as classes mais relevantes:
  Application > Activity LAUNCHER > componentes do manifest > classes com indicadores (cripto, rede, execução, SMS, WebView...).
  O topo do código decompilado lista o que foi enviado e as classes importantes que ficaram de fora.
- Também funciona decompilar primeiro e depois analisar a pasta gerada (smali + manifest + assets).

## Análise de pasta de projeto (código + assets)
- Selecionar uma pasta > ⋮ > "Analisar com IA" agora envia: estrutura, **código-fonte** (manifest e gradle primeiro,
  depois .kt/.java/etc.), layouts/values, e os **assets** (lista, tipo e entropia dos binários, conteúdo dos de texto).
- Pastas build/.git/.gradle/node_modules são ignoradas. O topo do contexto (📋) mostra o que foi incluído e o que ficou de fora.
- Limite do contexto: 350 mil caracteres com Gemini, 120 mil com Claude. APK/ZIP também mostram os assets.

## Extrator de APK
- Menu ⋮ da tela inicial > "Extrator de APK": lista os apps instalados (com busca e filtro de apps do sistema).
- Toque num app > Extrair: copia o APK para `/ZSFiles_APKs`. Apps com splits viram um `.apks` (base + splits).
- "Extrair + IA" já abre a análise do APK extraído. Precisa da permissão QUERY_ALL_PACKAGES (já no manifest).

## Formatos de arquivo
- Extrair: ZIP/JAR/APK/AAR, **7z**, **RAR** (RAR4; RAR5 ainda não), TAR, TAR.GZ/TGZ, TAR.BZ2, TAR.XZ, GZ, BZ2, XZ.
- Compactar: apenas ZIP. Análise com IA lista o conteúdo de 7z e TAR sem extrair.
- minSdk passou para 26 (Android 8.0) por causa das bibliotecas de compactação.

## Próximas etapas
- Criar 7z, RAR5
- Decompilação (jadx)

## Assistente de projeto (v1.2.0)
- Ferramentas > Assistente de projeto (IA), ou selecione uma pasta > ⋮ > Assistente de projeto (IA).
- Agente com ferramentas (listar, ler, buscar, editar, criar) sobre a pasta real do projeto; funciona com Gemini ou Claude.
- Cópia automática de cada arquivo antes da primeira alteração; diff por linha, reverter por arquivo, desfazer/aceitar tudo.
- `ZS_INSTRUCOES.md` na pasta do projeto: instruções lidas pela IA a cada pedido (ícone (i) na tela do assistente).
- Corrigir erro do log, modo "Planejar antes", conversa salva por projeto, imagem anexada, cancelar.
- Limites: não apaga arquivos; só edita texto de até 1 MB; ignora build/.git/.gradle/node_modules/zs_build_reports.
- Chave de API criptografada com o Android Keystore.
- Arquivos: ProjectAgent.kt (motor), AgentScreen.kt (tela), SecureStore.kt (chave).
