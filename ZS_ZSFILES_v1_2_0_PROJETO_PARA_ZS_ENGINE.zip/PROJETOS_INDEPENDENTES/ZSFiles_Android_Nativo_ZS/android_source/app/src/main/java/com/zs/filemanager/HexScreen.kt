@file:OptIn(ExperimentalMaterial3Api::class)

package com.zs.filemanager

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.Closeable
import java.io.File
import java.io.RandomAccessFile
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

/** Acesso aleatório de leitura via mapeamento de memória (arquivos de até 2 GB). */
class HexSource(file: File) : Closeable {
    private val raf = RandomAccessFile(file, "r")
    val size: Long = raf.length()
    private val buf: MappedByteBuffer? =
        if (size in 1..Int.MAX_VALUE.toLong()) raf.channel.map(FileChannel.MapMode.READ_ONLY, 0, size) else null

    val ok: Boolean get() = buf != null

    fun read(offset: Long, len: Int): ByteArray {
        val b = buf ?: return ByteArray(0)
        val n = minOf(len.toLong(), size - offset).toInt()
        if (n <= 0) return ByteArray(0)
        val out = ByteArray(n)
        val d = b.duplicate()
        d.position(offset.toInt())
        d.get(out)
        return out
    }

    /** Primeira posição >= from onde o padrão aparece, ou -1. */
    fun find(p: ByteArray, from: Long): Long {
        val b = buf ?: return -1
        if (p.isEmpty()) return -1
        val last = (size - p.size).toInt()
        var i = from.toInt().coerceAtLeast(0)
        val first = p[0]
        while (i <= last) {
            if (b.get(i) == first) {
                var j = 1
                while (j < p.size && b.get(i + j) == p[j]) j++
                if (j == p.size) return i.toLong()
            }
            i++
        }
        return -1
    }

    override fun close() {
        raf.close()
    }
}

private fun parseHex(s: String): ByteArray? {
    val h = s.replace("0x", "", ignoreCase = true).filter { !it.isWhitespace() && it != ',' }
    if (h.isEmpty() || h.length % 2 != 0) return null
    if (!h.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' }) return null
    return ByteArray(h.length / 2) { h.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
}

@Composable
private fun HexRow(src: HexSource, row: Int, bpr: Int, hit: LongRange?) {
    val off = row.toLong() * bpr
    val line = remember(src, row, bpr) {
        val bytes = src.read(off, bpr)
        val sb = StringBuilder()
        sb.append(String.format("%08X  ", off))
        for (i in 0 until bpr) {
            if (i < bytes.size) sb.append(String.format("%02X ", bytes[i])) else sb.append("   ")
        }
        sb.append(' ')
        for (b in bytes) {
            val c = b.toInt() and 0xFF
            sb.append(if (c in 32..126) c.toChar() else '.')
        }
        sb.toString()
    }
    val inHit = hit != null && hit.first < off + bpr && hit.last >= off
    Text(
        line,
        fontFamily = FontFamily.Monospace,
        fontSize = 12.sp,
        softWrap = false,
        maxLines = 1,
        modifier = Modifier.fillMaxWidth()
            .background(if (inHit) Color(0x55FFEB3B) else Color.Transparent)
            .padding(horizontal = 8.dp, vertical = 1.dp)
    )
}

@Composable
fun HexScreen(file: File, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val src = remember(file) { try { HexSource(file) } catch (e: Exception) { null } }
    DisposableEffect(src) { onDispose { src?.close() } }

    val bpr = if (LocalConfiguration.current.screenWidthDp >= 560) 16 else 8
    val rows = if (src != null && src.ok) ((src.size + bpr - 1) / bpr).toInt() else 0
    val listState = rememberLazyListState()
    var hit by remember { mutableStateOf<LongRange?>(null) }
    var showFind by remember { mutableStateOf(false) }
    var showGoto by remember { mutableStateOf(false) }

    fun toast(m: String) = Toast.makeText(context, m, Toast.LENGTH_SHORT).show()
    fun jumpTo(offset: Long) {
        scope.launch { listState.scrollToItem((offset / bpr).toInt().coerceIn(0, maxOf(rows - 1, 0))) }
    }

    fun doFind(q: String, hex: Boolean) {
        val s = src ?: return
        val pattern: ByteArray? =
            if (hex) parseHex(q) else q.toByteArray(Charsets.UTF_8).takeIf { it.isNotEmpty() }
        if (pattern == null) {
            toast("Padrão inválido")
            return
        }
        val h = hit
        val from: Long = if (h != null) h.first + 1 else listState.firstVisibleItemIndex.toLong() * bpr
        scope.launch {
            val r = withContext(Dispatchers.Default) {
                val a = s.find(pattern, from)
                if (a < 0) s.find(pattern, 0) else a
            }
            if (r < 0) {
                toast("Não encontrado")
                hit = null
            } else {
                hit = r until r + pattern.size
                jumpTo(r)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Hex", fontSize = 16.sp)
                        Text(
                            file.name + " · " + FileUtils.readableSize(file.length()),
                            fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = { IconButton(onClick = onBack) { Icon(ZIcons.Back, contentDescription = "Voltar") } },
                actions = {
                    IconButton(onClick = { showFind = true }) { Icon(ZIcons.Search, contentDescription = "Buscar") }
                    IconButton(onClick = { showGoto = true }) { Text("#", fontSize = 18.sp) }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            if (src == null || !src.ok) {
                Text(
                    if (src != null && src.size == 0L) "Arquivo vazio."
                    else "Não foi possível abrir (arquivos acima de 2 GB não são suportados).",
                    Modifier.padding(16.dp)
                )
            } else {
                val first = listState.firstVisibleItemIndex
                Text(
                    "Offset 0x%X (%d) · linha %d/%d".format(first.toLong() * bpr, first.toLong() * bpr, first + 1, rows),
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
                LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState) {
                    items(rows) { r -> HexRow(src, r, bpr, hit) }
                }
                val pos = (first.toFloat() / maxOf(rows - 1, 1)).coerceIn(0f, 1f)
                Slider(
                    value = pos,
                    onValueChange = { v ->
                        scope.launch { listState.scrollToItem((v * (rows - 1)).toInt().coerceAtLeast(0)) }
                    },
                    modifier = Modifier.padding(horizontal = 8.dp)
                )
            }
        }
    }

    if (showFind) {
        var q by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showFind = false },
            title = { Text("Buscar") },
            text = {
                OutlinedTextField(
                    q, { q = it }, singleLine = true,
                    label = { Text("Texto ou bytes (ex.: 7F 45 4C 46)") }
                )
            },
            confirmButton = {
                Row {
                    TextButton(onClick = { showFind = false; doFind(q, false) }) { Text("Texto") }
                    TextButton(onClick = { showFind = false; doFind(q, true) }) { Text("Hex") }
                }
            },
            dismissButton = { TextButton(onClick = { showFind = false }) { Text("Fechar") } }
        )
    }

    if (showGoto) {
        var g by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showGoto = false },
            title = { Text("Ir para offset") },
            text = {
                OutlinedTextField(
                    g, { g = it }, singleLine = true,
                    label = { Text("Decimal ou 0x...") }
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val t = g.trim()
                    val v = if (t.startsWith("0x", ignoreCase = true)) t.substring(2).toLongOrNull(16) else t.toLongOrNull()
                    showGoto = false
                    if (v == null) toast("Offset inválido") else jumpTo(v)
                }) { Text("Ir") }
            },
            dismissButton = { TextButton(onClick = { showGoto = false }) { Text("Cancelar") } }
        )
    }
}
