package com.zs.filemanager

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay
import java.io.File

@Composable
fun LayoutPreviewPane(file: File, xml: String, modifier: Modifier = Modifier) {
    val res = remember(file.absolutePath) { ProjectRes(LayoutPreview.findResDir(file)) }
    var shown by remember { mutableStateOf(xml) }
    LaunchedEffect(xml) {
        delay(400)
        shown = xml
    }
    AndroidView(
        modifier = modifier.fillMaxWidth(),
        factory = { c -> LayoutPreview.createRoot(c) },
        update = { root -> LayoutPreview.render(root, shown, file, res) }
    )
}
