@file:OptIn(ExperimentalMaterial3Api::class)

package com.zs.filemanager

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class AppItem(
    val label: String,
    val pkg: String,
    val versionName: String?,
    val versionCode: Long,
    val sourceDir: String,
    val splits: List<String>,
    val isSystem: Boolean
)

@Suppress("DEPRECATION")
private fun loadApps(pm: PackageManager): List<AppItem> =
    pm.getInstalledPackages(0).mapNotNull { pi ->
        val ai = pi.applicationInfo ?: return@mapNotNull null
        val code = if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()
        AppItem(
            label = ai.loadLabel(pm).toString(),
            pkg = pi.packageName,
            versionName = pi.versionName,
            versionCode = code,
            sourceDir = ai.sourceDir ?: return@mapNotNull null,
            splits = ai.splitSourceDirs?.toList() ?: emptyList(),
            isSystem = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0
        )
    }.sortedBy { it.label.lowercase() }

/** Copia o APK (ou base + splits num .apks) para /ZSFiles_APKs. */
private fun extractApk(app: AppItem): File {
    val outDir = File(Environment.getExternalStorageDirectory(), "ZSFiles_APKs")
    outDir.mkdirs()
    val ver = app.versionName ?: app.versionCode.toString()
    val safe = "${app.label}_${app.pkg}_$ver".replace(Regex("[^\\p{L}\\p{N}._\\- ]"), "_").trim()
    if (app.splits.isEmpty()) {
        val out = FileUtils.uniqueTarget(outDir, "$safe.apk")
        File(app.sourceDir).copyTo(out)
        return out
    }
    val out = FileUtils.uniqueTarget(outDir, "$safe.apks")
    ZipOutputStream(BufferedOutputStream(FileOutputStream(out))).use { z ->
        (listOf(app.sourceDir) + app.splits).forEach { path ->
            val f = File(path)
            z.putNextEntry(ZipEntry(f.name))
            f.inputStream().use { it.copyTo(z) }
            z.closeEntry()
        }
    }
    return out
}

@Composable
private fun AppRow(app: AppItem, pm: PackageManager, onClick: () -> Unit) {
    val icon = remember(app.pkg) {
        try {
            pm.getApplicationIcon(app.pkg).toBitmap(80, 80).asImageBitmap()
        } catch (e: Exception) {
            null
        }
    }
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) Image(icon, null, Modifier.size(40.dp)) else Spacer(Modifier.size(40.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(app.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                app.pkg + " · " + (app.versionName ?: app.versionCode.toString()) +
                    if (app.splits.isNotEmpty()) " · split ×${app.splits.size + 1}" else "",
                fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun ApkExtractorScreen(
    onBack: () -> Unit,
    onAnalyze: (File) -> Unit,
    onShowFolder: (File) -> Unit,
) {
    val context = LocalContext.current
    val pm = context.packageManager
    val scope = rememberCoroutineScope()
    var apps by remember { mutableStateOf<List<AppItem>?>(null) }
    var query by remember { mutableStateOf("") }
    var showSystem by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<AppItem?>(null) }
    var busy by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<File?>(null) }

    fun toast(m: String) = Toast.makeText(context, m, Toast.LENGTH_LONG).show()

    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) {
            try {
                loadApps(pm)
            } catch (e: Exception) {
                emptyList()
            }
        }
    }

    val list = remember(apps, query, showSystem) {
        apps?.filter {
            (showSystem || !it.isSystem) &&
                (query.isBlank() || it.label.contains(query, ignoreCase = true) ||
                    it.pkg.contains(query, ignoreCase = true))
        }
    }

    fun doExtract(app: AppItem, analyze: Boolean) {
        busy = true
        scope.launch {
            val r = runCatching { withContext(Dispatchers.IO) { extractApk(app) } }
            busy = false
            val f = r.getOrNull()
            if (f == null) {
                toast("Erro: ${r.exceptionOrNull()?.message}")
            } else if (analyze) {
                onAnalyze(f)
            } else {
                result = f
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Extrator de APK", fontSize = 18.sp) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(ZIcons.Back, contentDescription = "Voltar") } }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().padding(8.dp),
                singleLine = true,
                placeholder = { Text("Buscar app ou pacote") }
            )
            Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = showSystem, onCheckedChange = { showSystem = it })
                Spacer(Modifier.width(8.dp))
                Text("Apps do sistema", Modifier.weight(1f), fontSize = 13.sp)
                Text("${list?.size ?: 0} apps", fontSize = 12.sp)
            }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 4.dp))
            if (list == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(list, key = { it.pkg }) { app -> AppRow(app, pm) { selected = app } }
                }
            }
        }
    }

    val sel = selected
    if (sel != null) {
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text(sel.label) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(sel.pkg, fontSize = 12.sp)
                    Text("Versão ${sel.versionName ?: "?"} (${sel.versionCode})", fontSize = 13.sp)
                    Text(
                        "Tamanho: ${FileUtils.readableSize(File(sel.sourceDir).length())}" +
                            if (sel.splits.isNotEmpty()) " · +${sel.splits.size} split(s) → será salvo como .apks" else "",
                        fontSize = 13.sp
                    )
                    Text(sel.sourceDir, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                }
            },
            confirmButton = {
                Row {
                    TextButton(onClick = { selected = null; doExtract(sel, false) }) { Text("Extrair") }
                    TextButton(onClick = { selected = null; doExtract(sel, true) }) { Text("Extrair + IA") }
                }
            },
            dismissButton = { TextButton(onClick = { selected = null }) { Text("Fechar") } }
        )
    }

    val done = result
    if (done != null) {
        AlertDialog(
            onDismissRequest = { result = null },
            title = { Text("APK extraído") },
            text = { Text("${done.name}\n\n${done.parentFile?.absolutePath}", fontSize = 13.sp) },
            confirmButton = {
                Row {
                    TextButton(onClick = { result = null; onShowFolder(done.parentFile ?: done) }) { Text("Ver na pasta") }
                    TextButton(onClick = { result = null; onAnalyze(done) }) { Text("Analisar com IA") }
                }
            },
            dismissButton = { TextButton(onClick = { result = null }) { Text("OK") } }
        )
    }
}
