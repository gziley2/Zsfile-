package com.zs.filemanager

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation

class SyntaxTransformation(private val ext: String) : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText =
        TransformedText(Highlighter.highlight(text.text, ext), OffsetMapping.Identity)
}

object Highlighter {
    private val cComment = Color(0xFF808080)
    private val cString = Color(0xFF6A8759)
    private val cNumber = Color(0xFF6897BB)
    private val cKeyword = Color(0xFFCC7832)
    private val cTag = Color(0xFFE8BF6A)

    private class Lang(val regex: Regex, val color: Color)

    private const val STR = "\"(?:\\\\.|[^\"\\\\\\n])*\"|'(?:\\\\.|[^'\\\\\\n])*'"
    private const val NUM = "\\b\\d+(?:\\.\\d+)?\\b"

    private fun lang(comment: String, kws: String, color: Color = cKeyword) =
        Lang(Regex("($comment)|($STR)|($NUM)|(\\b(?:$kws)\\b)"), color)

    private val cLikeKw = listOf(
        "abstract", "as", "break", "case", "catch", "class", "const", "continue", "default", "do", "else",
        "enum", "extends", "false", "final", "finally", "for", "fun", "function", "if", "implements", "import",
        "in", "interface", "is", "let", "new", "null", "object", "override", "package", "private", "protected",
        "public", "return", "static", "super", "switch", "this", "throw", "throws", "true", "try", "typealias",
        "val", "var", "void", "when", "while", "int", "long", "float", "double", "boolean", "char", "byte",
        "short", "struct", "using", "namespace", "async", "await", "yield", "lateinit", "sealed", "open",
        "internal", "companion", "suspend", "inline", "constructor", "typeof", "instanceof"
    ).joinToString("|")

    private val pyKw = listOf(
        "and", "as", "assert", "async", "await", "break", "class", "continue", "def", "del", "elif", "else",
        "except", "False", "finally", "for", "from", "global", "if", "import", "in", "is", "lambda", "None",
        "nonlocal", "not", "or", "pass", "raise", "return", "True", "try", "while", "with", "yield", "self", "print"
    ).joinToString("|")

    private val shKw = "if|then|else|elif|fi|for|do|done|while|case|esac|function|echo|exit|return|in"

    private val cLike = lang("//[^\\n]*|/\\*[\\s\\S]*?\\*/", cLikeKw)
    private val python = lang("#[^\\n]*", pyKw)
    private val shell = lang("#[^\\n]*", shKw)
    private val hashCfg = lang("#[^\\n]*", "true|false|null|yes|no")
    private val json = lang("(?!)", "true|false|null")
    private val xml = Lang(
        Regex("(<!--[\\s\\S]*?-->)|(\"[^\"]*\"|'[^']*')|($NUM)|(</?[A-Za-z_][\\w:.-]*|/?>)"),
        cTag
    )

    private val byExt: Map<String, Lang> = buildMap {
        listOf(
            "kt", "kts", "java", "cs", "js", "ts", "jsx", "tsx", "c", "h", "cpp", "hpp", "cc", "go", "rs",
            "swift", "php", "gradle", "dart", "css", "scala", "groovy"
        ).forEach { put(it, cLike) }
        listOf("py", "pyw").forEach { put(it, python) }
        listOf("sh", "bash", "zsh").forEach { put(it, shell) }
        listOf("yml", "yaml", "properties", "toml", "conf", "cfg", "smali", "rb").forEach { put(it, hashCfg) }
        put("json", json)
        listOf("xml", "html", "htm", "svg", "xhtml", "plist").forEach { put(it, xml) }
    }

    fun highlight(text: String, ext: String): AnnotatedString {
        val lang = byExt[ext.lowercase()]
        if (lang == null || text.length > 150_000) return AnnotatedString(text)
        return try {
            buildAnnotatedString {
                append(text)
                for (m in lang.regex.findAll(text)) {
                    val c = when {
                        m.groups[1] != null -> cComment
                        m.groups[2] != null -> cString
                        m.groups[3] != null -> cNumber
                        else -> lang.color
                    }
                    addStyle(SpanStyle(color = c), m.range.first, m.range.last + 1)
                }
            }
        } catch (e: StackOverflowError) {
            AnnotatedString(text)
        }
    }
}
