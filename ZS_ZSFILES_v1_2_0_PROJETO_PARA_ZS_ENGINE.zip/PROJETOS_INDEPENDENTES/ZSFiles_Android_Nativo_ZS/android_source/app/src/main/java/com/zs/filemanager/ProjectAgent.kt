package com.zs.filemanager

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.StringReader
import java.security.MessageDigest
import javax.xml.parsers.DocumentBuilderFactory

/*
 * Assistente de projeto: a IA lê, busca, edita e cria arquivos DIRETO na pasta do projeto
 * (o app já tem acesso a todos os arquivos). Antes de mexer num arquivo, o app guarda uma
 * cópia dele (copy-on-write), então dá para ver o diff, reverter por arquivo ou desfazer tudo.
 */

const val INSTRUCOES = "ZS_INSTRUCOES.md"

const val MODELO_INSTRUCOES = """# Instruções do projeto (a IA lê este arquivo a cada pedido)

## O que é este projeto
(Descreva em 2 linhas: é jogo ou app, e qual o objetivo.)

## Formato da ZS Engine
- project.zeproj: JSON ("format": "zeproj-1") com nome, cena principal (main_scene) e tipo ("kind").
- scenes/*.zscene: JSON ("format": "zscene-1") com "size": [largura, altura] e a lista "entities".
  Cada entidade tem: id (12 caracteres hex, único), type (ex.: player, wall, text), name, x, y, w, h,
  color (#rrggbb), solid, visible, locked, speed, asset, text.
- Mantenha o JSON válido, não renomeie campos existentes e não repita ids.
- Em projetos Android nativos o código fica em android_source/ (Kotlin + Gradle).
  zs_native.json e project.zeproj são gerados pela engine: não edite.

## Regras
- Responda em português do Brasil, curto.
- Mudanças pequenas e focadas; não reescreva arquivos inteiros sem necessidade.
- Não mexa em build/, .gradle/ e zs_build_reports/.

## Como eu testo
- Abro e compilo na ZS Engine. Se der erro, o log fica em android_source/zs_build_reports/logs/.
"""

// ---------------------------------------------------------------- diff por linha

class DiffLine(val kind: Char, val text: String) // ' ' igual, '+' novo, '-' removido, '~' trecho omitido

object LineDiff {
    fun diff(a: List<String>, b: List<String>): List<DiffLine> {
        var p = 0
        while (p < a.size && p < b.size && a[p] == b[p]) p++
        var s = 0
        while (s < a.size - p && s < b.size - p && a[a.size - 1 - s] == b[b.size - 1 - s]) s++
        val ma = a.subList(p, a.size - s)
        val mb = b.subList(p, b.size - s)
        val out = ArrayList<DiffLine>()
        for (i in 0 until p) out.add(DiffLine(' ', a[i]))
        if (ma.size.toLong() * mb.size <= 2_000_000L) {
            val n = ma.size
            val m = mb.size
            val t = Array(n + 1) { IntArray(m + 1) }
            for (i in n - 1 downTo 0) for (j in m - 1 downTo 0) {
                t[i][j] = if (ma[i] == mb[j]) t[i + 1][j + 1] + 1 else maxOf(t[i + 1][j], t[i][j + 1])
            }
            var i = 0
            var j = 0
            while (i < n && j < m) {
                if (ma[i] == mb[j]) { out.add(DiffLine(' ', ma[i])); i++; j++ }
                else if (t[i + 1][j] >= t[i][j + 1]) { out.add(DiffLine('-', ma[i])); i++ }
                else { out.add(DiffLine('+', mb[j])); j++ }
            }
            while (i < n) { out.add(DiffLine('-', ma[i])); i++ }
            while (j < m) { out.add(DiffLine('+', mb[j])); j++ }
        } else {
            ma.forEach { out.add(DiffLine('-', it)) }
            mb.forEach { out.add(DiffLine('+', it)) }
        }
        for (i in a.size - s until a.size) out.add(DiffLine(' ', a[i]))
        return out
    }

    fun counts(d: List<DiffLine>): Pair<Int, Int> = d.count { it.kind == '+' } to d.count { it.kind == '-' }

    /** Só as linhas alteradas, com [ctx] linhas de contexto ao redor. */
    fun compact(d: List<DiffLine>, ctx: Int = 2): List<DiffLine> {
        val keep = BooleanArray(d.size)
        d.forEachIndexed { i, l ->
            if (l.kind != ' ') for (k in maxOf(0, i - ctx)..minOf(d.lastIndex, i + ctx)) keep[k] = true
        }
        val out = ArrayList<DiffLine>()
        var lacuna = false
        d.forEachIndexed { i, l ->
            if (keep[i]) {
                if (lacuna) out.add(DiffLine('~', "…"))
                lacuna = false
                out.add(l)
            } else lacuna = true
        }
        return out
    }
}

// ---------------------------------------------------------------- sessão

class AgentMsg(val kind: String, val text: String) // user | ai | plan | step

class Change(val rel: String, val backup: File?, val created: Boolean)

class AgentSession(ctx: Context, val project: File) {
    val raiz: File = project.canonicalFile
    val base: File = File(ctx.filesDir, "agent/" + sha(project.absolutePath)).apply { mkdirs() }

    val msgs = mutableStateListOf<AgentMsg>()
    var contents = JSONArray()
    var provider = ""

    /** Arquivos alterados desde a última vez que você aceitou ou desfez tudo. */
    val changes = LinkedHashMap<String, Change>()
    var tick by mutableIntStateOf(0)
    var busy by mutableStateOf(false)
    var planPending by mutableStateOf(false)
    @Volatile var cancel = false

    private var backupDir: File? = null

    init {
        carregarChat()
    }

    private fun sha(s: String): String =
        MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }.take(12)

    fun dirBackup(): File {
        backupDir?.let { return it }
        val d = File(base, "b${System.currentTimeMillis()}")
        d.mkdirs()
        backupDir = d
        return d
    }

    // --- chat salvo por projeto
    private fun arquivoChat() = File(base, "chat.json")

    fun salvarChat() {
        try {
            val a = JSONArray()
            msgs.filter { it.kind != "step" }.takeLast(200).forEach {
                a.put(JSONObject().put("k", it.kind).put("t", it.text))
            }
            arquivoChat().writeText(a.toString())
        } catch (e: Exception) {
        }
    }

    private fun carregarChat() {
        try {
            val f = arquivoChat()
            if (!f.isFile) return
            val a = JSONArray(f.readText())
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                msgs.add(AgentMsg(o.getString("k"), o.getString("t")))
            }
        } catch (e: Exception) {
        }
    }

    fun limparChat() {
        msgs.clear(); contents = JSONArray(); planPending = false
        arquivoChat().delete()
    }

    // --- revisão das mudanças
    fun diffDe(c: Change): List<DiffLine> {
        val atual = File(raiz, c.rel)
        val antes = if (c.created || c.backup == null) emptyList() else c.backup.readLines()
        val depois = if (atual.isFile) atual.readLines() else emptyList()
        return LineDiff.diff(antes, depois)
    }

    fun reverter(rel: String) {
        val c = changes[rel] ?: return
        val f = File(raiz, rel)
        try {
            if (c.created) f.delete() else c.backup?.copyTo(f, true)
        } catch (e: Exception) {
        }
        changes.remove(rel)
        if (changes.isEmpty()) backupDir = null
    }

    fun desfazerTudo() {
        changes.keys.toList().forEach { reverter(it) }
        backupDir = null
    }

    fun aceitar() {
        changes.clear()
        backupDir = null
        // guarda só as 10 últimas levas de cópias
        base.listFiles()?.filter { it.isDirectory && it.name.startsWith("b") }
            ?.sortedBy { it.name.drop(1).toLongOrNull() ?: 0L }?.dropLast(10)
            ?.forEach { it.deleteRecursively() }
    }
}

// ---------------------------------------------------------------- ferramentas

class AgentFs(private val s: AgentSession, private val readOnly: Boolean) {
    companion object {
        val IGNORAR = setOf("build", ".git", ".gradle", ".idea", "node_modules", "zs_build_reports", ".cxx")
        const val LIMITE = 1_000_000L
    }

    private val raiz = s.raiz

    private fun rel(f: File) = f.relativeTo(raiz).path.replace(File.separatorChar, '/')

    private fun seguro(caminho: String): File {
        val f = File(raiz, caminho.trim().trimStart('/')).canonicalFile
        require(f.path == raiz.path || f.path.startsWith(raiz.path + File.separator)) { "caminho fora do projeto" }
        return f
    }

    private fun pastaIgnorada(f: File): Boolean = rel(f).split("/").dropLast(1).any { it in IGNORAR }

    private fun arquivos(): Sequence<File> =
        raiz.walkTopDown().onEnter { it == raiz || it.name !in IGNORAR }.filter { it.isFile }

    private fun pareceBinario(f: File): Boolean {
        f.inputStream().use { i ->
            val b = ByteArray(2000)
            val n = i.read(b)
            for (k in 0 until maxOf(n, 0)) if (b[k] == 0.toByte()) return true
        }
        return false
    }

    fun arvore(): String {
        val out = ArrayList<String>()
        fun rec(d: File, nivel: Int, prefixo: String) {
            val itens = (d.listFiles() ?: return)
                .filter { it.name !in IGNORAR && !it.name.startsWith(".") }
                .sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
            for (f in itens) {
                if (out.size >= 150) return
                out.add(prefixo + f.name + if (f.isDirectory) "/" else "")
                if (f.isDirectory && nivel < 2) rec(f, nivel + 1, "$prefixo  ")
            }
        }
        rec(raiz, 1, "")
        return out.joinToString("\n") + if (out.size >= 150) "\n..." else ""
    }

    fun listar(filtro: String): String {
        val l = arquivos().map { "${rel(it)} (${it.length()} bytes)" }
            .filter { filtro.isBlank() || it.contains(filtro, true) }.take(500).toList()
        return if (l.isEmpty()) "(nenhum arquivo)"
        else l.joinToString("\n") + if (l.size == 500) "\n... (lista cortada; use o filtro)" else ""
    }

    fun ler(caminho: String, ini: Int?, fim: Int?): String {
        val f = seguro(caminho)
        if (!f.isFile) return "ERRO: arquivo não existe"
        if (f.length() > 20_000_000) return "ERRO: arquivo grande demais"
        if (pareceBinario(f)) return "ERRO: arquivo binário"
        val linhas = f.readText().lines()
        val a = ((ini ?: 1) - 1).coerceIn(0, linhas.size)
        val b = (fim ?: linhas.size).coerceIn(a, linhas.size)
        val txt = linhas.subList(a, b).withIndex().joinToString("\n") { "${a + it.index + 1}: ${it.value}" }
        return if (txt.length > 60_000) txt.take(60_000) + "\n...(cortado; peça um intervalo de linhas)" else txt
    }

    fun buscar(texto: String): String {
        val r = ArrayList<String>()
        for (f in arquivos()) {
            if (f.length() > LIMITE || pareceBinario(f)) continue
            f.readLines().forEachIndexed { i, l ->
                if (r.size < 60 && l.contains(texto, true)) r.add("${rel(f)}:${i + 1}: ${l.trim().take(160)}")
            }
            if (r.size >= 60) break
        }
        return if (r.isEmpty()) "nada encontrado" else r.joinToString("\n")
    }

    // --- validação: JSON e XML não podem ficar inválidos por causa da IA
    private fun valido(ext: String, texto: String): Boolean? {
        if (ext != "json" && ext != "xml") return null
        return try {
            if (ext == "json") {
                val t = texto.trim()
                if (t.startsWith("[")) JSONArray(t) else JSONObject(t)
            } else {
                DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(org.xml.sax.InputSource(StringReader(texto)))
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun invalidaArquivo(f: File, antes: String?, depois: String): String? {
        val ext = f.extension.lowercase()
        val novo = valido(ext, depois) ?: return null
        if (novo) return null
        val eraValido = if (antes == null) true else valido(ext, antes) ?: return null
        return if (eraValido) "ERRO: o resultado seria um $ext inválido; nada foi alterado. Revise o trecho e tente de novo." else null
    }

    // --- aviso de chaves/parênteses desbalanceados em código
    private fun avisoBalanco(f: File, t: String): String {
        if (f.extension.lowercase() !in setOf("kt", "kts", "java", "js", "ts", "cs", "gradle", "c", "cpp", "h")) return ""
        val pilha = ArrayList<Char>()
        var ok = true
        var i = 0
        while (i < t.length && ok) {
            val c = t[i]
            if (c == '/' && i + 1 < t.length && t[i + 1] == '/') {
                while (i < t.length && t[i] != '\n') i++
                continue
            }
            if (c == '/' && i + 1 < t.length && t[i + 1] == '*') {
                val e = t.indexOf("*/", i + 2)
                i = if (e < 0) t.length else e + 2
                continue
            }
            if (c == '"' || c == '\'') {
                i++
                while (i < t.length && t[i] != c && t[i] != '\n') {
                    if (t[i] == '\\') i++
                    i++
                }
                i++
                continue
            }
            if (c == '(' || c == '[' || c == '{') pilha.add(c)
            else if (c == ')' || c == ']' || c == '}') {
                val o = if (pilha.isEmpty()) null else pilha.removeAt(pilha.lastIndex)
                if (o == null || "([{".indexOf(o) != ")]}".indexOf(c)) ok = false
            }
            i++
        }
        return if (ok && pilha.isEmpty()) "" else
            "\nAVISO: parece haver chaves/parênteses desbalanceados em ${f.name}; releia o arquivo e confira."
    }

    private fun guardar(f: File) {
        val r = rel(f)
        if (s.changes.containsKey(r)) return
        if (f.exists()) {
            val b = File(s.dirBackup(), r)
            b.parentFile?.mkdirs()
            f.copyTo(b, true)
            s.changes[r] = Change(r, b, false)
        } else {
            s.changes[r] = Change(r, null, true)
        }
    }

    fun editar(caminho: String, antigo: String, novo: String): String {
        if (readOnly) return "ERRO: modo plano (somente leitura)"
        val f = seguro(caminho)
        if (!f.isFile) return "ERRO: arquivo não existe"
        if (pastaIgnorada(f)) return "ERRO: pasta ignorada (build/.git/.gradle)"
        if (f.length() > LIMITE) return "ERRO: arquivo grande demais para editar com segurança"
        if (pareceBinario(f)) return "ERRO: arquivo binário"
        val t = f.readText()
        val i = if (antigo.isEmpty()) -1 else t.indexOf(antigo)
        val n = if (antigo.isEmpty()) 0 else t.split(antigo).size - 1
        if (n != 1 || i < 0) return "ERRO: trecho_antigo aparece $n vezes (precisa aparecer exatamente 1). Releia o arquivo e copie o trecho exato."
        val depois = t.substring(0, i) + novo + t.substring(i + antigo.length)
        invalidaArquivo(f, t, depois)?.let { return it }
        guardar(f)
        f.writeText(depois)
        return "ok" + avisoBalanco(f, depois)
    }

    fun criar(caminho: String, conteudo: String): String {
        if (readOnly) return "ERRO: modo plano (somente leitura)"
        val f = seguro(caminho)
        if (f == raiz || f.isDirectory) return "ERRO: o caminho é uma pasta"
        if (pastaIgnorada(f)) return "ERRO: pasta ignorada (build/.git/.gradle)"
        val existe = f.exists()
        if (existe && (f.length() > LIMITE || pareceBinario(f))) return "ERRO: não sobrescrevo arquivo grande ou binário"
        invalidaArquivo(f, if (existe) f.readText() else null, conteudo)?.let { return it }
        guardar(f)
        f.parentFile?.mkdirs()
        f.writeText(conteudo)
        return "ok" + avisoBalanco(f, conteudo)
    }
}

class ToolSpec(
    val name: String,
    val desc: String,
    val props: List<Triple<String, String, String>>,
    val req: List<String>,
    val writes: Boolean
) {
    private fun propsJson(maiusculo: Boolean): JSONObject {
        val o = JSONObject()
        props.forEach { (n, t, d) ->
            o.put(n, JSONObject().put("type", if (maiusculo) t.uppercase() else t).put("description", d))
        }
        return o
    }

    fun gemini(): JSONObject {
        val p = JSONObject().put("type", "OBJECT").put("properties", propsJson(true))
        if (req.isNotEmpty()) p.put("required", JSONArray(req))
        return JSONObject().put("name", name).put("description", desc).put("parameters", p)
    }

    fun claude(): JSONObject {
        val p = JSONObject().put("type", "object").put("properties", propsJson(false))
        if (req.isNotEmpty()) p.put("required", JSONArray(req))
        return JSONObject().put("name", name).put("description", desc).put("input_schema", p)
    }
}

val AGENT_TOOLS = listOf(
    ToolSpec("listar_arquivos", "Lista os arquivos do projeto (ignora build, .git, .gradle). Filtro opcional no caminho.",
        listOf(Triple("filtro", "string", "parte do caminho para filtrar")), emptyList(), false),
    ToolSpec("ler_arquivo", "Lê um arquivo de texto. As linhas vêm numeradas; não inclua os números ao editar.",
        listOf(
            Triple("caminho", "string", "caminho relativo à pasta do projeto"),
            Triple("linha_inicial", "integer", "opcional"),
            Triple("linha_final", "integer", "opcional")
        ), listOf("caminho"), false),
    ToolSpec("buscar_texto", "Procura um texto em todos os arquivos de texto do projeto.",
        listOf(Triple("texto", "string", "texto a procurar (sem diferenciar maiúsculas)")), listOf("texto"), false),
    ToolSpec("editar_arquivo", "Troca um trecho exato (que aparece uma única vez) por outro.",
        listOf(
            Triple("caminho", "string", "caminho relativo"),
            Triple("trecho_antigo", "string", "trecho exato a trocar"),
            Triple("trecho_novo", "string", "novo trecho")
        ), listOf("caminho", "trecho_antigo", "trecho_novo"), true),
    ToolSpec("criar_arquivo", "Cria um arquivo novo ou sobrescreve um arquivo de texto existente.",
        listOf(
            Triple("caminho", "string", "caminho relativo"),
            Triple("conteudo", "string", "conteúdo completo do arquivo")
        ), listOf("caminho", "conteudo"), true)
)

// ---------------------------------------------------------------- log de build

object LogFinder {
    fun achar(projeto: File): File? {
        var melhor: File? = null
        projeto.walkTopDown().maxDepth(7).onEnter { it.name != ".git" && it.name != "node_modules" }.forEach { f ->
            if (f.isFile && f.extension.lowercase() in setOf("log", "txt") &&
                (f.path.contains("zs_build_reports") || f.parentFile?.name == "logs")
            ) {
                if (melhor == null || f.lastModified() > melhor!!.lastModified()) melhor = f
            }
        }
        return melhor
    }

    /** Só os trechos úteis do log (erros do Kotlin/Gradle), para não gastar contexto. */
    fun extrair(f: File): String {
        val txt = if (f.length() > 3_000_000) {
            f.inputStream().use { i ->
                i.skip(f.length() - 3_000_000)
                String(i.readBytes(), Charsets.UTF_8)
            }
        } else f.readText()
        val linhas = txt.lines()
        val padrao = Regex("^(e|w): |error:|FAILURE|What went wrong|Execution failed|Unresolved reference|Caused by|\\.kt:\\d+|\\.java:\\d+")
        val marcadas = linhas.indices.filter { padrao.containsMatchIn(linhas[it]) }.take(120)
        val corpo = if (marcadas.isEmpty()) linhas.takeLast(120).joinToString("\n")
        else marcadas.flatMap { listOf(it, it + 1) }.distinct().filter { it < linhas.size }.joinToString("\n") { linhas[it] }
        return "Arquivo de log: ${f.path}\n" + corpo.take(14_000)
    }
}

// ---------------------------------------------------------------- execução (Gemini e Claude)

object AgentRunner {
    const val MAX_PASSOS = 30

    class Anexo(val mime: String, val b64: String)

    private const val BASE = "Você é um engenheiro de software dentro de um app Android (ZS Files) que lê e edita arquivos de " +
        "projetos do usuário: jogos e apps, inclusive projetos da ZS Engine Studio e projetos Android com Kotlin/Gradle. " +
        "Trabalhe com as ferramentas: liste, leia só o necessário, busque textos, edite com trechos pequenos e exatos e crie " +
        "arquivos quando precisar. Depois de editar, releia o trecho para conferir. Nunca invente arquivos ou código que você " +
        "não viu. Você não apaga arquivos. JSON e XML precisam continuar válidos. Respeite as instruções do projeto, se houver. " +
        "O app NÃO compila nem executa o projeto: o usuário testa na ZS Engine; diga o que ele deve testar. Se faltar informação, " +
        "pergunte em vez de adivinhar. Ao terminar, responda em português do Brasil, curto (tela de celular): o que mudou, por arquivo. " +
        "Não escreva malware nem código para burlar proteções de terceiros."

    private const val PLANO = "\n\nMODO PLANO: você só tem ferramentas de leitura. Investigue o necessário e responda com um plano " +
        "numerado (arquivos que vai mexer e o que muda em cada um). Não diga que já alterou nada."

    private fun sistema(s: AgentSession, somenteLeitura: Boolean): String {
        val f = File(s.raiz, INSTRUCOES)
        val inst: String? = try {
            if (f.isFile) f.readText().take(20_000) else null
        } catch (e: Exception) {
            null
        }
        return BASE + (if (inst != null) "\n\n<instrucoes_do_projeto>\n$inst\n</instrucoes_do_projeto>" else "") +
            if (somenteLeitura) PLANO else ""
    }

    private fun descrever(a: JSONObject): String =
        listOf("caminho", "texto", "filtro").map { a.optString(it, "") }.firstOrNull { it.isNotBlank() } ?: ""

    private fun intOuNulo(a: JSONObject, k: String): Int? = if (a.has(k) && !a.isNull(k)) a.optInt(k) else null

    private fun executarTool(fs: AgentFs, nome: String, a: JSONObject): String = try {
        when (nome) {
            "listar_arquivos" -> fs.listar(a.optString("filtro", ""))
            "ler_arquivo" -> fs.ler(a.getString("caminho"), intOuNulo(a, "linha_inicial"), intOuNulo(a, "linha_final"))
            "buscar_texto" -> fs.buscar(a.getString("texto"))
            "editar_arquivo" -> fs.editar(a.getString("caminho"), a.getString("trecho_antigo"), a.getString("trecho_novo"))
            "criar_arquivo" -> fs.criar(a.getString("caminho"), a.getString("conteudo"))
            else -> "ERRO: ferramenta desconhecida"
        }
    } catch (e: Exception) {
        "ERRO: ${e.message}"
    }

    // resultados e imagens antigas ocupam muito contexto: encurta tudo que não é do pedido atual
    private fun compactar(arr: JSONArray) {
        for (i in 0 until arr.length()) {
            val msg = arr.getJSONObject(i)
            val parts = msg.optJSONArray("parts")           // formato Gemini
            if (parts != null) {
                for (j in 0 until parts.length()) {
                    val p = parts.getJSONObject(j)
                    val r = p.optJSONObject("functionResponse")?.optJSONObject("response")
                    if (r != null) {
                        val t = r.optString("result")
                        if (t.length > 1500) r.put("result", t.take(600) + "\n[... resultado antigo omitido ...]")
                    }
                    if (p.has("inlineData")) parts.put(j, JSONObject().put("text", "[imagem anterior omitida]"))
                }
            }
            val blocos = msg.optJSONArray("content")         // formato Claude
            if (blocos != null) {
                for (j in 0 until blocos.length()) {
                    val b = blocos.getJSONObject(j)
                    if (b.optString("type") == "tool_result") {
                        val t = b.optString("content")
                        if (t.length > 1500) b.put("content", t.take(600) + "\n[... resultado antigo omitido ...]")
                    }
                    if (b.optString("type") == "image") {
                        blocos.put(j, JSONObject().put("type", "text").put("text", "[imagem anterior omitida]"))
                    }
                }
            }
        }
    }

    private fun cortar(a: JSONArray, n: Int): JSONArray {
        val r = JSONArray()
        for (i in 0 until minOf(n, a.length())) r.put(a.get(i))
        return r
    }

    private fun encerrar(s: AgentSession, claude: Boolean, texto: String) {
        if (claude) {
            s.contents.put(
                JSONObject().put("role", "assistant")
                    .put("content", JSONArray().put(JSONObject().put("type", "text").put("text", texto)))
            )
        } else {
            s.contents.put(
                JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", texto)))
            )
        }
    }

    /** Bloqueante: rode fora da thread principal. [log] recebe uma linha por passo. */
    fun run(
        ctx: Context, s: AgentSession, pedido: String, anexos: List<Anexo>,
        somenteLeitura: Boolean, log: (String) -> Unit
    ): String {
        val provider = AiSettings.provider(ctx)
        val chave = AiSettings.apiKey(ctx, provider)
        val modelo = AiSettings.model(ctx, provider)
        if (chave.isBlank()) throw IllegalStateException("Configure a chave da API em Ajustes.")
        if (s.provider != provider) {
            s.contents = JSONArray()
            s.provider = provider
        }
        val fs = AgentFs(s, somenteLeitura)
        val primeira = s.contents.length() == 0
        val texto = buildString {
            if (primeira) {
                val antes = s.msgs.filter { it.kind == "user" || it.kind == "ai" }.dropLast(1).takeLast(6)
                if (antes.isNotEmpty()) {
                    append("<conversa_anterior>\n")
                    antes.forEach { append(if (it.kind == "user") "Usuário: " else "Assistente: ").append(it.text.take(500)).append("\n") }
                    append("</conversa_anterior>\n\n")
                }
                append("<estrutura_do_projeto>\n").append(fs.arvore()).append("\n</estrutura_do_projeto>\n\n")
            }
            append(pedido)
        }
        val marca = s.contents.length()
        try {
            return if (provider == AiSettings.ANTHROPIC)
                rodarClaude(chave, modelo, sistema(s, somenteLeitura), s, fs, texto, anexos, somenteLeitura, log)
            else
                rodarGemini(chave, modelo, sistema(s, somenteLeitura), s, fs, texto, anexos, somenteLeitura, log)
        } catch (e: Exception) {
            s.contents = cortar(s.contents, marca) // não deixa a conversa num estado inválido
            val m = e.message ?: ""
            if (m.contains("404")) {
                throw IOException(m + "\n\nModelo não encontrado: em Ajustes > Configurar IA toque em Buscar modelos e escolha um.")
            }
            throw e
        }
    }

    private fun rodarGemini(
        chave: String, modelo: String, sistema: String, s: AgentSession, fs: AgentFs, pedido: String,
        anexos: List<Anexo>, somenteLeitura: Boolean, log: (String) -> Unit
    ): String {
        compactar(s.contents)
        val partes = JSONArray().put(JSONObject().put("text", pedido))
        anexos.forEach {
            partes.put(JSONObject().put("inlineData", JSONObject().put("mimeType", it.mime).put("data", it.b64)))
        }
        s.contents.put(JSONObject().put("role", "user").put("parts", partes))
        val decl = JSONArray()
        AGENT_TOOLS.filter { !somenteLeitura || !it.writes }.forEach { decl.put(it.gemini()) }
        val tools = JSONArray().put(JSONObject().put("functionDeclarations", decl))
        val m = modelo.trim().removePrefix("models/")
        repeat(MAX_PASSOS) {
            if (s.cancel) {
                encerrar(s, false, "(pedido cancelado pelo usuário)")
                return "Cancelado."
            }
            val corpo = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sistema))))
                .put("tools", tools)
                .put("contents", s.contents)
                .put("generationConfig", JSONObject().put("maxOutputTokens", 16384))
            val resp = AiClient.post(
                "https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent",
                mapOf("x-goog-api-key" to chave), corpo
            )
            val cand = resp.optJSONArray("candidates")?.optJSONObject(0)
                ?: throw IOException("Sem resposta da IA (possível bloqueio).")
            val conteudo = cand.optJSONObject("content")
                ?: throw IOException("Resposta vazia (${cand.optString("finishReason", "?")}).")
            s.contents.put(conteudo) // devolve exatamente o que o modelo mandou
            val ps = conteudo.optJSONArray("parts") ?: JSONArray()
            val resultados = JSONArray()
            var texto = ""
            for (i in 0 until ps.length()) {
                val p = ps.getJSONObject(i)
                val fc = p.optJSONObject("functionCall")
                if (fc != null) {
                    val nome = fc.getString("name")
                    val args = fc.optJSONObject("args") ?: JSONObject()
                    log("→ $nome ${descrever(args)}")
                    val r = executarTool(fs, nome, args)
                    resultados.put(
                        JSONObject().put(
                            "functionResponse",
                            JSONObject().put("name", nome).put("response", JSONObject().put("result", r))
                        )
                    )
                } else if (!p.optBoolean("thought", false)) {
                    texto += p.optString("text", "")
                }
            }
            if (resultados.length() == 0) return texto.ifBlank { "(a IA terminou sem texto)" }
            s.contents.put(JSONObject().put("role", "user").put("parts", resultados))
        }
        encerrar(s, false, "(parei no limite de passos)")
        return "Parei após $MAX_PASSOS passos. Peça para continuar de onde parou."
    }

    private fun rodarClaude(
        chave: String, modelo: String, sistema: String, s: AgentSession, fs: AgentFs, pedido: String,
        anexos: List<Anexo>, somenteLeitura: Boolean, log: (String) -> Unit
    ): String {
        compactar(s.contents)
        val blocos = JSONArray()
        anexos.forEach {
            blocos.put(
                JSONObject().put("type", "image").put(
                    "source", JSONObject().put("type", "base64").put("media_type", it.mime).put("data", it.b64)
                )
            )
        }
        blocos.put(JSONObject().put("type", "text").put("text", pedido))
        s.contents.put(JSONObject().put("role", "user").put("content", blocos))
        val tools = JSONArray()
        AGENT_TOOLS.filter { !somenteLeitura || !it.writes }.forEach { tools.put(it.claude()) }
        repeat(MAX_PASSOS) {
            if (s.cancel) {
                encerrar(s, true, "(pedido cancelado pelo usuário)")
                return "Cancelado."
            }
            val corpo = JSONObject()
                .put("model", modelo.trim())
                .put("max_tokens", 8192)
                .put("system", sistema)
                .put("tools", tools)
                .put("messages", s.contents)
            val resp = AiClient.post(
                "https://api.anthropic.com/v1/messages",
                mapOf("x-api-key" to chave, "anthropic-version" to "2023-06-01"), corpo
            )
            val conteudo = resp.optJSONArray("content") ?: JSONArray()
            s.contents.put(JSONObject().put("role", "assistant").put("content", conteudo))
            val resultados = JSONArray()
            var texto = ""
            for (i in 0 until conteudo.length()) {
                val b = conteudo.getJSONObject(i)
                when (b.optString("type")) {
                    "text" -> texto += b.optString("text", "")
                    "tool_use" -> {
                        val nome = b.getString("name")
                        val args = b.optJSONObject("input") ?: JSONObject()
                        log("→ $nome ${descrever(args)}")
                        resultados.put(
                            JSONObject().put("type", "tool_result").put("tool_use_id", b.getString("id"))
                                .put("content", executarTool(fs, nome, args))
                        )
                    }
                }
            }
            if (resultados.length() == 0) return texto.ifBlank { "(a IA terminou sem texto)" }
            s.contents.put(JSONObject().put("role", "user").put("content", resultados))
        }
        encerrar(s, true, "(parei no limite de passos)")
        return "Parei após $MAX_PASSOS passos. Peça para continuar de onde parou."
    }
}
