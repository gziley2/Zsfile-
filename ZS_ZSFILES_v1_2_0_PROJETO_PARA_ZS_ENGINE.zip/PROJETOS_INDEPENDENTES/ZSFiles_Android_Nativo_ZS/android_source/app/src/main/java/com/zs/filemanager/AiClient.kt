package com.zs.filemanager

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

object AiSettings {
    const val GEMINI = "gemini"
    const val ANTHROPIC = "anthropic"

    fun defaultModel(p: String) = if (p == ANTHROPIC) "claude-sonnet-5-5" else "gemini-flash-latest"

    private fun prefs(c: Context) = c.getSharedPreferences("zsfiles", Context.MODE_PRIVATE)
    fun provider(c: Context): String = prefs(c).getString("provider", GEMINI) ?: GEMINI
    fun apiKey(c: Context, p: String): String {
        val guardado = prefs(c).getString("key_$p", "") ?: ""
        // chave antiga em texto simples: criptografa na primeira leitura
        if (guardado.isNotEmpty() && !SecureStore.isEncrypted(guardado)) {
            val cifrado = SecureStore.encrypt(guardado)
            if (SecureStore.isEncrypted(cifrado)) prefs(c).edit().putString("key_$p", cifrado).apply()
        }
        return SecureStore.decrypt(guardado)
    }
    fun model(c: Context, p: String): String {
        val m = (prefs(c).getString("model_$p", "") ?: "").trim()
        if (m.isBlank()) return defaultModel(p)
        if (p == GEMINI && (m.startsWith("gemini-1.") || m.startsWith("gemini-2."))) return defaultModel(p)
        return m
    }

    fun save(c: Context, p: String, key: String, model: String) {
        prefs(c).edit()
            .putString("provider", p)
            .putString("key_$p", SecureStore.encrypt(key))
            .putString("model_$p", model)
            .apply()
    }
}

object AiClient {
    class ChatMsg(val role: String, val text: String, val shown: String = text)

    const val SYSTEM =
        "Você é um analista de engenharia reversa e segurança de software dentro de um app Android de " +
            "gerenciamento de arquivos. O usuário analisa arquivos que possui ou tem autorização para analisar " +
            "(apps próprios, auditoria, estudo, interoperabilidade). Você recebe um CONTEXTO EXTRAÍDO localmente " +
            "(manifest decodificado, classes, strings, indicadores, estrutura, código, às vezes smali decompilado das classes do app: leia-o e, se pedido, reescreva em Java/Kotlin legível). Explique com profundidade: " +
            "o que o app/arquivo faz, arquitetura, fluxos prováveis, riscos e comportamentos suspeitos, e o que " +
            "investigar a seguir. Separe claramente o que foi OBSERVADO no contexto do que é HIPÓTESE sua, e não " +
            "invente o que não está no contexto; se o contexto listar arquivos omitidos, não conclua nada sobre eles. Responda em português do Brasil, em seções curtas e objetivas " +
            "(a leitura é em tela de celular). Não escreva malware nem exploits funcionais e não ensine a burlar " +
            "proteções ou licenças de terceiros; foque em compreender, auditar e documentar."

    fun firstMessage(name: String, ctx: String, request: String): String =
        "Analise o arquivo \"$name\". Abaixo está o CONTEXTO EXTRAÍDO localmente no celular " +
            "(eu não tenho o arquivo inteiro aqui, só este resumo).\n\n<contexto>\n$ctx\n</contexto>\n\nPedido: $request"

    /** Chamada bloqueante: rode fora da thread principal. */
    fun send(provider: String, apiKey: String, model: String, system: String, history: List<ChatMsg>): String =
        if (provider == AiSettings.ANTHROPIC) sendAnthropic(apiKey, model, system, history)
        else sendGemini(apiKey, model, system, history)

    /** Repete em erros temporários do servidor (503 alta demanda, 429, 500, 502, 504). */
    internal fun post(url: String, headers: Map<String, String>, body: JSONObject): JSONObject {
        val waits = longArrayOf(3_000L, 8_000L, 15_000L)
        var attempt = 0
        while (true) {
            try {
                return postOnce(url, headers, body)
            } catch (e: IOException) {
                val m = e.message ?: ""
                val temporary = m.startsWith("HTTP 503") || m.startsWith("HTTP 429") || m.startsWith("HTTP 500") ||
                    m.startsWith("HTTP 502") || m.startsWith("HTTP 504")
                if (!temporary || attempt >= waits.size) throw e
                Thread.sleep(waits[attempt])
                attempt++
            }
        }
    }

    private fun postOnce(url: String, headers: Map<String, String>, body: JSONObject): JSONObject {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 20_000
            conn.readTimeout = 180_000
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val txt = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val msg = try {
                    JSONObject(txt).getJSONObject("error").getString("message")
                } catch (e: Exception) {
                    txt.take(300)
                }
                throw IOException("HTTP $code: $msg")
            }
            return JSONObject(txt)
        } finally {
            conn.disconnect()
        }
    }

    private fun get(url: String, headers: Map<String, String>): JSONObject {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "GET"
            conn.connectTimeout = 20_000
            conn.readTimeout = 60_000
            headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val txt = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val msg = try {
                    JSONObject(txt).getJSONObject("error").getString("message")
                } catch (e: Exception) {
                    txt.take(300)
                }
                throw IOException("HTTP $code: $msg")
            }
            return JSONObject(txt)
        } finally {
            conn.disconnect()
        }
    }

    /** Modelos Gemini disponíveis para a chave (só os de texto que aceitam generateContent). */
    fun listGeminiModels(apiKey: String): List<String> {
        val root = get(
            "https://generativelanguage.googleapis.com/v1beta/models?pageSize=200",
            mapOf("x-goog-api-key" to apiKey)
        )
        val arr = root.optJSONArray("models") ?: return emptyList()
        val skip = Regex("tts|image|live|embedding|audio|robotics|computer-use|veo|imagen|aqa")
        val out = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val name = o.optString("name").removePrefix("models/")
            val methods = o.optJSONArray("supportedGenerationMethods")
            var ok = false
            if (methods != null) {
                for (j in 0 until methods.length()) if (methods.getString(j) == "generateContent") ok = true
            }
            if (ok && name.startsWith("gemini") && !skip.containsMatchIn(name)) out.add(name)
        }
        return out.sortedDescending()
    }

    private fun sendAnthropic(apiKey: String, model: String, system: String, history: List<ChatMsg>): String {
        val msgs = JSONArray()
        history.forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.text)) }
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 4096)
            .put("system", system)
            .put("messages", msgs)
        val root = post(
            "https://api.anthropic.com/v1/messages",
            mapOf("x-api-key" to apiKey, "anthropic-version" to "2023-06-01"),
            body
        )
        val arr = root.getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("type") == "text") sb.append(o.getString("text"))
        }
        return sb.toString()
    }

    private fun sendGemini(apiKey: String, model: String, system: String, history: List<ChatMsg>): String {
        val contents = JSONArray()
        history.forEach {
            contents.put(
                JSONObject()
                    .put("role", if (it.role == "assistant") "model" else "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", it.text)))
            )
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("maxOutputTokens", 8192))
        val m = model.trim().removePrefix("models/")
        val root = try {
            post(
                "https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent",
                mapOf("x-goog-api-key" to apiKey),
                body
            )
        } catch (e: IOException) {
            val msg = e.message ?: ""
            if (msg.contains("404") || msg.contains("not found", ignoreCase = true)) {
                throw IOException(msg + "\n\nEsse modelo não existe mais ou o nome está errado. Em Configurar IA, toque em Buscar modelos e escolha um.")
            }
            if (msg.contains("503") || msg.contains("429") || msg.contains("high demand", ignoreCase = true)) {
                throw IOException(msg + "\n\nO Google está com alta demanda neste modelo (o app já tentou 4 vezes). Tente de novo em alguns minutos ou troque o modelo em Ajustes > Configurar IA > Buscar modelos.")
            }
            throw e
        }
        val cands = root.optJSONArray("candidates")
        if (cands == null || cands.length() == 0) {
            val reason = root.optJSONObject("promptFeedback")?.optString("blockReason")
            throw IOException("Sem resposta da IA" + if (!reason.isNullOrEmpty()) " (bloqueado: $reason)" else "")
        }
        val cand = cands.getJSONObject(0)
        val parts = cand.optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (parts != null) {
            for (i in 0 until parts.length()) {
                val p = parts.getJSONObject(i)
                if (!p.optBoolean("thought", false) && p.has("text")) sb.append(p.getString("text"))
            }
        }
        if (sb.isEmpty()) throw IOException("Resposta vazia (motivo: ${cand.optString("finishReason", "?")})")
        return sb.toString()
    }
}
