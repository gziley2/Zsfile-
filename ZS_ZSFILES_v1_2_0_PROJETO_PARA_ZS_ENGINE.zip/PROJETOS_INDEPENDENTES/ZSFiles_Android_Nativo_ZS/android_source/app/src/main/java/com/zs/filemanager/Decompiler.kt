package com.zs.filemanager

import com.android.tools.smali.baksmali.Baksmali
import com.android.tools.smali.baksmali.BaksmaliOptions
import com.android.tools.smali.dexlib2.DexFileFactory
import com.android.tools.smali.dexlib2.Opcodes
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile

class DecompSummary(val dexFiles: Int, val smaliFiles: Int, val resFiles: Int = 0)

/**
 * Decompila DEX/APK para smali (assembly do Dalvik) com o baksmali.
 * Não gera Java: o smali é exato e é o que a IA lê para reconstruir o comportamento.
 */
object Decompiler {
    private val libPrefixes = listOf(
        "Landroid/", "Landroidx/", "Lkotlin/", "Lkotlinx/", "Lcom/google/", "Lcom/android/", "Lcom/squareup/",
        "Lcom/bumptech/", "Lcom/facebook/", "Lcom/airbnb/", "Lokhttp3/", "Lokio/", "Lretrofit2/", "Lorg/jetbrains/",
        "Lorg/intellij/", "Lorg/apache/", "Lorg/json/", "Lorg/slf4j/", "Lio/reactivex/", "Lio/grpc/", "Ldagger/",
        "Ljavax/", "Ljava/", "Lj$/", "Lbutterknife/", "Lcom/unity3d/", "Lcom/applovin/", "Lcom/ironsource/"
    )

    private val tokens = listOf(
        "Ljava/lang/Runtime;", "Ljava/lang/ProcessBuilder;", "DexClassLoader", "PathClassLoader",
        "InMemoryDexClassLoader", "Ljavax/crypto/Cipher;", "SecretKeySpec", "Landroid/telephony/SmsManager;",
        "TelephonyManager", "HttpURLConnection", "OkHttpClient", "Landroid/webkit/WebView;",
        "addJavascriptInterface", "AccessibilityService", "DevicePolicyManager", "getDeviceId",
        "Landroid/location/LocationManager;", "loadLibrary", "Ljava/lang/reflect/Method;", "http://", "https://"
    )

    private val compTags = setOf("activity", "activity-alias", "service", "receiver", "provider")

    private fun disassemble(dexFile: File, smaliDir: File, appOnly: Boolean) {
        smaliDir.mkdirs()
        val dex = DexFileFactory.loadDexFile(dexFile, Opcodes.forApi(34))
        val classes: List<String>? =
            if (appOnly) dex.classes.map { it.type }.filter { t -> libPrefixes.none { t.startsWith(it) } } else null
        val jobs = Runtime.getRuntime().availableProcessors().coerceIn(1, 4)
        Baksmali.disassembleDexFile(dex, smaliDir, jobs, BaksmaliOptions(), classes)
    }

    /** Decompila para outDir: smali/, smali_classesN/, AndroidManifest.xml decodificado e assets/. */
    /** full = true também copia assets e imagens/binários de res/. */
    fun decompile(src: File, outDir: File, appOnly: Boolean, full: Boolean = true): DecompSummary {
        outDir.mkdirs()
        var dexCount = 0
        var resCount = 0
        if (src.extension.equals("dex", ignoreCase = true)) {
            disassemble(src, File(outDir, "smali"), appOnly)
            dexCount = 1
        } else {
            ZipFile(src).use { zip ->
                val dexRe = Regex("classes\\d*\\.dex")
                val dexes = zip.entries().toList().filter { dexRe.matches(it.name) }
                    .sortedWith(compareBy<ZipEntry>({ it.name.length }, { it.name }))
                dexes.forEachIndexed { i, e ->
                    val tmp = File.createTempFile("zsdex", ".dex")
                    try {
                        zip.getInputStream(e).use { ins -> FileOutputStream(tmp).use { ins.copyTo(it) } }
                        disassemble(tmp, File(outDir, if (i == 0) "smali" else "smali_classes${i + 1}"), appOnly)
                    } finally {
                        tmp.delete()
                    }
                    dexCount++
                }
                val arsc = zip.getEntry("resources.arsc")?.let { e ->
                    try {
                        Arsc.parse(zip.getInputStream(e).use { it.readBytes() })
                    } catch (ex: Exception) {
                        null
                    }
                }
                val resolver: ((Int) -> String?)? = arsc?.let { t -> { id: Int -> t.names[id] } }
                zip.getEntry("AndroidManifest.xml")?.let { m ->
                    val b = zip.getInputStream(m).use { it.readBytes() }
                    val txt = if (Axml.isAxml(b)) Axml.decode(b, resolver) else String(b)
                    File(outDir, "AndroidManifest.xml").writeText(txt)
                }
                val outPath = outDir.canonicalPath
                fun safe(name: String): File? {
                    val o = File(outDir, name)
                    return if (o.canonicalPath.startsWith(outPath + File.separator)) o else null
                }
                // res/**/*.xml binários -> XML legível (layouts, menus, drawables xml...)
                zip.entries().toList()
                    .filter { it.name.startsWith("res/") && !it.isDirectory && it.name.endsWith(".xml") && it.size < 5_000_000 }
                    .forEach { e ->
                        val o = safe(e.name) ?: return@forEach
                        val b = zip.getInputStream(e).use { it.readBytes() }
                        val txt = try {
                            if (Axml.isAxml(b)) Axml.decode(b, resolver) else String(b)
                        } catch (ex: Exception) {
                            return@forEach
                        }
                        o.parentFile?.mkdirs()
                        o.writeText(txt)
                        resCount++
                    }
                // strings.xml, colors.xml, dimens.xml... a partir do resources.arsc
                if (arsc != null) resCount += arsc.writeValues(File(outDir, "res/values"))
                if (full) {
                    zip.entries().toList()
                        .filter { it.name.startsWith("assets/") && !it.isDirectory && it.size < 50_000_000 }
                        .forEach { a ->
                            val o = safe(a.name) ?: return@forEach
                            o.parentFile?.mkdirs()
                            zip.getInputStream(a).use { ins -> FileOutputStream(o).use { ins.copyTo(it) } }
                        }
                    var copied = 0L
                    zip.entries().toList()
                        .filter { it.name.startsWith("res/") && !it.isDirectory && !it.name.endsWith(".xml") && it.size in 1..20_000_000 }
                        .forEach { e ->
                            if (copied + e.size > 200_000_000L) return@forEach
                            val o = safe(e.name) ?: return@forEach
                            o.parentFile?.mkdirs()
                            zip.getInputStream(e).use { ins -> FileOutputStream(o).use { ins.copyTo(it) } }
                            copied += e.size
                            resCount++
                        }
                }
            }
        }
        val n = outDir.walkTopDown().count { it.isFile && it.extension == "smali" }
        return DecompSummary(dexCount, n, resCount)
    }

    private class Comp(val cls: String, val label: String)

    private fun components(manifest: String): List<Comp> {
        val root = try { parseNode(manifest) } catch (e: Exception) { null } ?: return emptyList()
        val pkg = root.attrs["package"] ?: ""
        fun norm(n: String): String = when {
            n.startsWith(".") -> pkg + n
            !n.contains('.') -> "$pkg.$n"
            else -> n
        }
        val out = ArrayList<Comp>()
        val app = root.children.firstOrNull { it.tag == "application" } ?: return out
        app.attrs["android:name"]?.let { out.add(Comp(norm(it), "Application")) }
        for (c in app.children) {
            if (c.tag !in compTags) continue
            val n = c.attrs["android:name"] ?: continue
            val launcher = c.children.any { f ->
                f.tag == "intent-filter" &&
                    f.children.any { a -> a.attrs["android:name"] == "android.intent.category.LAUNCHER" }
            }
            out.add(Comp(norm(n), if (launcher) "Activity LAUNCHER (ponto de entrada)" else c.tag.replaceFirstChar { it.uppercase() }))
        }
        return out
    }

    /** Acrescenta ao contexto o smali das classes mais relevantes, respeitando o orçamento. */
    fun appendSmaliContext(outDir: File, budget: Int, sb: StringBuilder) {
        val roots = (outDir.listFiles() ?: emptyArray<File>()).filter { it.isDirectory && it.name.startsWith("smali") }
        val byClass = HashMap<String, File>()
        for (root in roots) {
            for (f in root.walkTopDown()) {
                if (f.isFile && f.extension == "smali") {
                    byClass[f.relativeTo(root).path.removeSuffix(".smali").replace('/', '.')] = f
                }
            }
        }
        val stringsXml = File(outDir, "res/values/strings.xml")
        if (stringsXml.isFile) {
            sb.appendLine("\n## Strings do app (res/values/strings.xml)")
            sb.appendLine("```")
            sb.appendLine(stringsXml.readText().take(15_000))
            sb.appendLine("```")
        }
        val layoutNames = File(outDir, "res/layout").listFiles()?.map { it.name }?.sorted()
        if (!layoutNames.isNullOrEmpty()) {
            sb.appendLine("\n## Layouts (${layoutNames.size}): " + layoutNames.take(80).joinToString(", "))
        }
        sb.appendLine("\n## Código decompilado (smali)")
        val summaryPos = sb.length

        val ordered = LinkedHashMap<File, String>()
        val manifestFile = File(outDir, "AndroidManifest.xml")
        val comps = if (manifestFile.isFile) components(manifestFile.readText()) else emptyList()
        comps.sortedBy {
            when {
                it.label.startsWith("Application") -> 0
                it.label.contains("LAUNCHER") -> 1
                else -> 2
            }
        }.forEach { c ->
            val f = byClass[c.cls]
            if (f != null && f !in ordered) ordered[f] = c.label
        }

        val scored = ArrayList<Triple<File, Int, List<String>>>()
        var scanned = 0
        for (f in byClass.values) {
            if (scanned >= 8000) break
            if (f in ordered || f.length() > 300_000) continue
            scanned++
            val t = try { f.readText() } catch (e: Exception) { continue }
            val hit = tokens.filter { t.contains(it) }
            if (hit.isNotEmpty()) scored.add(Triple(f, hit.size, hit))
        }
        scored.sortedByDescending { it.second }.take(200).forEach { s ->
            ordered[s.first] = "indicadores: " + s.third.take(5).joinToString(", ")
        }
        byClass.values.sortedBy { it.length() }.forEach { f -> if (f !in ordered) ordered[f] = "classe do app" }

        val included = ArrayList<String>()
        val omittedImportant = ArrayList<String>()
        val limit = budget - 6_000
        for ((f, reason) in ordered) {
            val rel = f.relativeTo(outDir).path
            val approx = minOf(f.length(), 30_000L).toInt()
            if (sb.length + approx + rel.length + reason.length + 30 > limit) {
                if (reason != "classe do app" && omittedImportant.size < 40) omittedImportant.add("$rel [$reason]")
                continue
            }
            val txt = try { f.readText() } catch (e: Exception) { continue }
            val body = if (txt.length > 30_000) txt.take(30_000) + "\n# ...[truncado: ${txt.length} caracteres]" else txt
            sb.appendLine("\n### $rel  [$reason]")
            sb.appendLine("```smali")
            sb.appendLine(body)
            sb.appendLine("```")
            included.add(rel)
        }

        val s = StringBuilder()
        s.appendLine("Classes do app decompiladas: ${byClass.size} · com código enviado: ${included.size} · omitidas: ${ordered.size - included.size}")
        s.appendLine("Prioridade: Application > Activity LAUNCHER > componentes do manifest > classes com indicadores (cripto, rede, execução, SMS, WebView...) > demais por tamanho.")
        if (omittedImportant.isNotEmpty()) {
            s.appendLine("Classes importantes OMITIDAS por limite de tamanho (não conclua nada sobre elas):")
            omittedImportant.forEach { s.appendLine("- $it") }
        }
        sb.insert(summaryPos, s)
    }
}
