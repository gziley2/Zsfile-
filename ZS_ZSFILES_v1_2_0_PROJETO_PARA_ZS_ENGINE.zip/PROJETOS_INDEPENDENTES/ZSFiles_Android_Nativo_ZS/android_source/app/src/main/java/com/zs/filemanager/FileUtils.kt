package com.zs.filemanager

import com.github.junrar.Junrar
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import org.apache.commons.compress.compressors.xz.XZCompressorInputStream
import java.io.BufferedInputStream
import java.io.InputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object FileUtils {
    val archiveExts = setOf("zip", "jar", "apk", "aar", "war", "apks", "xapk")
    val imageExts = setOf("png", "jpg", "jpeg", "gif", "webp", "bmp")
    val textExts = setOf(
        "txt", "md", "kt", "kts", "java", "xml", "json", "html", "htm", "css", "js", "ts", "tsx", "jsx",
        "py", "sh", "gradle", "properties", "yml", "yaml", "smali", "c", "cpp", "h", "hpp", "cs", "lua",
        "sql", "csv", "log", "ini", "cfg", "toml", "rb", "php", "go", "rs", "swift", "dart", "conf", "bat", "pro"
    )

    /** Pastas primeiro; depois por name | date (mais novos primeiro) | size (maiores primeiro). */
    fun list(dir: File, sort: String = "name"): List<File> {
        val files = dir.listFiles() ?: return emptyList()
        val byName = compareBy<File>({ !it.isDirectory }, { it.name.lowercase() })
        val cmp: Comparator<File> = when (sort) {
            "date" -> compareBy<File> { !it.isDirectory }.thenByDescending { it.lastModified() }
            "size" -> compareBy<File> { !it.isDirectory }
                .thenByDescending { if (it.isDirectory) 0L else it.length() }
                .thenBy { it.name.lowercase() }
            else -> byName
        }
        return files.sortedWith(cmp)
    }

    fun uniqueTarget(dir: File, name: String): File {
        var t = File(dir, name)
        if (!t.exists()) return t
        val base = name.substringBeforeLast('.', name)
        val ext = if (name.contains('.')) "." + name.substringAfterLast('.') else ""
        var i = 1
        while (t.exists()) {
            t = File(dir, "$base ($i)$ext")
            i++
        }
        return t
    }

    private fun copyInto(src: File, target: File) {
        if (src.isDirectory) src.copyRecursively(target, overwrite = false) else src.copyTo(target)
    }

    fun copy(src: File, destDir: File): File {
        val t = uniqueTarget(destDir, src.name)
        copyInto(src, t)
        return t
    }

    fun move(src: File, destDir: File): File {
        val t = uniqueTarget(destDir, src.name)
        if (!src.renameTo(t)) {
            copyInto(src, t)
            src.deleteRecursively()
        }
        return t
    }

    fun delete(f: File): Boolean = f.deleteRecursively()

    fun zip(sources: List<File>, out: File) {
        val outPath = out.canonicalPath
        ZipOutputStream(BufferedOutputStream(FileOutputStream(out))).use { zos ->
            fun add(file: File, base: String) {
                if (file.canonicalPath == outPath) return
                val name = if (base.isEmpty()) file.name else "$base/${file.name}"
                if (file.isDirectory) {
                    zos.putNextEntry(ZipEntry("$name/"))
                    zos.closeEntry()
                    file.listFiles()?.forEach { add(it, name) }
                } else {
                    zos.putNextEntry(ZipEntry(name))
                    file.inputStream().use { it.copyTo(zos) }
                    zos.closeEntry()
                }
            }
            sources.forEach { add(it, "") }
        }
    }

    fun unzip(zip: File, destDir: File) {
        destDir.mkdirs()
        val destPath = destDir.canonicalPath
        ZipInputStream(BufferedInputStream(FileInputStream(zip))).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val outFile = File(destDir, entry.name)
                val p = outFile.canonicalPath
                if (p != destPath && !p.startsWith(destPath + File.separator)) {
                    throw IOException("Entrada inválida no zip: ${entry.name}")
                }
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    FileOutputStream(outFile).use { zis.copyTo(it) }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }

    fun readableSize(b: Long): String {
        if (b < 1024) return "$b B"
        val units = arrayOf("KB", "MB", "GB", "TB")
        var v = b.toDouble()
        var i = -1
        do {
            v /= 1024
            i++
        } while (v >= 1024 && i < units.lastIndex)
        return String.format(Locale.getDefault(), "%.1f %s", v, units[i])
    }

    fun isProbablyText(f: File): Boolean {
        if (!f.isFile) return false
        return try {
            f.inputStream().use { s ->
                val buf = ByteArray(4096)
                val n = s.read(buf)
                (0 until maxOf(n, 0)).none { buf[it].toInt() == 0 }
            }
        } catch (e: IOException) {
            false
        }
    }

    // ---------- 7z / RAR / TAR / GZ / BZ2 / XZ ----------
    fun archiveKind(f: File): String? {
        val n = f.name.lowercase()
        return when {
            n.endsWith(".tar.gz") || n.endsWith(".tgz") -> "tgz"
            n.endsWith(".tar.bz2") || n.endsWith(".tbz2") || n.endsWith(".tbz") -> "tbz2"
            n.endsWith(".tar.xz") || n.endsWith(".txz") -> "txz"
            n.endsWith(".tar") -> "tar"
            n.endsWith(".7z") -> "7z"
            n.endsWith(".rar") -> "rar"
            n.endsWith(".gz") -> "gz"
            n.endsWith(".bz2") -> "bz2"
            n.endsWith(".xz") -> "xz"
            f.extension.lowercase() in archiveExts -> "zip"
            else -> null
        }
    }

    private val knownSuffixes = listOf(
        ".tar.gz", ".tar.bz2", ".tar.xz", ".tgz", ".tbz2", ".tbz", ".txz", ".tar", ".7z", ".rar",
        ".gz", ".bz2", ".xz", ".zip", ".jar", ".apk", ".aar", ".war", ".apks", ".xapk"
    )

    /** Nome sem a extensão do compactador (inclui .tar.gz etc.). */
    fun baseName(f: File): String {
        val n = f.name
        val l = n.lowercase()
        for (s in knownSuffixes) {
            if (l.endsWith(s) && n.length > s.length) return n.dropLast(s.length)
        }
        return f.nameWithoutExtension.ifEmpty { n }
    }

    private fun safeOut(dest: File, name: String): File {
        val out = File(dest, name)
        val p = out.canonicalPath
        val d = dest.canonicalPath
        if (p != d && !p.startsWith(d + File.separator)) throw IOException("Entrada inválida: $name")
        return out
    }

    private fun openBuffered(f: File): InputStream = BufferedInputStream(FileInputStream(f))

    private fun extractTar(raw: InputStream, dest: File) {
        TarArchiveInputStream(raw).use { tin ->
            var e = tin.nextTarEntry
            while (e != null) {
                if (e.isDirectory) {
                    safeOut(dest, e.name).mkdirs()
                } else if (e.isFile) {
                    val out = safeOut(dest, e.name)
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { os -> tin.copyTo(os) }
                }
                e = tin.nextTarEntry
            }
        }
    }

    private fun listTar(raw: InputStream): List<Pair<String, Long>> {
        val out = ArrayList<Pair<String, Long>>()
        TarArchiveInputStream(raw).use { tin ->
            var e = tin.nextTarEntry
            while (e != null) {
                out.add(e.name to e.size)
                e = tin.nextTarEntry
            }
        }
        return out
    }

    private fun extract7z(src: File, dest: File) {
        SevenZFile(src).use { sz ->
            val buf = ByteArray(65536)
            var e = sz.nextEntry
            while (e != null) {
                val out = safeOut(dest, e.name)
                if (e.isDirectory) {
                    out.mkdirs()
                } else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { os ->
                        while (true) {
                            val n = sz.read(buf)
                            if (n < 0) break
                            os.write(buf, 0, n)
                        }
                    }
                }
                e = sz.nextEntry
            }
        }
    }

    private fun extractRar(src: File, dest: File) {
        try {
            Junrar.extract(src, dest)
        } catch (e: Exception) {
            if (e.javaClass.simpleName.contains("V5")) {
                throw IOException("RAR5 ainda não é suportado (só RAR 4 ou anterior)")
            }
            throw e
        }
    }

    private fun single(input: InputStream, out: File) {
        input.use { i -> FileOutputStream(out).use { o -> i.copyTo(o) } }
    }

    /** Extrai qualquer formato suportado em destDir. */
    fun extract(src: File, destDir: File) {
        destDir.mkdirs()
        when (archiveKind(src)) {
            "zip" -> unzip(src, destDir)
            "7z" -> extract7z(src, destDir)
            "rar" -> extractRar(src, destDir)
            "tar" -> extractTar(openBuffered(src), destDir)
            "tgz" -> extractTar(GzipCompressorInputStream(openBuffered(src)), destDir)
            "tbz2" -> extractTar(BZip2CompressorInputStream(openBuffered(src)), destDir)
            "txz" -> extractTar(XZCompressorInputStream(openBuffered(src)), destDir)
            "gz" -> single(GzipCompressorInputStream(openBuffered(src)), File(destDir, baseName(src)))
            "bz2" -> single(BZip2CompressorInputStream(openBuffered(src)), File(destDir, baseName(src)))
            "xz" -> single(XZCompressorInputStream(openBuffered(src)), File(destDir, baseName(src)))
            else -> throw IOException("Formato não suportado")
        }
    }

    /** Lista (nome, tamanho) sem extrair; null se o formato não permite listar. */
    fun listArchive(f: File): List<Pair<String, Long>>? = when (archiveKind(f)) {
        "7z" -> SevenZFile(f).use { sz -> sz.entries.map { it.name to it.size } }
        "tar" -> listTar(openBuffered(f))
        "tgz" -> listTar(GzipCompressorInputStream(openBuffered(f)))
        "tbz2" -> listTar(BZip2CompressorInputStream(openBuffered(f)))
        "txz" -> listTar(XZCompressorInputStream(openBuffered(f)))
        else -> null
    }

    fun isApkOrDex(f: File): Boolean = f.isFile && f.extension.lowercase() in setOf("apk", "dex")

    fun isLayoutXml(f: File): Boolean =
        f.extension.equals("xml", ignoreCase = true) && f.parentFile?.name?.startsWith("layout") == true

    fun validName(n: String) = n.isNotEmpty() && !n.contains('/') && n != "." && n != ".."
}
