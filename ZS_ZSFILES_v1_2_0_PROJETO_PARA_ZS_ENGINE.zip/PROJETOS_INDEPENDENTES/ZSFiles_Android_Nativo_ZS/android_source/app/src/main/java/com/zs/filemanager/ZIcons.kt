package com.zs.filemanager

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.outlined.Android
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.Code
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.FolderZip
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.ui.graphics.vector.ImageVector

/** Ícones do app num só lugar. */
object ZIcons {
    val Back: ImageVector = Icons.AutoMirrored.Filled.ArrowBack
    val More: ImageVector = Icons.Filled.MoreVert
    val Close: ImageVector = Icons.Filled.Close
    val Save: ImageVector = Icons.Filled.Save
    val Search: ImageVector = Icons.Filled.Search
    val Eye: ImageVector = Icons.Filled.Visibility
    val Copy: ImageVector = Icons.Filled.ContentCopy
    val Undo: ImageVector = Icons.AutoMirrored.Filled.Undo
    val Redo: ImageVector = Icons.AutoMirrored.Filled.Redo
    val Up: ImageVector = Icons.Filled.ArrowUpward
    val Settings: ImageVector = Icons.Outlined.Settings
    val Folder: ImageVector = Icons.Outlined.Folder
    val File: ImageVector = Icons.Outlined.Description
    val Image: ImageVector = Icons.Outlined.Image
    val Zip: ImageVector = Icons.Outlined.FolderZip
    val Code: ImageVector = Icons.Outlined.Code
    val Android: ImageVector = Icons.Outlined.Android
    val Binary: ImageVector = Icons.Outlined.Memory
    val Layout: ImageVector = Icons.Outlined.Palette
    val Tools: ImageVector = Icons.Outlined.Build
    val Hex: ImageVector = Icons.Outlined.Memory
    val Ai: ImageVector = Icons.Outlined.AutoAwesome
    val Info: ImageVector = Icons.Outlined.Info
    val Send: ImageVector = Icons.AutoMirrored.Filled.Send
    val Stop: ImageVector = Icons.Filled.Stop
}
