@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)

package com.zs.filemanager

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Clipboard(val files: List<File>, val cut: Boolean)

sealed interface FmDialog {
    object NewFolder : FmDialog
    object NewFile : FmDialog
    class Rename(val file: File) : FmDialog
    class Delete(val files: List<File>) : FmDialog
    class Extract(val file: File) : FmDialog
    class Decompile(val file: File) : FmDialog
}

private val dateFmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())

private fun iconFor(f: File): ImageVector {
    if (f.isDirectory) return ZIcons.Folder
    if (FileUtils.isLayoutXml(f)) return ZIcons.Layout
    val e = f.extension.lowercase()
    return when {
        e == "apk" || e == "apks" || e == "xapk" -> ZIcons.Android
        FileUtils.archiveKind(f) != null -> ZIcons.Zip
        e in FileUtils.imageExts -> ZIcons.Image
        e in FileUtils.textExts -> ZIcons.Code
        e == "dex" || e == "so" || e == "bin" -> ZIcons.Binary
        else -> ZIcons.File
    }
}

@Composable
private fun iconTint(f: File): Color {
    val c = MaterialTheme.colorScheme
    if (f.isDirectory) return c.primary
    val e = f.extension.lowercase()
    return when {
        e == "apk" || e == "apks" || e == "xapk" -> c.secondary
        FileUtils.archiveKind(f) != null -> c.tertiary
        e in FileUtils.textExts -> c.secondary
        else -> c.onSurfaceVariant
    }
}

private fun subtitle(f: File): String {
    val d = dateFmt.format(Date(f.lastModified()))
    return if (f.isDirectory) d else "${FileUtils.readableSize(f.length())} · $d"
}

@Composable
private fun Item(label: String, onClick: () -> Unit) =
    DropdownMenuItem(text = { Text(label) }, onClick = onClick)

@Composable
fun InputDialog(title: String, initial: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var value by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value, { value = it }, singleLine = true) },
        confirmButton = { TextButton(onClick = { onConfirm(value.trim()) }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun FileManagerScreen(
    root: File,
    currentPath: String,
    onPathChange: (String) -> Unit,
    clipboard: Clipboard?,
    onClipboardChange: (Clipboard?) -> Unit,
    openTabs: Int,
    onShowEditor: () -> Unit,
    onOpenFile: (File) -> Unit,
    onAnalyze: (File) -> Unit,
    onOpenHex: (File) -> Unit,
    onOpenApkExtractor: () -> Unit,
    onConvertJava: (File) -> Unit,
    onAgent: (File) -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val dir = File(currentPath)
    val canGoUp = dir.absolutePath != root.absolutePath && dir.parentFile != null

    var refresh by remember { mutableIntStateOf(0) }
    var selection by remember { mutableStateOf(setOf<String>()) }
    var menu by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf<FmDialog?>(null) }
    var showAiSettings by remember { mutableStateOf(false) }
    var showHelp by remember { mutableStateOf(false) }
    var showHidden by remember { mutableStateOf(AppPrefs.showHidden(context)) }
    var sortMode by remember { mutableStateOf(AppPrefs.sort(context)) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }

    val files = remember(currentPath, refresh, showHidden, sortMode, query) {
        FileUtils.list(dir, sortMode).filter {
            (showHidden || !it.name.startsWith(".")) &&
                (query.isBlank() || it.name.contains(query, ignoreCase = true))
        }
    }
    val selected = files.filter { it.absolutePath in selection }
    val single = selected.singleOrNull()

    fun toast(m: String) = Toast.makeText(context, m, Toast.LENGTH_SHORT).show()

    LaunchedEffect(currentPath) {
        selection = emptySet()
        query = ""
        searching = false
    }
    BackHandler(enabled = selection.isNotEmpty() || canGoUp) {
        if (selection.isNotEmpty()) selection = emptySet()
        else onPathChange(dir.parent ?: root.absolutePath)
    }

    fun runOp(block: () -> String?) {
        busy = true
        scope.launch {
            val msg = try {
                withContext(Dispatchers.IO) { block() }
            } catch (e: Exception) {
                "Erro: ${e.message}"
            }
            busy = false
            selection = emptySet()
            refresh++
            if (msg != null) toast(msg)
        }
    }

    fun paste() {
        val cb = clipboard ?: return
        if (cb.cut) onClipboardChange(null)
        runOp {
            var n = 0
            cb.files.forEach { f ->
                if (f.isDirectory && dir.canonicalPath.startsWith(f.canonicalPath)) return@forEach
                if (cb.cut && f.parentFile?.canonicalPath == dir.canonicalPath) return@forEach
                if (cb.cut) FileUtils.move(f, dir) else FileUtils.copy(f, dir)
                n++
            }
            "$n item(ns) colado(s)"
        }
    }

    fun zipSelected() {
        val items = selected
        if (items.isEmpty()) return
        val name = if (items.size == 1) items[0].nameWithoutExtension + ".zip" else "arquivos.zip"
        val target = FileUtils.uniqueTarget(dir, name)
        runOp { FileUtils.zip(items, target); "Criado: ${target.name}" }
    }

    fun decompile(f: File, appOnly: Boolean) {
        val dest = FileUtils.uniqueTarget(dir, FileUtils.baseName(f) + "_decompilado")
        runOp {
            val s = Decompiler.decompile(f, dest, appOnly)
            "Decompilado: ${s.smaliFiles} classes e ${s.resFiles} recursos em ${dest.name}"
        }
    }

    fun extract(f: File, intoFolder: Boolean) {
        val dest = if (intoFolder) FileUtils.uniqueTarget(dir, FileUtils.baseName(f)) else dir
        runOp { FileUtils.extract(f, dest); "Extraído em ${dest.name}" }
    }

    Scaffold(
        topBar = {
            if (selection.isEmpty()) {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                if (canGoUp) dir.name else "Armazenamento",
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                dir.absolutePath, fontSize = 11.sp, maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    navigationIcon = {
                        if (canGoUp) IconButton(onClick = { onPathChange(dir.parent ?: root.absolutePath) }) {
                            Icon(ZIcons.Back, contentDescription = "Voltar")
                        }
                    },
                    actions = {
                        if (openTabs > 0) TextButton(onClick = onShowEditor) { Text("Editor ($openTabs)") }
                        Box {
                            IconButton(onClick = { menu = true }) { Icon(ZIcons.More, contentDescription = "Mais opções") }
                            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                Item("Nova pasta") { menu = false; dialog = FmDialog.NewFolder }
                                Item("Novo arquivo") { menu = false; dialog = FmDialog.NewFile }
                                Item("Atualizar") { menu = false; refresh++ }
                                Item("Buscar nesta pasta") { menu = false; searching = !searching; if (!searching) query = "" }
                                Item(if (showHidden) "Ocultar arquivos ocultos" else "Mostrar arquivos ocultos") {
                                    menu = false
                                    showHidden = !showHidden
                                    AppPrefs.setShowHidden(context, showHidden)
                                }
                                Item("Ordenar por nome") { menu = false; sortMode = "name"; AppPrefs.setSort(context, "name") }
                                Item("Ordenar por data") { menu = false; sortMode = "date"; AppPrefs.setSort(context, "date") }
                                Item("Ordenar por tamanho") { menu = false; sortMode = "size"; AppPrefs.setSort(context, "size") }
                                Item("Extrator de APK") { menu = false; onOpenApkExtractor() }
                                Item("Configurar IA (chave da API)") { menu = false; showAiSettings = true }
                                Item("Ajuda") { menu = false; showHelp = true }
                            }
                        }
                    }
                )
            } else {
                TopAppBar(
                    title = { Text("${selection.size} selecionado(s)") },
                    navigationIcon = {
                        IconButton(onClick = { selection = emptySet() }) { Icon(ZIcons.Close, contentDescription = "Cancelar seleção") }
                    },
                    actions = {
                        Box {
                            IconButton(onClick = { menu = true }) { Icon(ZIcons.More, contentDescription = "Mais opções") }
                            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                                Item("Copiar") {
                                    menu = false
                                    onClipboardChange(Clipboard(selected, false)); selection = emptySet()
                                }
                                Item("Cortar") {
                                    menu = false
                                    onClipboardChange(Clipboard(selected, true)); selection = emptySet()
                                }
                                Item("Compactar (ZIP)") { menu = false; zipSelected() }
                                Item("Excluir") { menu = false; dialog = FmDialog.Delete(selected) }
                                if (single != null) Item("Renomear") { menu = false; dialog = FmDialog.Rename(single) }
                                if (single != null && single.isFile &&
                                    FileUtils.archiveKind(single) != null
                                ) Item("Extrair…") { menu = false; dialog = FmDialog.Extract(single) }
                                if (single != null && single.isFile) Item("Abrir no editor") {
                                    menu = false; selection = emptySet(); onOpenFile(single)
                                }
                                if (single != null && single.isFile) Item("Abrir no hex") {
                                    menu = false; selection = emptySet(); onOpenHex(single)
                                }
                                if (single != null && single.isFile && single.extension.equals("smali", ignoreCase = true)) Item("Converter para Java (IA)") {
                                    menu = false; selection = emptySet(); onConvertJava(single)
                                }
                                if (single != null && FileUtils.isApkOrDex(single)) Item("Decompilar (smali)") {
                                    menu = false; dialog = FmDialog.Decompile(single)
                                }
                                if (single != null && single.isDirectory) Item("Assistente de projeto (IA)") {
                                    menu = false; selection = emptySet(); onAgent(single)
                                }
                                if (single != null) Item("Analisar com IA") {
                                    menu = false; selection = emptySet(); onAnalyze(single)
                                }
                                Item("Selecionar tudo") {
                                    menu = false; selection = files.map { it.absolutePath }.toSet()
                                }
                            }
                        }
                    }
                )
            }
        },
        bottomBar = {
            if (clipboard != null) {
                Surface(tonalElevation = 3.dp) {
                    Row(
                        Modifier.fillMaxWidth().padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "${clipboard.files.size} item(ns) · ${if (clipboard.cut) "mover" else "copiar"}",
                            Modifier.weight(1f)
                        )
                        TextButton(onClick = { onClipboardChange(null) }) { Text("Limpar") }
                        Button(onClick = { paste() }) { Text("Colar aqui") }
                    }
                }
            }
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            if (searching) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
                    singleLine = true,
                    placeholder = { Text("Buscar nesta pasta") },
                    leadingIcon = { Icon(ZIcons.Search, contentDescription = null) },
                    trailingIcon = {
                        IconButton(onClick = { searching = false; query = "" }) {
                            Icon(ZIcons.Close, contentDescription = "Fechar busca")
                        }
                    }
                )
            }
            if (!searching && dir.absolutePath == root.absolutePath) {
                val shortcuts = remember {
                    listOf("Download", "DCIM", "Documents", "Pictures", "Movies", "Music")
                        .map { File(root, it) }.filter { it.isDirectory }
                }
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(shortcuts, key = { it.absolutePath }) { s ->
                        AssistChip(
                            onClick = { onPathChange(s.absolutePath) },
                            label = { Text(s.name) },
                            leadingIcon = { Icon(ZIcons.Folder, contentDescription = null, modifier = Modifier.size(18.dp)) }
                        )
                    }
                }
            }
            if (files.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Pasta vazia", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            LazyColumn(Modifier.fillMaxSize()) {
                items(files, key = { it.absolutePath }) { f ->
                    val isSel = f.absolutePath in selection
                    Row(
                        Modifier.fillMaxWidth()
                            .background(if (isSel) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                            .combinedClickable(
                                onClick = {
                                    when {
                                        selection.isNotEmpty() ->
                                            selection = if (isSel) selection - f.absolutePath else selection + f.absolutePath
                                        f.isDirectory -> onPathChange(f.absolutePath)
                                        FileUtils.archiveKind(f) != null -> dialog = FmDialog.Extract(f)
                                        else -> onOpenFile(f)
                                    }
                                },
                                onLongClick = { selection = selection + f.absolutePath }
                            )
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(iconFor(f), contentDescription = null, tint = iconTint(f), modifier = Modifier.size(28.dp))
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                subtitle(f), fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }

    if (showAiSettings) AiSettingsDialog { showAiSettings = false }
    if (showHelp) {
        AlertDialog(
            onDismissRequest = { showHelp = false },
            title = { Text("Como usar") },
            text = {
                Text(
                    "• Segure o dedo em um arquivo ou pasta para selecionar. O menu ⋮ do topo muda e mostra as ações: " +
                        "copiar, cortar, compactar, excluir, renomear, abrir no hex, decompilar APK e analisar com IA.\n\n" +
                        "• Toque em um arquivo de texto ou código para abrir no editor (abas, busca, desfazer). " +
                        "Em layouts XML, o botão do olho mostra a prévia.\n\n" +
                        "• Toque em um arquivo binário para ver em hexadecimal, ou em .zip/.7z/.rar para extrair.\n\n" +
                        "• IA: selecione um arquivo ou pasta > ⋮ > Analisar com IA. " +
                        "A chave da API fica no menu ⋮ desta tela > Configurar IA (chave da API).",
                    fontSize = 14.sp
                )
            },
            confirmButton = { TextButton(onClick = { showHelp = false }) { Text("OK") } }
        )
    }

    when (val d = dialog) {
        null -> {}
        is FmDialog.NewFolder -> InputDialog("Nova pasta", "", { dialog = null }) { name ->
            dialog = null
            val f = File(dir, name)
            when {
                !FileUtils.validName(name) -> toast("Nome inválido")
                f.exists() -> toast("Já existe")
                f.mkdirs() -> refresh++
                else -> toast("Não foi possível criar")
            }
        }
        is FmDialog.NewFile -> InputDialog("Novo arquivo", "", { dialog = null }) { name ->
            dialog = null
            val f = File(dir, name)
            when {
                !FileUtils.validName(name) -> toast("Nome inválido")
                f.exists() -> toast("Já existe")
                else -> try {
                    f.createNewFile(); refresh++; onOpenFile(f)
                } catch (e: Exception) {
                    toast("Erro: ${e.message}")
                }
            }
        }
        is FmDialog.Rename -> InputDialog("Renomear", d.file.name, { dialog = null }) { name ->
            dialog = null
            val target = File(d.file.parentFile, name)
            when {
                !FileUtils.validName(name) -> toast("Nome inválido")
                target.exists() -> toast("Já existe")
                d.file.renameTo(target) -> { selection = emptySet(); refresh++ }
                else -> toast("Não foi possível renomear")
            }
        }
        is FmDialog.Delete -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Excluir") },
            text = {
                Text(
                    if (d.files.size == 1) "Excluir \"${d.files[0].name}\"?"
                    else "Excluir ${d.files.size} itens?"
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    dialog = null
                    runOp { d.files.forEach { FileUtils.delete(it) }; "Excluído" }
                }) { Text("Excluir") }
            },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("Cancelar") } }
        )
        is FmDialog.Decompile -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Decompilar para smali") },
            text = {
                Text(
                    "${d.file.name}\n\nA saída vai para uma pasta ao lado do arquivo (smali, manifest decodificado e assets). " +
                        "\"Só app\" ignora bibliotecas conhecidas: mais rápido e menor. Em APKs grandes pode levar alguns minutos."
                )
            },
            confirmButton = {
                TextButton(onClick = { dialog = null; decompile(d.file, true) }) { Text("Só app") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { dialog = null; decompile(d.file, false) }) { Text("Tudo") }
                    TextButton(onClick = { dialog = null }) { Text("Cancelar") }
                }
            }
        )
        is FmDialog.Extract -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Extrair") },
            text = { Text(d.file.name) },
            confirmButton = {
                TextButton(onClick = { dialog = null; extract(d.file, true) }) { Text("Em pasta") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { dialog = null; extract(d.file, false) }) { Text("Aqui") }
                    TextButton(onClick = { dialog = null }) { Text("Cancelar") }
                }
            }
        )
    }
}
