package com.zs.filemanager

import android.content.Context

object AppPrefs {
    private fun p(c: Context) = c.getSharedPreferences("zsfiles", Context.MODE_PRIVATE)

    fun theme(c: Context): String = p(c).getString("theme", "system") ?: "system"
    fun setTheme(c: Context, v: String) {
        p(c).edit().putString("theme", v).apply()
    }

    fun showHidden(c: Context): Boolean = p(c).getBoolean("show_hidden", false)
    fun setShowHidden(c: Context, v: Boolean) {
        p(c).edit().putBoolean("show_hidden", v).apply()
    }

    /** name | date | size */
    fun sort(c: Context): String = p(c).getString("sort", "name") ?: "name"
    fun setSort(c: Context, v: String) {
        p(c).edit().putString("sort", v).apply()
    }
}
