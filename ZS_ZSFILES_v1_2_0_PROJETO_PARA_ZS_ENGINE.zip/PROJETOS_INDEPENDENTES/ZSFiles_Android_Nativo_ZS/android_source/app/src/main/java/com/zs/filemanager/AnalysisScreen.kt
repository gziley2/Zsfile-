@file:OptIn(ExperimentalMaterial3Api::class)

package com.zs.filemanager

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class AnalyzeRequest(val file: File, val textOverride: String?, val initialPrompt: String? = null)

const val PROMPT_SMALI_TO_JAVA =
    "Converta esta classe smali (Dalvik) em Java legível. Reconstrua nomes de variáveis e de métodos auxiliares " +
        "a partir do uso, mantenha a lógica fiel ao smali, comente os trechos pouco óbvios e liste no final as " +
        "dúvidas e pontos incertos. Não invente código que não esteja no smali."

private val QUICK = listOf(
    "Visão geral" to "Faça uma visão geral: o que é este arquivo/app, o que faz, tecnologias usadas e arquitetura provável.",
    "Riscos e comportamentos suspeitos" to "Analise riscos de segurança e comportamentos suspeitos. Classifique por severidade e diga o que verificar a seguir.",
    "Permissões e componentes" to "Explique as permissões e os componentes (activities, services, receivers, providers) e se fazem sentido para o propósito do app.",
    "Strings, URLs e indicadores" to "Analise as strings, URLs e indicadores encontrados e explique o que revelam sobre o funcionamento.",
    "Explicar o código" to "Explique o código passo a passo, aponte bugs e possíveis melhorias.",
    "Reconstruir Java do ponto de entrada" to "Converta o smali da classe Application e da Activity inicial em Java/Kotlin legível (pseudo-código) e explique o fluxo de execução.",
    "Procurar chaves, endpoints e segredos" to "Procure no contexto chaves de API, tokens, endpoints, URLs, credenciais embutidas e uso de criptografia. Para cada achado, cite o arquivo/classe e avalie o risco."
)

/** Markdown mínimo: títulos, **negrito**, `código`, listas e blocos ```. */
internal fun md(src: String): AnnotatedString = buildAnnotatedString {
    var inFence = false
    val inline = Regex("\\*\\*(.+?)\\*\\*|`([^`]+)`")
    val codeBg = Color(0x22888888)
    src.lines().forEachIndexed { i, raw ->
        if (i > 0) append("\n")
        val t = raw.trimStart()
        if (t.startsWith("```")) {
            inFence = !inFence
            return@forEachIndexed
        }
        if (inFence) {
            withStyle(SpanStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, background = codeBg)) { append(raw) }
            return@forEachIndexed
        }
        if (t.startsWith("#")) {
            withStyle(SpanStyle(fontWeight = FontWeight.Bold, fontSize = 16.sp)) { append(t.trimStart('#').trim()) }
            return@forEachIndexed
        }
        val line = if (t.startsWith("- ") || t.startsWith("* ")) "• " + t.drop(2) else raw
        var last = 0
        for (m in inline.findAll(line)) {
            append(line.substring(last, m.range.first))
            if (m.groups[1] != null) {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(m.groupValues[1]) }
            } else {
                withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = codeBg)) { append(m.groupValues[2]) }
            }
            last = m.range.last + 1
        }
        append(line.substring(last))
    }
}

@Composable
internal fun Bubble(m: AiClient.ChatMsg) {
    val isUser = m.role == "user"
    Box(
        Modifier.fillMaxWidth(),
        contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        Surface(
            color = if (isUser) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
            shape = RoundedCornerShape(12.dp)
        ) {
            SelectionContainer {
                if (isUser) Text(m.shown, Modifier.padding(12.dp), fontSize = 14.sp)
                else Text(md(m.text), Modifier.padding(12.dp), fontSize = 14.sp)
            }
        }
    }
}

@Composable
fun AnalysisScreen(file: File, textOverride: String?, initialPrompt: String? = null, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var ctxText by remember { mutableStateOf<String?>(null) }
    val chat = remember { mutableStateListOf<AiClient.ChatMsg>() }
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    var showContext by remember { mutableStateOf(false) }
    var decompiling by remember { mutableStateOf(false) }

    fun toast(m: String) = Toast.makeText(context, m, Toast.LENGTH_SHORT).show()

    val budget = if (AiSettings.provider(context) == AiSettings.GEMINI) 350_000 else 120_000
    LaunchedEffect(file) {
        ctxText = withContext(Dispatchers.IO) {
            try {
                Analyzer.buildContext(file, textOverride, budget)
            } catch (e: Exception) {
                "Erro ao extrair informações: ${e.message}"
            }
        }
    }

    fun send(request: String) {
        val c = ctxText ?: return
        if (request.isBlank() || loading) return
        val provider = AiSettings.provider(context)
        val key = AiSettings.apiKey(context, provider)
        if (key.isBlank()) {
            showSettings = true
            return
        }
        error = null
        val first = chat.isEmpty()
        chat.add(
            if (first) AiClient.ChatMsg("user", AiClient.firstMessage(file.name, c, request), request)
            else AiClient.ChatMsg("user", request)
        )
        input = ""
        loading = true
        val history = chat.toList()
        val model = AiSettings.model(context, provider)
        scope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) { AiClient.send(provider, key, model, AiClient.SYSTEM, history) }
            }
            loading = false
            val reply = result.getOrNull()
            if (reply != null) {
                chat.add(AiClient.ChatMsg("assistant", reply))
            } else {
                chat.removeAt(chat.lastIndex)
                error = result.exceptionOrNull()?.message ?: "Erro desconhecido"
                input = request
            }
        }
    }

    fun decompileAndLoad() {
        if (decompiling) return
        decompiling = true
        error = null
        scope.launch {
            val r = runCatching {
                withContext(Dispatchers.IO) {
                    Analyzer.buildApkWithSmali(file, budget, File(context.cacheDir, "decomp"))
                }
            }
            decompiling = false
            val txt = r.getOrNull()
            if (txt != null) {
                ctxText = txt
                toast("Código decompilado incluído no contexto")
            } else {
                error = "Falha ao decompilar: " + (r.exceptionOrNull()?.message ?: "erro desconhecido")
            }
        }
    }

    var autoSent by remember { mutableStateOf(false) }
    LaunchedEffect(ctxText) {
        val p = initialPrompt
        if (p != null && ctxText != null && !autoSent && chat.isEmpty()) {
            autoSent = true
            if (AiSettings.apiKey(context, AiSettings.provider(context)).isBlank()) {
                input = p
                showSettings = true
            } else {
                send(p)
            }
        }
    }

    fun saveChat() {
        if (chat.isEmpty()) {
            toast("Nada para salvar")
            return
        }
        val folder = if (file.isDirectory) file else (file.parentFile ?: file)
        val out = FileUtils.uniqueTarget(folder, file.nameWithoutExtension + "_analise.md")
        val body = "# Análise: ${file.name}\n\n" + chat.joinToString("\n\n") {
            if (it.role == "user") "**Você:** ${it.shown}" else it.text
        }
        try {
            out.writeText(body)
            toast("Salvo: ${out.name}")
        } catch (e: Exception) {
            toast("Erro: ${e.message}")
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Análise com IA", fontSize = 16.sp)
                        Text(
                            file.name, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = { IconButton(onClick = onBack) { Icon(ZIcons.Back, contentDescription = "Voltar") } },
                actions = {
                    IconButton(onClick = { showContext = !showContext }) { Icon(ZIcons.Copy, contentDescription = "Ver contexto") }
                    IconButton(onClick = { saveChat() }) { Icon(ZIcons.Save, contentDescription = "Salvar") }
                    IconButton(onClick = { showSettings = true }) { Icon(ZIcons.Settings, contentDescription = "Configurar IA") }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            val c = ctxText
            if (c == null) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Text("Extraindo informações do arquivo…", Modifier.padding(16.dp))
            } else if (showContext) {
                Box(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(12.dp)) {
                    SelectionContainer { Text(c, fontFamily = FontFamily.Monospace, fontSize = 11.sp) }
                }
            } else {
                val listState = rememberLazyListState()
                LaunchedEffect(chat.size, loading) {
                    val total = listState.layoutInfo.totalItemsCount
                    if (chat.isNotEmpty() && total > 0) listState.animateScrollToItem(total - 1)
                }
                LazyColumn(
                    Modifier.weight(1f).fillMaxWidth(),
                    state = listState,
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (chat.isEmpty()) {
                        item {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Contexto extraído: ${c.length} caracteres (toque em 📋 para ver).")
                                Text(
                                    "Ao analisar, esse contexto é enviado para a API de IA configurada (Gemini ou Claude). " +
                                        "Escolha um tipo de análise ou escreva sua pergunta abaixo.",
                                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                if (AiSettings.apiKey(context, AiSettings.provider(context)).isBlank()) {
                                    Text(
                                        "⚙ Configure sua chave de API para começar.",
                                        fontSize = 12.sp, color = MaterialTheme.colorScheme.error
                                    )
                                }
                                if (FileUtils.isApkOrDex(file)) {
                                    OutlinedButton(
                                        onClick = { decompileAndLoad() },
                                        enabled = !decompiling,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            if (decompiling) "Decompilando… (pode levar alguns minutos)"
                                            else "🧩 Decompilar e incluir código (smali)"
                                        )
                                    }
                                }
                                QUICK.forEach { (label, prompt) ->
                                    OutlinedButton(onClick = { send(prompt) }, modifier = Modifier.fillMaxWidth()) {
                                        Text(label)
                                    }
                                }
                            }
                        }
                    }
                    items(chat) { m -> Bubble(m) }
                    if (loading) {
                        item {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                                Spacer(Modifier.width(10.dp))
                                Text("Analisando…")
                            }
                        }
                    }
                    val err = error
                    if (err != null) {
                        item { Text("⚠ $err", color = MaterialTheme.colorScheme.error, fontSize = 13.sp) }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.Bottom) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = {
                            Text(if (chat.isEmpty()) "Pergunte algo ou escolha acima…" else "Pergunta de acompanhamento…")
                        },
                        maxLines = 4
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = { send(input) }, enabled = !loading && input.isNotBlank()) { Text("➤") }
                }
            }
        }
    }

    if (showSettings) AiSettingsDialog { showSettings = false }
}

@Composable
fun AiSettingsDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var provider by remember { mutableStateOf(AiSettings.provider(context)) }
    var key by remember { mutableStateOf(AiSettings.apiKey(context, AiSettings.provider(context))) }
    var model by remember { mutableStateOf(AiSettings.model(context, AiSettings.provider(context))) }
    var models by remember { mutableStateOf<List<String>>(emptyList()) }
    var loadingModels by remember { mutableStateOf(false) }
    var modelsError by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Configurar IA") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    listOf(AiSettings.GEMINI to "Gemini", AiSettings.ANTHROPIC to "Claude").forEach { (id, label) ->
                        RadioButton(
                            selected = provider == id,
                            onClick = {
                                provider = id
                                key = AiSettings.apiKey(context, id)
                                model = AiSettings.model(context, id)
                                models = emptyList()
                                modelsError = null
                            }
                        )
                        Text(label, Modifier.padding(end = 12.dp))
                    }
                }
                Text(
                    if (provider == AiSettings.GEMINI) "Chave do Google AI Studio (Gemini). Fica salva só neste aparelho."
                    else "Chave da API da Anthropic. Fica salva só neste aparelho.",
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    key, { key = it }, label = { Text("API key") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(model, { model = it }, label = { Text("Modelo") }, singleLine = true)
                if (provider == AiSettings.GEMINI) {
                    Text(
                        "Padrão: gemini-flash-latest (sempre o Flash mais novo). Se der erro de modelo, busque a lista abaixo.",
                        fontSize = 11.sp
                    )
                    TextButton(
                        onClick = {
                            if (key.isBlank()) {
                                modelsError = "Cole a chave primeiro."
                            } else {
                                loadingModels = true
                                modelsError = null
                                scope.launch {
                                    val r = runCatching {
                                        withContext(Dispatchers.IO) { AiClient.listGeminiModels(key.trim()) }
                                    }
                                    loadingModels = false
                                    val list = r.getOrNull()
                                    if (list == null) {
                                        modelsError = r.exceptionOrNull()?.message ?: "Erro ao buscar"
                                    } else if (list.isEmpty()) {
                                        modelsError = "Nenhum modelo encontrado."
                                    } else {
                                        models = list
                                    }
                                }
                            }
                        },
                        enabled = !loadingModels
                    ) { Text(if (loadingModels) "Buscando…" else "Buscar modelos") }
                    modelsError?.let { Text(it, fontSize = 12.sp, color = MaterialTheme.colorScheme.error) }
                    models.take(15).forEach { m ->
                        TextButton(onClick = { model = m }) { Text(m, fontSize = 12.sp) }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                AiSettings.save(context, provider, key.trim(), model.trim())
                onDismiss()
            }) { Text("Salvar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
