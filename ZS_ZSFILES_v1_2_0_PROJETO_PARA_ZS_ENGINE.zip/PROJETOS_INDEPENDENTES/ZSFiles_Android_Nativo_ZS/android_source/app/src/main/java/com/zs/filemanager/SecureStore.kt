package com.zs.filemanager

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Criptografa a chave de API com uma chave guardada no Android Keystore (AES-GCM).
 * Se o aparelho não suportar, cai para texto simples (como era antes).
 */
object SecureStore {
    private const val ALIAS = "zsfiles_key_v1"
    private const val PREFIXO = "enc:"

    private fun chave(): SecretKey? = try {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey) ?: run {
            val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
            g.init(
                KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build()
            )
            g.generateKey()
        }
    } catch (e: Exception) {
        null
    }

    fun encrypt(plain: String): String {
        if (plain.isEmpty()) return ""
        val k = chave() ?: return plain
        return try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.ENCRYPT_MODE, k)
            val dados = c.doFinal(plain.toByteArray(Charsets.UTF_8))
            PREFIXO + Base64.encodeToString(c.iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(dados, Base64.NO_WRAP)
        } catch (e: Exception) {
            plain
        }
    }

    /** Aceita valores antigos em texto simples (sem o prefixo) e devolve como estão. */
    fun decrypt(guardado: String): String {
        if (!guardado.startsWith(PREFIXO)) return guardado
        return try {
            val partes = guardado.split(":")
            if (partes.size != 3) return ""
            val k = chave() ?: return ""
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, k, GCMParameterSpec(128, Base64.decode(partes[1], Base64.NO_WRAP)))
            String(c.doFinal(Base64.decode(partes[2], Base64.NO_WRAP)), Charsets.UTF_8)
        } catch (e: Exception) {
            ""
        }
    }

    fun isEncrypted(guardado: String) = guardado.startsWith(PREFIXO)
}
