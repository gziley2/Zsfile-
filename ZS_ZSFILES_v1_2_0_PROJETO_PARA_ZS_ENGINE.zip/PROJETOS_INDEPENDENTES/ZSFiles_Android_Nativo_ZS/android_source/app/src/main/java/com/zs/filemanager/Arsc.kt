package com.zs.filemanager

import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

class ResValue(val type: Int, val data: Int)

/** Tabela de recursos (resources.arsc): nomes dos IDs e valores simples do config padrão. */
class ArscTable(
    val names: Map<Int, String>,
    val values: Map<Int, ResValue>,
    private val globalStrings: List<String>
) {
    fun formatValue(v: ResValue): String? = when (v.type) {
        0x03 -> globalStrings.getOrNull(v.data)
        0x1c -> String.format("#%08x", v.data)
        0x1d -> String.format("#%06x", v.data and 0xFFFFFF)
        0x12 -> if (v.data != 0) "true" else "false"
        0x10 -> v.data.toString()
        0x11 -> "0x" + Integer.toHexString(v.data)
        0x05 -> Axml.dimension(v.data)
        0x06 -> Axml.fraction(v.data)
        0x04 -> java.lang.Float.intBitsToFloat(v.data).toString()
        0x01 -> names[v.data]?.let { "@$it" } ?: ("@0x" + Integer.toHexString(v.data))
        else -> null
    }

    private fun esc(s: String, isString: Boolean): String {
        var r = s.replace("&", "&amp;").replace("<", "&lt;")
        if (isString) r = r.replace("'", "\\'").replace("\n", "\\n")
        return r
    }

    /** Gera strings.xml, colors.xml, dimens.xml, integers.xml, bools.xml e ids.xml. Retorna quantos arquivos. */
    fun writeValues(dir: File): Int {
        val files = linkedMapOf(
            "string" to "strings.xml", "color" to "colors.xml", "dimen" to "dimens.xml",
            "integer" to "integers.xml", "bool" to "bools.xml", "id" to "ids.xml"
        )
        val bodies = HashMap<String, StringBuilder>()
        for ((id, nm) in names.toSortedMap()) {
            val type = nm.substringBefore('/')
            val name = nm.substringAfter('/')
            if (type !in files) continue
            val sb = bodies.getOrPut(type) { StringBuilder() }
            if (type == "id") {
                sb.append("    <item name=\"").append(name).append("\" type=\"id\" />\n")
                continue
            }
            val raw = values[id] ?: continue
            val v = formatValue(raw) ?: continue
            sb.append("    <").append(type).append(" name=\"").append(name).append("\">")
                .append(esc(v, type == "string")).append("</").append(type).append(">\n")
        }
        var written = 0
        for ((type, fileName) in files) {
            val body = bodies[type] ?: continue
            if (body.isEmpty()) continue
            dir.mkdirs()
            File(dir, fileName).writeText("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<resources>\n$body</resources>\n")
            written++
        }
        return written
    }
}

object Arsc {
    private fun u16(bb: ByteBuffer, p: Int) = bb.getShort(p).toInt() and 0xFFFF

    fun parse(data: ByteArray): ArscTable {
        val bb = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        if (u16(bb, 0) != 0x0002) throw IllegalArgumentException("não é um resources.arsc")
        var pos = u16(bb, 2)
        val tableSize = minOf(bb.getInt(4), data.size)
        var global: List<String> = emptyList()
        val names = HashMap<Int, String>()
        val values = HashMap<Int, ResValue>()
        val defaults = HashSet<Int>()
        while (pos + 8 <= tableSize) {
            val type = u16(bb, pos)
            val size = bb.getInt(pos + 4)
            if (size <= 0 || pos + size > data.size) break
            when (type) {
                0x0001 -> if (global.isEmpty()) global = Axml.readStringPool(bb, pos)
                0x0200 -> readPackage(bb, pos, size, names, values, defaults)
            }
            pos += size
        }
        return ArscTable(names, values, global)
    }

    private fun readPackage(
        bb: ByteBuffer, pkgPos: Int, pkgSize: Int,
        names: HashMap<Int, String>, values: HashMap<Int, ResValue>, defaults: HashSet<Int>
    ) {
        val hdr = u16(bb, pkgPos + 2)
        val pkgId = bb.getInt(pkgPos + 8)
        val typeNames = Axml.readStringPool(bb, pkgPos + bb.getInt(pkgPos + 268))
        val keyNames = Axml.readStringPool(bb, pkgPos + bb.getInt(pkgPos + 276))
        var pos = pkgPos + hdr
        val end = pkgPos + pkgSize
        while (pos + 8 <= end) {
            val type = u16(bb, pos)
            val size = bb.getInt(pos + 4)
            if (size <= 0 || pos + size > end) break
            if (type == 0x0201) readType(bb, pos, size, pkgId, typeNames, keyNames, names, values, defaults)
            pos += size
        }
    }

    private fun isDefaultConfig(bb: ByteBuffer, cfgPos: Int, cfgSize: Int): Boolean {
        if (cfgSize < 4 || cfgSize > 128) return false
        for (i in 4 until cfgSize) if (bb.get(cfgPos + i).toInt() != 0) return false
        return true
    }

    private fun readType(
        bb: ByteBuffer, pos: Int, size: Int, pkgId: Int, typeNames: List<String>, keyNames: List<String>,
        names: HashMap<Int, String>, values: HashMap<Int, ResValue>, defaults: HashSet<Int>
    ) {
        val hdr = u16(bb, pos + 2)
        val typeId = bb.get(pos + 8).toInt() and 0xFF
        val flags = bb.get(pos + 9).toInt() and 0xFF
        val entryCount = bb.getInt(pos + 12)
        val entriesStart = bb.getInt(pos + 16)
        val isDefault = isDefaultConfig(bb, pos + 20, bb.getInt(pos + 20))
        val typeName = typeNames.getOrNull(typeId - 1) ?: "type$typeId"
        val sparse = (flags and 0x01) != 0
        val off16 = (flags and 0x02) != 0
        val limit = pos + size
        for (i in 0 until entryCount) {
            val entryIdx: Int
            val entryOff: Int
            if (sparse) {
                val v = bb.getInt(pos + hdr + i * 4)
                entryIdx = v and 0xFFFF
                entryOff = ((v ushr 16) and 0xFFFF) * 4
            } else if (off16) {
                val o = u16(bb, pos + hdr + i * 2)
                if (o == 0xFFFF) continue
                entryIdx = i
                entryOff = o * 4
            } else {
                val o = bb.getInt(pos + hdr + i * 4)
                if (o == -1) continue
                entryIdx = i
                entryOff = o
            }
            val ep = pos + entriesStart + entryOff
            if (ep < 0 || ep + 8 > limit) continue
            val eFlags = u16(bb, ep + 2)
            val keyIdx = bb.getInt(ep + 4)
            val keyName = keyNames.getOrNull(keyIdx) ?: continue
            val resId = (pkgId shl 24) or (typeId shl 16) or entryIdx
            names.putIfAbsent(resId, "$typeName/$keyName")
            if ((eFlags and 0x0001) == 0 && ep + 16 <= limit) {
                val v = ResValue(bb.get(ep + 11).toInt() and 0xFF, bb.getInt(ep + 12))
                if (isDefault) {
                    values[resId] = v
                    defaults.add(resId)
                } else if (!values.containsKey(resId)) {
                    values[resId] = v
                }
            }
        }
    }
}
