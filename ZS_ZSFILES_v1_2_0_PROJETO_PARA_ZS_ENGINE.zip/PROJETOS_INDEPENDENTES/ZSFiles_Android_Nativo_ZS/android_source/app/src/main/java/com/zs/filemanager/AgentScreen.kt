@file:OptIn(ExperimentalMaterial3Api::class)

package com.zs.filemanager

import android.util.Base64
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
private fun DiffView(linhas: List<DiffLine>) {
    val verde = Color(0xFF2E7D32)
    val vermelho = Color(0xFFC62828)
    Column(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 4.dp)) {
        linhas.take(300).forEach { l ->
            val cor = when (l.kind) {
                '+' -> verde
                '-' -> vermelho
                else -> MaterialTheme.colorScheme.onSurfaceVariant
            }
            val fundo = when (l.kind) {
                '+' -> verde.copy(alpha = 0.12f)
                '-' -> vermelho.copy(alpha = 0.12f)
                else -> Color.Transparent
            }
            Text(
                (if (l.kind == '~') " " else l.kind.toString()) + " " + l.text,
                color = cor, fontFamily = FontFamily.Monospace, fontSize = 11.sp, softWrap = false,
                modifier = Modifier.background(fundo)
            )
        }
        if (linhas.size > 300) {
            Text("… mais ${linhas.size - 300} linhas (abra o arquivo para ver tudo)", fontSize = 11.sp)
        }
    }
}

@Composable
fun AgentScreen(
    session: AgentSession,
    onBack: () -> Unit,
    onOpenFile: (File) -> Unit,
    onBeforeRun: () -> Unit,
    onFilesChanged: (List<File>) -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }
    var planMode by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showInst by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    var image by remember { mutableStateOf<AgentRunner.Anexo?>(null) }
    var expandidos by remember { mutableStateOf(setOf<String>()) }
    var stats by remember { mutableStateOf<Map<String, Pair<Int, Int>>>(emptyMap()) }
    val lista = rememberLazyListState()

    fun toast(m: String) = Toast.makeText(context, m, Toast.LENGTH_SHORT).show()

    val escolherImagem = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) scope.launch {
            val r = withContext(Dispatchers.IO) {
                try {
                    val bytes = context.contentResolver.openInputStream(u)?.use { it.readBytes() }
                    if (bytes == null || bytes.size > 4_000_000) null
                    else AgentRunner.Anexo(
                        context.contentResolver.getType(u) ?: "image/jpeg",
                        Base64.encodeToString(bytes, Base64.NO_WRAP)
                    )
                } catch (e: Exception) {
                    null
                }
            }
            if (r == null) toast("Imagem inválida ou maior que 4 MB") else image = r
        }
    }

    LaunchedEffect(session.msgs.size) {
        if (session.msgs.isNotEmpty()) lista.animateScrollToItem(session.msgs.lastIndex)
    }

    // números (+/−) de cada arquivo alterado, calculados fora da thread principal
    LaunchedEffect(session.tick, session.busy) {
        if (!session.busy) {
            stats = withContext(Dispatchers.IO) {
                session.changes.values.toList().associate { it.rel to LineDiff.counts(session.diffDe(it)) }
            }
        }
    }

    fun executar(pedido: String, somenteLeitura: Boolean, mostrar: String = pedido) {
        if (session.busy || pedido.isBlank()) return
        val provider = AiSettings.provider(context)
        if (AiSettings.apiKey(context, provider).isBlank()) {
            showSettings = true
            return
        }
        onBeforeRun() // salva o que você digitou nos editores abertos
        session.msgs.add(AgentMsg("user", mostrar + if (image != null) "\n[imagem anexada]" else ""))
        session.planPending = false
        session.busy = true
        session.cancel = false
        val anexos = listOfNotNull(image)
        image = null
        scope.launch {
            val resposta = try {
                withContext(Dispatchers.IO) {
                    AgentRunner.run(context, session, pedido, anexos, somenteLeitura) { passo ->
                        scope.launch(Dispatchers.Main) { session.msgs.add(AgentMsg("step", passo)) }
                    }
                }
            } catch (e: Exception) {
                "Erro: ${e.message}"
            }
            session.msgs.add(AgentMsg(if (somenteLeitura) "plan" else "ai", resposta))
            session.planPending = somenteLeitura && !resposta.startsWith("Erro:") && resposta != "Cancelado."
            session.salvarChat()
            session.busy = false
            session.tick++
            onFilesChanged(session.changes.keys.map { File(session.raiz, it) })
        }
    }

    fun corrigirLog() {
        scope.launch {
            val achado = withContext(Dispatchers.IO) {
                LogFinder.achar(session.project)?.let { it to LogFinder.extrair(it) }
            }
            if (achado == null) {
                toast("Não achei log de build neste projeto. Cole o erro no campo de texto.")
                return@launch
            }
            val (arq, trecho) = achado
            executar(
                "O build falhou. Abaixo estão os trechos relevantes do log. Encontre a causa, corrija nos arquivos do " +
                    "projeto com as ferramentas e explique. Se o erro vier de configuração (Gradle, SDK, dependência), " +
                    "diga exatamente o que ajustar.\n\n<log>\n$trecho\n</log>",
                false,
                "Corrigir erro do log (${arq.name})"
            )
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Assistente de projeto", maxLines = 1)
                        Text(
                            session.project.name, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                navigationIcon = { IconButton(onClick = onBack) { Icon(ZIcons.Back, contentDescription = "Voltar") } },
                actions = {
                    IconButton(onClick = { showInst = true }) { Icon(ZIcons.Info, contentDescription = "Instruções do projeto") }
                    IconButton(onClick = { showSettings = true }) { Icon(ZIcons.Settings, contentDescription = "Configurar IA") }
                    Box {
                        IconButton(onClick = { showMenu = true }) { Icon(ZIcons.More, contentDescription = "Mais") }
                        DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                            DropdownMenuItem(
                                text = { Text("Limpar conversa") },
                                enabled = !session.busy,
                                onClick = { showMenu = false; session.limparChat() }
                            )
                        }
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            if (session.busy) LinearProgressIndicator(Modifier.fillMaxWidth())

            LazyColumn(
                Modifier.weight(1f).fillMaxWidth().padding(horizontal = 8.dp),
                state = lista,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (session.msgs.isEmpty()) {
                    item {
                        Text(
                            "Peça algo para este projeto. A IA lê os arquivos, edita e cria o que precisar; depois você revê " +
                                "o que mudou, aceita ou reverte por arquivo.\n\n" +
                                "Dica: toque no (i) acima para criar o arquivo $INSTRUCOES com as regras do projeto " +
                                "(formato da ZS Engine, o que não mexer). A IA lê esse arquivo a cada pedido.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
                items(session.msgs) { m ->
                    when (m.kind) {
                        "user" -> Bubble(AiClient.ChatMsg("user", m.text))
                        "ai", "plan" -> Bubble(AiClient.ChatMsg("assistant", m.text))
                        else -> Text(
                            m.text, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(start = 8.dp)
                        )
                    }
                }
            }

            if (session.planPending && !session.busy) {
                Card(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Aprovar este plano?", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                        Button(onClick = {
                            executar("Plano aprovado. Execute agora, seguindo exatamente o plano.", false, "Aprovar plano")
                        }) { Text("Executar") }
                    }
                }
            }

            val tick = session.tick
            if (!session.busy && session.changes.isNotEmpty()) {
                Card(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)) {
                    Column(Modifier.padding(10.dp).heightIn(max = 320.dp).verticalScroll(rememberScrollState())) {
                        Text("${session.changes.size} arquivo(s) alterado(s)", style = MaterialTheme.typography.titleSmall)
                        session.changes.values.toList().forEach { c ->
                            val st = stats[c.rel]
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(
                                    Modifier.weight(1f).clickable {
                                        expandidos = if (c.rel in expandidos) expandidos - c.rel else expandidos + c.rel
                                    }.padding(vertical = 6.dp)
                                ) {
                                    Text(c.rel, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    Text(
                                        (if (c.created) "novo · " else "") + (st?.let { "+${it.first} −${it.second}" } ?: ""),
                                        fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                TextButton(onClick = { onOpenFile(File(session.raiz, c.rel)) }) { Text("Abrir") }
                                TextButton(onClick = {
                                    session.reverter(c.rel)
                                    session.tick++
                                    onFilesChanged(listOf(File(session.raiz, c.rel)))
                                }) { Text("Reverter") }
                            }
                            if (c.rel in expandidos) {
                                val linhas = remember(tick, c.rel) { LineDiff.compact(session.diffDe(c)) }
                                DiffView(linhas)
                            }
                            HorizontalDivider()
                        }
                        Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            TextButton(onClick = {
                                val arqs = session.changes.keys.map { File(session.raiz, it) }
                                session.desfazerTudo()
                                session.tick++
                                onFilesChanged(arqs)
                            }) { Text("Desfazer tudo") }
                            Spacer(Modifier.weight(1f))
                            Button(onClick = { session.aceitar(); session.tick++ }) { Text("Aceitar tudo") }
                        }
                    }
                }
            }

            Row(Modifier.padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(
                    onClick = { corrigirLog() },
                    label = { Text("Corrigir erro do log") },
                    enabled = !session.busy
                )
                FilterChip(
                    selected = planMode,
                    onClick = { planMode = !planMode },
                    label = { Text("Planejar antes") }
                )
            }

            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.Bottom) {
                IconButton(onClick = { escolherImagem.launch("image/*") }) {
                    Icon(
                        ZIcons.Image, contentDescription = "Anexar imagem",
                        tint = if (image != null) MaterialTheme.colorScheme.primary else LocalContentColor.current
                    )
                }
                OutlinedTextField(
                    value = input, onValueChange = { input = it },
                    modifier = Modifier.weight(1f), maxLines = 5,
                    placeholder = { Text(if (planMode) "Descreva o que quer (a IA vai planejar)" else "Peça algo ao projeto") }
                )
                if (session.busy) {
                    IconButton(onClick = { session.cancel = true; toast("Cancelando ao fim do passo atual…") }) {
                        Icon(ZIcons.Stop, contentDescription = "Cancelar")
                    }
                } else {
                    IconButton(
                        onClick = { val t = input.trim(); input = ""; executar(t, planMode) },
                        enabled = input.isNotBlank()
                    ) { Icon(ZIcons.Send, contentDescription = "Enviar") }
                }
            }
        }
    }

    if (showSettings) AiSettingsDialog { showSettings = false }
    if (showInst) InstrucoesDialog(session.raiz) { showInst = false }
}

@Composable
private fun InstrucoesDialog(projeto: File, onDismiss: () -> Unit) {
    val arquivo = File(projeto, INSTRUCOES)
    var texto by remember { mutableStateOf(if (arquivo.isFile) arquivo.readText().take(20_000) else "") }
    val context = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Instruções do projeto") },
        text = {
            Column {
                Text(
                    "Fica salvo em $INSTRUCOES na pasta do projeto. A IA lê a cada pedido: use para explicar o formato " +
                        "da engine, regras e o que não mexer.",
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = texto, onValueChange = { texto = it },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 180.dp, max = 320.dp),
                    textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                )
                TextButton(onClick = { texto = MODELO_INSTRUCOES }) { Text("Usar modelo da ZS Engine") }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                try {
                    arquivo.writeText(texto)
                    Toast.makeText(context, "Instruções salvas", Toast.LENGTH_SHORT).show()
                    onDismiss()
                } catch (e: Exception) {
                    Toast.makeText(context, "Erro ao salvar: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }) { Text("Salvar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Fechar") } }
    )
}
