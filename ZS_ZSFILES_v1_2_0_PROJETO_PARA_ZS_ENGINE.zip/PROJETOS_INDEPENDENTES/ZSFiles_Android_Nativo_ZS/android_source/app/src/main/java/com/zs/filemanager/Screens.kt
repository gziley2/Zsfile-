@file:OptIn(ExperimentalMaterial3Api::class)

package com.zs.filemanager

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

@Composable
private fun SectionTitle(t: String) = Text(
    t,
    style = MaterialTheme.typography.titleSmall,
    color = MaterialTheme.colorScheme.primary,
    modifier = Modifier.padding(start = 16.dp, top = 18.dp, bottom = 4.dp)
)

@Composable
private fun ToolCard(icon: ImageVector, title: String, desc: String, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
            Spacer(Modifier.width(16.dp))
            Column {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun ToolsScreen(onApkExtractor: () -> Unit, onHex: () -> Unit, onAnalyze: () -> Unit, onAgent: () -> Unit) {
    Scaffold(topBar = { TopAppBar(title = { Text("Ferramentas") }) }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(vertical = 8.dp)) {
            ToolCard(ZIcons.Android, "Extrator de APK", "Copie o APK de qualquer app instalado. Apps com splits viram um .apks.", onApkExtractor)
            ToolCard(ZIcons.Hex, "Visualizador hexadecimal", "Veja os bytes de qualquer arquivo, com busca e salto para um offset.", onHex)
            ToolCard(ZIcons.Code, "Assistente de projeto (IA)", "A IA lê, cria e corrige arquivos do seu projeto. Você revê o que mudou e aceita ou reverte.", onAgent)
            ToolCard(ZIcons.Ai, "Análise com IA", "Engenharia reversa assistida de APK, DEX, ZIP, código e pastas de projeto.", onAnalyze)
            Text(
                "Para decompilar um APK em smali ou extrair um .7z/.rar, segure o arquivo na aba Arquivos e use o menu de três pontos.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(16.dp)
            )
        }
    }
}

@Composable
fun HelpDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Como usar") },
        text = {
            Text(
                "• Segure o dedo em um arquivo ou pasta para selecionar. O menu do topo mostra as ações: copiar, cortar, " +
                    "compactar, excluir, renomear, abrir no hex, decompilar APK e analisar com IA.\n\n" +
                    "• Toque em um arquivo de texto ou código para abrir no editor. Em layouts XML, o botão do olho mostra a prévia.\n\n" +
                    "• Toque em um binário para ver em hexadecimal, ou em .zip/.7z/.rar para extrair.\n\n" +
                    "• IA: selecione um arquivo ou pasta > Analisar com IA. A chave da API fica em Ajustes.\n\n" +
                    "• Assistente de projeto: selecione uma pasta > ⋮ > Assistente de projeto (IA), ou use Ferramentas. " +
                    "A IA edita os arquivos; depois você vê o diff e aceita ou reverte.",
                fontSize = 14.sp
            )
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("OK") } }
    )
}

@Suppress("DEPRECATION")
@Composable
fun SettingsScreen(themeMode: String, onThemeChange: (String) -> Unit) {
    val context = LocalContext.current
    var showAi by remember { mutableStateOf(false) }
    var showHelp by remember { mutableStateOf(false) }
    var hidden by remember { mutableStateOf(AppPrefs.showHidden(context)) }
    var sort by remember { mutableStateOf(AppPrefs.sort(context)) }
    val provider = AiSettings.provider(context)
    val hasKey = AiSettings.apiKey(context, provider).isNotBlank()
    val version = remember {
        try {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }
    }
    Scaffold(topBar = { TopAppBar(title = { Text("Ajustes") }) }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState())) {
            SectionTitle("Inteligência artificial")
            ListItem(
                headlineContent = { Text(if (provider == AiSettings.GEMINI) "Gemini" else "Claude") },
                supportingContent = {
                    Text(
                        if (hasKey) "Chave configurada · modelo ${AiSettings.model(context, provider)}"
                        else "Chave não configurada"
                    )
                },
                leadingContent = { Icon(ZIcons.Ai, contentDescription = null) },
                trailingContent = { TextButton(onClick = { showAi = true }) { Text("Configurar") } }
            )
            SectionTitle("Aparência")
            listOf("system" to "Seguir o sistema", "light" to "Claro", "dark" to "Escuro").forEach { (id, label) ->
                ListItem(
                    headlineContent = { Text(label) },
                    leadingContent = { RadioButton(selected = themeMode == id, onClick = null) },
                    modifier = Modifier.clickable { onThemeChange(id) }
                )
            }
            SectionTitle("Arquivos")
            ListItem(
                headlineContent = { Text("Mostrar arquivos ocultos") },
                supportingContent = { Text("Itens que começam com ponto") },
                trailingContent = {
                    Switch(checked = hidden, onCheckedChange = {
                        hidden = it
                        AppPrefs.setShowHidden(context, it)
                    })
                }
            )
            listOf("name" to "Ordenar por nome", "date" to "Ordenar por data (mais novos primeiro)", "size" to "Ordenar por tamanho").forEach { (id, label) ->
                ListItem(
                    headlineContent = { Text(label) },
                    leadingContent = { RadioButton(selected = sort == id, onClick = null) },
                    modifier = Modifier.clickable {
                        sort = id
                        AppPrefs.setSort(context, id)
                    }
                )
            }
            SectionTitle("Sobre")
            ListItem(
                headlineContent = { Text("ZS Files") },
                supportingContent = { Text("Versão $version") }
            )
            ListItem(
                headlineContent = { Text("Ajuda") },
                leadingContent = { Icon(ZIcons.Info, contentDescription = null) },
                modifier = Modifier.clickable { showHelp = true }
            )
            Spacer(Modifier.height(24.dp))
        }
    }
    if (showAi) AiSettingsDialog { showAi = false }
    if (showHelp) HelpDialog { showHelp = false }
}

@Composable
fun EmptyEditor(onGoFiles: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(ZIcons.Code, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(56.dp))
        Spacer(Modifier.height(16.dp))
        Text("Nenhum arquivo aberto", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Text(
            "Toque em um arquivo de texto ou código na aba Arquivos para editar aqui.",
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(16.dp))
        Button(onClick = onGoFiles) { Text("Ir para Arquivos") }
    }
}

@Composable
private fun PickerRow(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(10.dp))
        Text(label, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
    }
}

/** Seletor simples de arquivo/pasta dentro do armazenamento. */
@Composable
fun FilePickerDialog(
    root: File,
    startPath: String,
    title: String,
    allowFolder: Boolean,
    onPick: (File) -> Unit,
    onDismiss: () -> Unit,
) {
    var path by remember { mutableStateOf(startPath) }
    val dir = File(path)
    val items = remember(path) { FileUtils.list(dir).filter { !it.name.startsWith(".") } }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                Text(
                    dir.absolutePath, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(6.dp))
                LazyColumn(Modifier.heightIn(max = 360.dp)) {
                    if (dir.absolutePath != root.absolutePath) {
                        item { PickerRow(ZIcons.Up, "Pasta acima") { path = dir.parent ?: root.absolutePath } }
                    }
                    items(items, key = { it.absolutePath }) { f ->
                        PickerRow(if (f.isDirectory) ZIcons.Folder else ZIcons.File, f.name) {
                            if (f.isDirectory) path = f.absolutePath else onPick(f)
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (allowFolder) TextButton(onClick = { onPick(dir) }) { Text("Usar esta pasta") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Fechar") } }
    )
}
