@file:OptIn(ExperimentalMaterial3Api::class)

package com.zs.filemanager

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

class EditorTab(val file: File, initial: String) {
    var text by mutableStateOf(TextFieldValue(initial))
        private set
    var saved by mutableStateOf(initial)
        private set

    private val undoStack = mutableListOf<TextFieldValue>()
    private val redoStack = mutableListOf<TextFieldValue>()
    private var lastEdit = 0L

    /** 0 = só código, 1 = dividido, 2 = só prévia (layouts XML). */
    var previewMode by mutableIntStateOf(0)

    val dirty: Boolean get() = text.text != saved

    fun onChange(new: TextFieldValue) {
        if (new.text != text.text) {
            val now = System.currentTimeMillis()
            if (undoStack.isEmpty() || now - lastEdit > 700) {
                undoStack.add(text)
                if (undoStack.size > 200) undoStack.removeAt(0)
            }
            lastEdit = now
            redoStack.clear()
        }
        text = new
    }

    /** Troca o texto pelo que está no disco (usado quando a IA altera o arquivo). */
    fun reload(novo: String) {
        text = TextFieldValue(novo)
        saved = novo
        undoStack.clear()
        redoStack.clear()
    }

    fun undo() {
        if (undoStack.isNotEmpty()) {
            redoStack.add(text)
            text = undoStack.removeAt(undoStack.lastIndex)
            lastEdit = 0
        }
    }

    fun redo() {
        if (redoStack.isNotEmpty()) {
            undoStack.add(text)
            text = redoStack.removeAt(redoStack.lastIndex)
            lastEdit = 0
        }
    }

    /** Retorna null se salvou, ou a mensagem de erro. */
    fun save(): String? = try {
        file.writeText(text.text)
        saved = text.text
        null
    } catch (e: Exception) {
        e.message ?: "erro ao salvar"
    }

    fun insert(s: String) {
        val sel = text.selection
        val t = text.text
        val newText = t.substring(0, sel.min) + s + t.substring(sel.max)
        onChange(TextFieldValue(newText, TextRange(sel.min + s.length)))
    }

    fun findNext(q: String): Boolean {
        if (q.isEmpty()) return false
        val t = text.text
        var i = t.indexOf(q, text.selection.max, ignoreCase = true)
        if (i < 0) i = t.indexOf(q, 0, ignoreCase = true)
        if (i < 0) return false
        text = text.copy(selection = TextRange(i, i + q.length))
        return true
    }

    fun replaceAll(q: String, r: String): Int {
        if (q.isEmpty()) return 0
        val re = Regex(Regex.escape(q), RegexOption.IGNORE_CASE)
        val n = re.findAll(text.text).count()
        if (n > 0) onChange(TextFieldValue(re.replace(text.text, Regex.escapeReplacement(r)), TextRange(0)))
        return n
    }
}

@Composable
fun EditorScreen(
    tabs: List<EditorTab>,
    current: Int,
    onSelect: (Int) -> Unit,
    onCloseTab: (Int) -> Unit,
    onBack: () -> Unit,
    onAnalyze: (File, String?) -> Unit,
    onConvertJava: (File, String) -> Unit,
) {
    val context = LocalContext.current
    val idx = current.coerceIn(0, tabs.lastIndex)
    val tab = tabs[idx]
    var showFind by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var findQ by remember { mutableStateOf("") }
    var findR by remember { mutableStateOf("") }
    var pendingClose by remember { mutableStateOf<Int?>(null) }

    fun toast(m: String) = Toast.makeText(context, m, Toast.LENGTH_SHORT).show()
    fun requestClose(i: Int) {
        if (tabs[i].dirty) pendingClose = i else onCloseTab(i)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        tab.file.name + if (tab.dirty) " •" else "",
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = { IconButton(onClick = onBack) { Icon(ZIcons.Back, contentDescription = "Voltar") } },
                actions = {
                    if (FileUtils.isLayoutXml(tab.file)) {
                        IconButton(onClick = {
                            tab.previewMode = (tab.previewMode + 1) % 3
                            toast(
                                when (tab.previewMode) {
                                    0 -> "Só código"
                                    1 -> "Código + prévia"
                                    else -> "Só prévia"
                                }
                            )
                        }) { Icon(ZIcons.Eye, contentDescription = "Prévia") }
                    }
                    IconButton(onClick = { tab.undo() }) { Icon(ZIcons.Undo, contentDescription = "Desfazer") }
                    Box {
                        IconButton(onClick = { menuOpen = true }) { Icon(ZIcons.More, contentDescription = "Mais opções") }
                        DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                            DropdownMenuItem(text = { Text("Refazer") }, onClick = { menuOpen = false; tab.redo() })
                            DropdownMenuItem(
                                text = { Text("Buscar / substituir") },
                                onClick = { menuOpen = false; showFind = true }
                            )
                            DropdownMenuItem(
                                text = { Text("Analisar com IA") },
                                onClick = { menuOpen = false; onAnalyze(tab.file, tab.text.text) }
                            )
                            if (tab.file.extension.equals("smali", ignoreCase = true)) {
                                DropdownMenuItem(
                                    text = { Text("Converter para Java (IA)") },
                                    onClick = { menuOpen = false; onConvertJava(tab.file, tab.text.text) }
                                )
                            }
                        }
                    }
                    IconButton(onClick = { toast(tab.save() ?: "Salvo") }) { Icon(ZIcons.Save, contentDescription = "Salvar") }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            ScrollableTabRow(selectedTabIndex = idx, edgePadding = 0.dp) {
                tabs.forEachIndexed { i, t ->
                    Tab(selected = i == idx, onClick = { onSelect(i) }) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(start = 12.dp, top = 4.dp, bottom = 4.dp)
                        ) {
                            Text(t.file.name + if (t.dirty) "*" else "", maxLines = 1)
                            Text(
                                "✕",
                                modifier = Modifier.clickable { requestClose(i) }.padding(12.dp)
                            )
                        }
                    }
                }
            }
            val mode = if (FileUtils.isLayoutXml(tab.file)) tab.previewMode else 0
            if (mode != 0) LayoutPreviewPane(tab.file, tab.text.text, Modifier.weight(1f))
            if (mode != 2) {
                Box(Modifier.weight(1f)) { CodeEditor(tab) }
                SymbolBar(tab)
            }
        }
    }

    if (showFind) {
        AlertDialog(
            onDismissRequest = { showFind = false },
            title = { Text("Buscar / substituir") },
            text = {
                Column {
                    OutlinedTextField(findQ, { findQ = it }, label = { Text("Buscar") }, singleLine = true)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(findR, { findR = it }, label = { Text("Substituir por") }, singleLine = true)
                }
            },
            confirmButton = {
                Row {
                    TextButton(onClick = {
                        if (tab.findNext(findQ)) showFind = false else toast("Não encontrado")
                    }) { Text("Próximo") }
                    TextButton(onClick = {
                        val n = tab.replaceAll(findQ, findR)
                        toast("$n substituído(s)")
                        showFind = false
                    }) { Text("Trocar tudo") }
                }
            },
            dismissButton = { TextButton(onClick = { showFind = false }) { Text("Fechar") } }
        )
    }

    val closing = pendingClose
    if (closing != null && closing < tabs.size) {
        val t = tabs[closing]
        AlertDialog(
            onDismissRequest = { pendingClose = null },
            title = { Text("Alterações não salvas") },
            text = { Text(t.file.name) },
            confirmButton = {
                TextButton(onClick = {
                    val err = t.save()
                    if (err == null) {
                        pendingClose = null
                        onCloseTab(closing)
                    } else toast(err)
                }) { Text("Salvar e fechar") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { pendingClose = null; onCloseTab(closing) }) { Text("Descartar") }
                    TextButton(onClick = { pendingClose = null }) { Text("Cancelar") }
                }
            }
        )
    }
}

@Composable
fun CodeEditor(tab: EditorTab) {
    val ext = tab.file.extension.lowercase()
    val transformation = remember(ext) { SyntaxTransformation(ext) }
    val style = remember {
        TextStyle(
            fontFamily = FontFamily.Monospace,
            fontSize = 13.sp,
            lineHeight = 19.sp,
            color = Color(0xFFD4D4D4)
        )
    }
    val lines = tab.text.text.count { it == '\n' } + 1
    val numbers = remember(lines) { (1..lines).joinToString("\n") }
    val gutter = (lines.toString().length * 8 + 16).dp

    Row(
        Modifier.fillMaxSize()
            .background(Color(0xFF1E1E1E))
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            numbers,
            style = style.copy(color = Color(0xFF6B6B6B), textAlign = TextAlign.End),
            modifier = Modifier.width(gutter).padding(end = 8.dp, top = 8.dp)
        )
        BasicTextField(
            value = tab.text,
            onValueChange = { tab.onChange(it) },
            textStyle = style,
            cursorBrush = SolidColor(Color.White),
            visualTransformation = transformation,
            keyboardOptions = KeyboardOptions(
                capitalization = KeyboardCapitalization.None,
                autoCorrect = false
            ),
            modifier = Modifier
                .weight(1f)
                .defaultMinSize(minHeight = 600.dp)
                .horizontalScroll(rememberScrollState())
                .padding(top = 8.dp, end = 32.dp)
        )
    }
}

@Composable
fun SymbolBar(tab: EditorTab) {
    val symbols = listOf(
        "TAB" to "    ", "{" to "{", "}" to "}", "(" to "(", ")" to ")", "[" to "[", "]" to "]",
        ";" to ";", "=" to "=", "\"" to "\"", "'" to "'", "<" to "<", ">" to ">", "/" to "/",
        "\\" to "\\", "!" to "!", "&" to "&", "|" to "|", "_" to "_", ":" to ":", "$" to "$"
    )
    Row(
        Modifier.fillMaxWidth()
            .background(Color(0xFF2B2B2B))
            .horizontalScroll(rememberScrollState())
    ) {
        symbols.forEach { (label, ins) ->
            TextButton(
                onClick = { tab.insert(ins) },
                contentPadding = PaddingValues(horizontal = 14.dp)
            ) { Text(label, fontFamily = FontFamily.Monospace, color = Color.White) }
        }
    }
}
