package com.zs.filemanager

import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import kotlin.math.ln

/** Decodifica XML binário do Android (AXML): AndroidManifest.xml e os XMLs de res. */
object Axml {
    private val attrNames = mapOf(
        0x01010003 to "name", 0x01010001 to "label", 0x01010002 to "icon",
        0x0101021b to "versionCode", 0x0101021c to "versionName",
        0x0101020c to "minSdkVersion", 0x01010270 to "targetSdkVersion",
        0x0101000f to "debuggable", 0x01010280 to "allowBackup", 0x01010010 to "exported",
        0x01010024 to "value", 0x01010025 to "resource"
    )
    private val radixMult = floatArrayOf(0.00390625f, 3.0517578E-5f, 1.1920929E-7f, 4.656613E-10f)
    private val unitNames = arrayOf("px", "dip", "sp", "pt", "in", "mm")
    private val constraintRe = Regex("layout_constraint\\w+_to\\w+Of")
    private val scaleTypes = arrayOf("matrix", "fitXY", "fitStart", "fitCenter", "fitEnd", "center", "centerCrop", "centerInside")
    private val ellipsizes = arrayOf("none", "start", "middle", "end", "marquee")

    fun isAxml(b: ByteArray) =
        b.size > 8 && b[0] == 0x03.toByte() && b[1] == 0x00.toByte() && b[2] == 0x08.toByte() && b[3] == 0x00.toByte()

    private fun str(list: List<String>, i: Int) = if (i in list.indices) list[i] else ""
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace("\"", "&quot;")

    fun readStringPool(bb: ByteBuffer, pos: Int): List<String> {
        val hdr = bb.getShort(pos + 2).toInt() and 0xFFFF
        val count = bb.getInt(pos + 8)
        val flags = bb.getInt(pos + 16)
        val stringsStart = bb.getInt(pos + 20)
        val utf8 = (flags and 0x100) != 0
        val arr = bb.array()
        val out = ArrayList<String>(maxOf(count, 0))
        for (i in 0 until count) {
            val off = bb.getInt(pos + hdr + i * 4)
            var p = pos + stringsStart + off
            if (utf8) {
                val l1 = bb.get(p).toInt() and 0xFF
                p += if ((l1 and 0x80) != 0) 2 else 1
                var blen = bb.get(p).toInt() and 0xFF
                if ((blen and 0x80) != 0) {
                    blen = ((blen and 0x7F) shl 8) or (bb.get(p + 1).toInt() and 0xFF)
                    p += 2
                } else p += 1
                out.add(String(arr, p, blen, Charsets.UTF_8))
            } else {
                var len = bb.getShort(p).toInt() and 0xFFFF
                p += 2
                if ((len and 0x8000) != 0) {
                    len = ((len and 0x7FFF) shl 16) or (bb.getShort(p).toInt() and 0xFFFF)
                    p += 2
                }
                out.add(String(arr, p, len * 2, Charsets.UTF_16LE))
            }
        }
        return out
    }

    private fun trimFloat(f: Float): String {
        val s = String.format(Locale.US, "%.2f", f).trimEnd('0').trimEnd('.')
        return if (s.isEmpty() || s == "-") "0" else s
    }

    fun dimension(data: Int): String {
        val mant = (data and 0xFFFFFF00.toInt()).toFloat() * radixMult[(data shr 4) and 3]
        return trimFloat(mant) + (unitNames.getOrNull(data and 0xF) ?: "")
    }

    fun fraction(data: Int): String {
        val v = (data and 0xFFFFFF00.toInt()).toFloat() * radixMult[(data shr 4) and 3] * 100f
        return trimFloat(v) + (if ((data and 0xF) == 0) "%" else "%p")
    }

    private fun gravityString(v: Int): String? {
        if (v == 0) return null
        if (v == 0x11) return "center"
        if (v == 0x77) return "fill"
        val rel = (v and 0x00800000) != 0
        val parts = ArrayList<String>()
        when (v and 0x07) {
            1 -> parts.add("center_horizontal")
            3 -> parts.add(if (rel) "start" else "left")
            5 -> parts.add(if (rel) "end" else "right")
            7 -> parts.add("fill_horizontal")
        }
        when (v and 0x70) {
            0x10 -> parts.add("center_vertical")
            0x30 -> parts.add("top")
            0x50 -> parts.add("bottom")
            0x70 -> parts.add("fill_vertical")
        }
        return if (parts.isEmpty()) null else parts.joinToString("|")
    }

    /** Enums/flags mais comuns: deixa o XML igual ao original (match_parent, vertical, gone...). */
    private fun enumValue(name: String, v: Int): String? = when (name) {
        "layout_width", "layout_height" -> when (v) {
            -1 -> "match_parent"
            -2 -> "wrap_content"
            else -> null
        }
        "orientation" -> when (v) {
            0 -> "horizontal"
            1 -> "vertical"
            else -> null
        }
        "visibility" -> when (v) {
            0 -> "visible"
            4 -> "invisible"
            8 -> "gone"
            else -> null
        }
        "textStyle" -> when (v) {
            0 -> "normal"
            1 -> "bold"
            2 -> "italic"
            3 -> "bold|italic"
            else -> null
        }
        "gravity", "layout_gravity" -> gravityString(v)
        "scaleType" -> scaleTypes.getOrNull(v)
        "ellipsize" -> ellipsizes.getOrNull(v)
        else -> null
    }

    fun decode(data: ByteArray, resolver: ((Int) -> String?)? = null): String {
        val bb = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        var strings: List<String> = emptyList()
        var resIds = IntArray(0)
        val nsPrefix = HashMap<Int, Int>()
        val pendingNs = ArrayList<Pair<Int, Int>>()
        val sb = StringBuilder("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n")
        var depth = 0
        var pos = bb.getShort(2).toInt() and 0xFFFF
        while (pos + 8 <= data.size) {
            val type = bb.getShort(pos).toInt() and 0xFFFF
            val hdr = bb.getShort(pos + 2).toInt() and 0xFFFF
            val size = bb.getInt(pos + 4)
            if (size <= 0 || pos + size > data.size) break
            when (type) {
                0x0001 -> strings = readStringPool(bb, pos)
                0x0180 -> {
                    val n = (size - hdr) / 4
                    resIds = IntArray(n) { bb.getInt(pos + hdr + it * 4) }
                }
                0x0100 -> {
                    val prefix = bb.getInt(pos + hdr)
                    val uri = bb.getInt(pos + hdr + 4)
                    nsPrefix[uri] = prefix
                    pendingNs.add(prefix to uri)
                }
                0x0102 -> {
                    val b0 = pos + hdr
                    val nameIdx = bb.getInt(b0 + 4)
                    val attrStart = bb.getShort(b0 + 8).toInt() and 0xFFFF
                    val attrCount = bb.getShort(b0 + 12).toInt() and 0xFFFF
                    sb.append("  ".repeat(depth)).append('<').append(str(strings, nameIdx))
                    for ((p, u) in pendingNs) {
                        sb.append(" xmlns:").append(str(strings, p)).append("=\"").append(esc(str(strings, u))).append('"')
                    }
                    pendingNs.clear()
                    var ap = b0 + attrStart
                    for (i in 0 until attrCount) {
                        val ns = bb.getInt(ap)
                        val nm = bb.getInt(ap + 4)
                        val raw = bb.getInt(ap + 8)
                        val dtype = bb.get(ap + 15).toInt() and 0xFF
                        val d = bb.getInt(ap + 16)
                        var name = str(strings, nm)
                        if (name.isEmpty() && nm in resIds.indices) {
                            name = attrNames[resIds[nm]] ?: ("attr_0x" + Integer.toHexString(resIds[nm]))
                        }
                        val prefix = if (ns != -1) nsPrefix[ns]?.let { str(strings, it) } else null
                        var v: String? = null
                        if (raw == -1 && (dtype == 0x10 || dtype == 0x11)) {
                            v = enumValue(name, d)
                            if (v == null && d == 0 && constraintRe.matches(name)) v = "parent"
                        }
                        if (v == null) {
                            v = when {
                                raw != -1 -> str(strings, raw)
                                dtype == 0x03 -> str(strings, d)
                                dtype == 0x12 -> if (d != 0) "true" else "false"
                                dtype == 0x10 -> d.toString()
                                dtype == 0x11 -> "0x" + Integer.toHexString(d)
                                dtype == 0x01 -> resolver?.invoke(d)?.let { "@$it" } ?: ("@0x" + Integer.toHexString(d))
                                dtype == 0x02 -> "?" + (resolver?.invoke(d) ?: ("0x" + Integer.toHexString(d)))
                                dtype == 0x04 -> java.lang.Float.intBitsToFloat(d).toString()
                                dtype == 0x05 -> dimension(d)
                                dtype == 0x06 -> fraction(d)
                                dtype == 0x1c -> String.format("#%08x", d)
                                dtype == 0x1d -> String.format("#%06x", d and 0xFFFFFF)
                                else -> "0x" + Integer.toHexString(d)
                            }
                        }
                        sb.append(' ')
                        if (!prefix.isNullOrEmpty()) sb.append(prefix).append(':')
                        sb.append(name).append("=\"").append(esc(v)).append('"')
                        ap += 20
                    }
                    sb.append(">\n")
                    depth++
                }
                0x0103 -> {
                    depth = maxOf(depth - 1, 0)
                    sb.append("  ".repeat(depth)).append("</").append(str(strings, bb.getInt(pos + hdr + 4))).append(">\n")
                }
                0x0104 -> {
                    val t = str(strings, bb.getInt(pos + hdr))
                    if (t.isNotBlank()) sb.append("  ".repeat(depth)).append(esc(t.trim())).append('\n')
                }
            }
            pos += size
        }
        return sb.toString()
    }
}

class DexData(val strings: List<String>, val defined: List<String>)

object Dex {
    fun isDex(b: ByteArray) = b.size > 0x70 && b[0] == 'd'.code.toByte() && b[1] == 'e'.code.toByte() &&
        b[2] == 'x'.code.toByte() && b[3] == 0x0A.toByte()

    fun pretty(d: String) = d.removePrefix("L").removeSuffix(";").replace('/', '.')

    fun read(data: ByteArray): DexData {
        val bb = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)
        val strCount = bb.getInt(0x38)
        val strOff = bb.getInt(0x3C)
        val typeOff = bb.getInt(0x44)
        val cdCount = bb.getInt(0x60)
        val cdOff = bb.getInt(0x64)
        val strings = ArrayList<String>(maxOf(strCount, 0))
        for (i in 0 until strCount) {
            var p = bb.getInt(strOff + i * 4)
            while (p < data.size && (data[p].toInt() and 0x80) != 0) p++
            p++
            var e = p
            while (e < data.size && data[e] != 0.toByte()) e++
            strings.add(String(data, p, e - p, Charsets.UTF_8))
        }
        val defined = ArrayList<String>(maxOf(cdCount, 0))
        for (i in 0 until cdCount) {
            val typeIdx = bb.getInt(cdOff + i * 32)
            val strIdx = bb.getInt(typeOff + typeIdx * 4)
            strings.getOrNull(strIdx)?.let { defined.add(it) }
        }
        return DexData(strings, defined)
    }
}

object Analyzer {
    private const val MAX = 120_000

    private val libPrefixes = listOf(
        "android.", "androidx.", "kotlin.", "kotlinx.", "com.google.", "okhttp3.", "okio.", "retrofit2.",
        "com.squareup.", "org.jetbrains.", "io.reactivex.", "com.bumptech.", "dagger.", "javax.", "java.",
        "org.apache.", "org.json.", "com.android.", "org.intellij.", "j$."
    )

    private val indicators = linkedMapOf(
        "Execução de comandos" to listOf("Ljava/lang/Runtime;", "Ljava/lang/ProcessBuilder;"),
        "Carregamento dinâmico de código" to listOf(
            "Ldalvik/system/DexClassLoader;", "Ldalvik/system/PathClassLoader;", "Ldalvik/system/InMemoryDexClassLoader;"
        ),
        "Reflection" to listOf("Ljava/lang/reflect/Method;"),
        "SMS / telefonia" to listOf("Landroid/telephony/SmsManager;", "Landroid/telephony/TelephonyManager;"),
        "Criptografia" to listOf(
            "Ljavax/crypto/Cipher;", "Ljavax/crypto/spec/SecretKeySpec;", "Ljava/security/MessageDigest;"
        ),
        "Rede" to listOf("Ljava/net/HttpURLConnection;", "Lokhttp3/OkHttpClient;", "Ljava/net/Socket;"),
        "WebView / JavaScript" to listOf("Landroid/webkit/WebView;", "addJavascriptInterface"),
        "Localização" to listOf("Landroid/location/LocationManager;"),
        "Câmera / áudio" to listOf("Landroid/hardware/Camera;", "Landroid/media/MediaRecorder;"),
        "Acessibilidade" to listOf("Landroid/accessibilityservice/AccessibilityService;"),
        "Admin do dispositivo" to listOf("Landroid/app/admin/DevicePolicyManager;"),
        "Detecção de root/emulador" to listOf(
            "/system/bin/su", "/system/xbin/su", "Superuser.apk", "ro.kernel.qemu"
        ),
        "Anti-debug" to listOf("Landroid/os/Debug;", "isDebuggerConnected"),
        "Biblioteca nativa" to listOf("loadLibrary")
    )

    private val nativeSensitive = setOf(
        "system", "execve", "execl", "execv", "popen", "ptrace", "fork", "dlopen", "dlsym", "mprotect",
        "mmap", "socket", "connect", "unlink", "chmod", "kill", "prctl", "inotify_init",
        "__android_log_print", "JNI_OnLoad", "RegisterNatives", "getenv", "fopen"
    )

    private val classDesc = Regex("^\\[*L[\\w/$]+;$")
    private val urlRe = Regex("https?://[^\\s\"'<>]{4,}")
    private val ipRe = Regex("\\b(?:\\d{1,3}\\.){3}\\d{1,3}(?::\\d+)?\\b")
    private val emailRe = Regex("[\\w.+-]+@[\\w-]+\\.[\\w.-]+")
    private val kwRe = Regex(
        "(?i)(password|passwd|secret|token|api[_-]?key|private[_-]?key|bearer |authorization|" +
            "BEGIN (RSA|PRIVATE|CERTIFICATE)|firebaseio|amazonaws|AES/|RSA/|encrypt|decrypt|license|premium)"
    )

    fun buildContext(f: File, textOverride: String?, budget: Int = MAX): String {
        val sb = StringBuilder()
        sb.appendLine("# Arquivo: ${f.name}")
        sb.appendLine("Caminho: ${f.absolutePath}")
        when {
            f.isDirectory -> folder(f, sb, budget)
            textOverride != null -> text(f, textOverride, sb, budget)
            f.extension.lowercase() in FileUtils.archiveExts -> archive(f, sb)
            FileUtils.archiveKind(f) != null -> otherArchive(f, sb)
            FileUtils.isProbablyText(f) && f.length() <= 2_000_000 -> text(f, f.readText(), sb, budget)
            else -> binary(f, sb)
        }
        return if (sb.length > budget) sb.substring(0, budget) + "\n...[contexto truncado]" else sb.toString()
    }

    /** Resumo estático do APK + smali decompilado das classes mais relevantes. */
    fun buildApkWithSmali(apk: File, budget: Int, workDir: File): String {
        val base = buildContext(apk, null, minOf(budget, 100_000))
        val out = File(workDir, "decomp_" + apk.nameWithoutExtension)
        out.deleteRecursively()
        try {
            Decompiler.decompile(apk, out, true, false)
            val sb = StringBuilder(base)
            Decompiler.appendSmaliContext(out, budget, sb)
            return if (sb.length > budget) sb.substring(0, budget) + "\n...[contexto truncado]" else sb.toString()
        } finally {
            out.deleteRecursively()
        }
    }

    // ---------- texto ----------
    private fun text(f: File, content: String, sb: StringBuilder, budget: Int) {
        val cap = (budget * 0.75).toInt()
        sb.appendLine("Tipo: texto/código (.${f.extension}) · ${content.length} caracteres · ${content.count { it == '\n' } + 1} linhas")
        sb.appendLine("\n## Conteúdo")
        sb.appendLine("```")
        sb.appendLine(content.take(cap))
        if (content.length > cap) sb.appendLine("...[truncado]")
        sb.appendLine("```")
    }

    // ---------- 7z / RAR / TAR ----------
    private fun otherArchive(f: File, sb: StringBuilder) {
        sb.appendLine("Tipo: arquivo compactado (${FileUtils.archiveKind(f)}) · ${FileUtils.readableSize(f.length())}")
        sb.appendLine("SHA-256: ${sha256(f)}")
        val names = try { FileUtils.listArchive(f) } catch (e: Exception) { null }
        if (names == null) {
            sb.appendLine("(listagem do conteúdo indisponível para este formato; extraia para analisar os arquivos)")
        } else {
            sb.appendLine("Entradas: ${names.size}")
            names.take(300).forEach { sb.appendLine("${it.first} (${FileUtils.readableSize(it.second)})") }
        }
    }

    // ---------- pasta ----------
    private fun appendFile(f: File, label: String, max: Int, sb: StringBuilder) {
        try {
            sb.appendLine("\n## $label")
            sb.appendLine("```")
            sb.appendLine(f.readText().take(max))
            sb.appendLine("```")
        } catch (e: Exception) {
            sb.appendLine("(erro ao ler: ${e.message})")
        }
    }

    private val srcExts = setOf(
        "kt", "kts", "java", "cs", "py", "js", "ts", "tsx", "jsx", "c", "cpp", "h", "hpp", "go", "rs",
        "swift", "dart", "lua", "php", "rb", "smali"
    )
    private val codeExts = srcExts + setOf(
        "xml", "json", "gradle", "properties", "html", "css", "md", "yml", "yaml", "toml", "txt", "sql", "pro", "sh", "bat"
    )
    private val textAssetExts = setOf(
        "json", "txt", "xml", "html", "htm", "js", "css", "csv", "properties", "md", "yml", "yaml", "toml", "ini",
        "cfg", "conf", "sql", "svg", "log", "lua", "glsl", "shader", "vert", "frag", "tsv", "plist"
    )
    private val nestedExts = listOf(".dex", ".jar", ".apk", ".so", ".zip", ".elf")
    private val skipDirs = setOf(
        "build", ".gradle", ".git", ".idea", "node_modules", "bin", "obj", "__pycache__", ".dart_tool", "intermediates"
    )
    private val entryRe = Regex("(?i)(main|application|app|activity|service|receiver|provider)")

    private fun isAssetPath(rel: String) = ("/" + rel.replace('\\', '/')).contains("/assets/")

    private fun priority(rel: String, f: File): Int {
        val n = f.name
        val r = rel.replace('\\', '/')
        return when {
            n == "AndroidManifest.xml" -> 0
            n.startsWith("build.gradle") || n.startsWith("settings.gradle") || n == "gradle.properties" -> 1
            f.extension.lowercase() in srcExts -> 2
            r.contains("/res/layout") || r.contains("/res/values") -> 3
            else -> 4
        }
    }

    private fun folder(dir: File, sb: StringBuilder, budget: Int) {
        sb.appendLine("Tipo: pasta/projeto")
        val summaryPos = sb.length
        fun rel(f: File) = f.relativeTo(dir).path

        val all = dir.walkTopDown().onEnter { it == dir || it.name !in skipDirs }.maxDepth(10)
            .filter { it.isFile }.take(5000).toList()
        sb.appendLine("\n## Estrutura (${all.size}${if (all.size == 5000) "+" else ""} arquivos)")
        all.take(400).forEach { sb.appendLine(rel(it) + "  (${FileUtils.readableSize(it.length())})") }
        if (all.size > 400) sb.appendLine("... e mais ${all.size - 400} arquivos")

        // ----- assets: lista, tipo e entropia dos binários -----
        val assets = all.filter { isAssetPath(rel(it)) }
        if (assets.isNotEmpty()) {
            sb.appendLine("\n## Assets (${assets.size} arquivos · ${FileUtils.readableSize(assets.sumOf { it.length() })})")
            assets.take(200).forEach { sb.appendLine(rel(it) + " (${FileUtils.readableSize(it.length())})") }
            if (assets.size > 200) sb.appendLine("... e mais ${assets.size - 200} assets")
            val bins = assets.filter { it.extension.lowercase() !in textAssetExts }.take(40)
            if (bins.isNotEmpty()) {
                sb.appendLine("\n### Assets binários (tipo detectado e entropia)")
                for (a in bins) {
                    val head = try { readUpTo(a, 65536) } catch (e: Exception) { ByteArray(0) }
                    val kind = magic(head)
                    val h = entropy(head, head.size)
                    val embedded = nestedExts.any { a.name.lowercase().endsWith(it) } ||
                        kind == "ELF" || kind.startsWith("DEX") || kind == "ZIP"
                    sb.appendLine("${rel(a)}: $kind, entropia ${"%.2f".format(h)}" +
                        if (embedded) " ⚠ código/pacote embutido" else "")
                }
            }
        }

        // ----- conteúdo: código primeiro, depois assets de texto -----
        val included = ArrayList<String>()
        val skipped = ArrayList<String>()
        fun pack(f: File, cap: Int, limit: Int): Boolean {
            val txt = try { f.readText() } catch (e: Exception) { return false }
            if (txt.indexOf('\u0000') >= 0) return false
            val body = if (txt.length > cap) txt.take(cap) + "\n...[truncado: ${txt.length} caracteres no total]" else txt
            val r = rel(f)
            if (sb.length + body.length + r.length + 20 > limit) return false
            sb.appendLine("\n### $r")
            sb.appendLine("```")
            sb.appendLine(body)
            sb.appendLine("```")
            return true
        }

        val codeFiles = all.filter { f ->
            !isAssetPath(rel(f)) && f.extension.lowercase() in codeExts && f.length() <= 400_000
        }.sortedWith(compareBy<File>({ priority(rel(it), it) }, { if (entryRe.containsMatchIn(it.name)) 0 else 1 }, { it.length() }))
        sb.appendLine("\n## Código-fonte e configuração")
        val codeLimit = (budget * 0.8).toInt()
        for (f in codeFiles) {
            if (pack(f, 60_000, codeLimit)) included.add(rel(f)) else skipped.add(rel(f))
        }

        val textAssets = assets.filter { it.extension.lowercase() in textAssetExts }.sortedBy { it.length() }
        if (textAssets.isNotEmpty()) {
            sb.appendLine("\n## Conteúdo dos assets de texto")
            for (f in textAssets) {
                if (pack(f, 20_000, budget - 8_000)) included.add(rel(f)) else skipped.add(rel(f))
            }
        }

        // ----- resumo do que foi (e do que não foi) enviado, no topo -----
        val summary = StringBuilder()
        summary.appendLine("\n## Resumo do que foi enviado")
        summary.appendLine("Arquivos com conteúdo enviado: ${included.size} · omitidos por limite de tamanho: ${skipped.size} · limite do contexto: $budget caracteres")
        if (skipped.isNotEmpty()) {
            summary.appendLine("Omitidos (conteúdo NÃO enviado):")
            skipped.take(60).forEach { summary.appendLine("- $it") }
            if (skipped.size > 60) summary.appendLine("- ... e mais ${skipped.size - 60}")
        }
        sb.insert(summaryPos, summary)
    }

    private fun assetDetails(zip: ZipFile, assets: List<ZipEntry>, sb: StringBuilder) {
        val texts = assets.filter {
            it.name.substringAfterLast('.').lowercase() in textAssetExts && it.size in 1..20_000
        }.sortedBy { it.size }
        var used = 0
        var count = 0
        if (texts.isNotEmpty()) sb.appendLine("\n### Conteúdo dos assets de texto")
        for (a in texts) {
            if (count >= 15 || used > 60_000) break
            val b = zip.bytes(a, 25_000) ?: continue
            val t = String(b, Charsets.UTF_8)
            sb.appendLine("#### ${a.name}")
            sb.appendLine("```")
            sb.appendLine(t)
            sb.appendLine("```")
            used += t.length
            count++
        }
        val bins = assets.filter { it.name.substringAfterLast('.').lowercase() !in textAssetExts }.take(30)
        if (bins.isNotEmpty()) {
            sb.appendLine("\n### Assets binários (tipo detectado e entropia)")
            for (a in bins) {
                val head = try { readHead(zip, a, 65536) } catch (e: Exception) { ByteArray(0) }
                val h = entropy(head, head.size)
                sb.appendLine("${a.name}: ${magic(head)}, entropia ${"%.2f".format(h)}" +
                    if (h > 7.5) " (alta: possivelmente criptografado/comprimido)" else "")
            }
        }
    }

    // ---------- arquivos compactados ----------
    private fun ZipFile.bytes(e: ZipEntry, max: Long = 64_000_000): ByteArray? =
        if (e.size > max) null else getInputStream(e).use { it.readBytes() }

    private fun archive(f: File, sb: StringBuilder) {
        sb.appendLine("Tipo: arquivo compactado (ZIP/APK/JAR) · ${FileUtils.readableSize(f.length())}")
        sb.appendLine("SHA-256: ${sha256(f)}")
        ZipFile(f).use { zip ->
            val entries = zip.entries().toList()
            sb.appendLine("Entradas: ${entries.size}")
            val manifest = entries.firstOrNull { it.name == "AndroidManifest.xml" }
            val dexRe = Regex("classes\\d*\\.dex")
            val dexEntries = entries.filter { dexRe.matches(it.name) }.sortedBy { it.name }
            if (manifest != null && dexEntries.isNotEmpty()) sb.appendLine("Detectado: APK Android")

            if (manifest != null) {
                val bytes = zip.bytes(manifest)
                if (bytes != null) {
                    val txt = if (Axml.isAxml(bytes)) {
                        try { Axml.decode(bytes) } catch (ex: Exception) { "(falha ao decodificar: ${ex.message})" }
                    } else String(bytes)
                    sb.appendLine("\n## AndroidManifest.xml (decodificado)")
                    sb.appendLine(txt.take(25_000))
                }
            }

            if (dexEntries.isNotEmpty()) {
                val allStrings = LinkedHashSet<String>()
                val allClasses = ArrayList<String>()
                var read = 0
                for (e in dexEntries.take(6)) {
                    val b = zip.bytes(e) ?: continue
                    if (!Dex.isDex(b)) continue
                    try {
                        val d = Dex.read(b)
                        allStrings.addAll(d.strings)
                        allClasses.addAll(d.defined)
                        read++
                    } catch (ex: Exception) {
                        sb.appendLine("(falha ao ler ${e.name}: ${ex.message})")
                    }
                }
                if (read > 0) dexReport(allStrings, allClasses, sb, read)
            }

            val classEntries = entries.filter { it.name.endsWith(".class") }
            if (classEntries.isNotEmpty()) {
                sb.appendLine("\n## Classes Java (.class): ${classEntries.size}")
                classEntries.groupingBy { it.name.split('/').dropLast(1).take(3).joinToString(".") }
                    .eachCount().entries.sortedByDescending { it.value }.take(30)
                    .forEach { sb.appendLine("${it.key}: ${it.value}") }
            }

            val libs = entries.filter { it.name.startsWith("lib/") && it.name.endsWith(".so") }
            if (libs.isNotEmpty()) {
                sb.appendLine("\n## Bibliotecas nativas (${libs.size})")
                libs.take(40).forEach { sb.appendLine("${it.name} (${FileUtils.readableSize(it.size)})") }
                val abis = libs.mapNotNull { it.name.split('/').getOrNull(1) }
                val abi = if ("arm64-v8a" in abis) "arm64-v8a" else abis.first()
                libs.filter { it.name.startsWith("lib/$abi/") }.sortedByDescending { it.size }.take(3).forEach { e ->
                    val b = zip.bytes(e, 30_000_000) ?: return@forEach
                    sb.appendLine("\n### ${e.name}")
                    elfInfo(b, sb)
                    nativeReport(b, sb)
                }
            }

            val assets = entries.filter { it.name.startsWith("assets/") && !it.isDirectory }
            if (assets.isNotEmpty()) {
                sb.appendLine("\n## Assets (${assets.size})")
                assets.sortedByDescending { it.size }.take(30)
                    .forEach { sb.appendLine("${it.name} (${FileUtils.readableSize(it.size)})") }
                val exts = listOf(".dex", ".jar", ".apk", ".so", ".zip", ".elf")
                val nested = assets.filter { a -> exts.any { a.name.lowercase().endsWith(it) } }
                if (nested.isNotEmpty()) {
                    sb.appendLine("⚠ Código/pacote embutido em assets (possível carga dinâmica): " +
                        nested.take(10).joinToString { it.name })
                }
                assetDetails(zip, assets, sb)
            }

            val certs = entries.filter {
                it.name.startsWith("META-INF/") &&
                    (it.name.endsWith(".RSA") || it.name.endsWith(".DSA") || it.name.endsWith(".EC"))
            }
            if (certs.isNotEmpty()) {
                sb.appendLine("\n## Assinatura (certificados)")
                certs.forEach { certInfo(zip, it, sb) }
            }

            val resCount = entries.count { it.name.startsWith("res/") }
            val others = entries.filter {
                !it.isDirectory && !it.name.startsWith("res/") && !it.name.startsWith("assets/") &&
                    !it.name.startsWith("lib/")
            }
            sb.appendLine("\n## Outras entradas (${others.size}) · res/: $resCount arquivos")
            others.take(100).forEach { sb.appendLine(it.name) }
        }
    }

    private fun certInfo(zip: ZipFile, e: ZipEntry, sb: StringBuilder) {
        try {
            val certs = zip.getInputStream(e).use { CertificateFactory.getInstance("X.509").generateCertificates(it) }
            for (c in certs) {
                if (c is X509Certificate) {
                    val fp = MessageDigest.getInstance("SHA-256").digest(c.encoded)
                        .joinToString(":") { "%02X".format(it) }
                    sb.appendLine("- ${e.name}: assunto=${c.subjectX500Principal.name}; validade=${c.notBefore} até ${c.notAfter}; SHA-256=$fp")
                }
            }
        } catch (ex: Exception) {
            sb.appendLine("- ${e.name}: não foi possível ler o certificado (${ex.message})")
        }
    }

    // ---------- DEX ----------
    private class Findings(val urls: List<String>, val others: List<String>)

    private fun findInteresting(strings: Collection<String>): Findings {
        val urls = LinkedHashSet<String>()
        val others = LinkedHashSet<String>()
        for (s in strings) {
            if (s.length < 6 || s.length > 300) continue
            if (classDesc.matches(s)) continue
            val u = urlRe.find(s)
            if (u != null) {
                if (urls.size < 80) urls.add(u.value)
                continue
            }
            if (others.size < 80 && (ipRe.containsMatchIn(s) || emailRe.containsMatchIn(s) || kwRe.containsMatchIn(s))) {
                others.add(s)
            }
            if (urls.size >= 80 && others.size >= 80) break
        }
        return Findings(urls.toList(), others.toList())
    }

    private fun dexReport(strings: Set<String>, defined: List<String>, sb: StringBuilder, dexCount: Int) {
        sb.appendLine("\n## Análise do DEX ($dexCount arquivo(s))")
        sb.appendLine("Classes definidas: ${defined.size} · Strings: ${strings.size}")
        val names = defined.map { Dex.pretty(it) }
        val short = names.count { it.substringAfterLast('.').length <= 2 }
        val ratio = if (names.isEmpty()) 0 else short * 100 / names.size
        sb.appendLine("Nomes de classe curtos (≤2 letras): $ratio%" + if (ratio >= 30) " → provável ofuscação (R8/ProGuard)" else "")
        sb.appendLine("\n### Pacotes (top 40)")
        names.groupingBy { it.split('.').take(3).joinToString(".") }.eachCount().entries
            .sortedByDescending { it.value }.take(40).forEach { sb.appendLine("${it.key}: ${it.value}") }
        val own = names.filter { n -> libPrefixes.none { n.startsWith(it) } }
        val limit = if (ratio >= 30) 60 else 200
        sb.appendLine("\n### Classes do app (${own.size}; mostrando ${minOf(limit, own.size)})")
        own.take(limit).forEach { sb.appendLine(it) }

        sb.appendLine("\n### Indicadores de comportamento (APIs/strings presentes)")
        var any = false
        for ((label, keys) in indicators) {
            val hit = keys.filter { it in strings }
            if (hit.isNotEmpty()) {
                any = true
                sb.appendLine("- $label: ${hit.joinToString(", ")}")
            }
        }
        if (!any) sb.appendLine("(nenhum)")
        val f = findInteresting(strings)
        if (f.urls.isNotEmpty()) {
            sb.appendLine("\n### URLs encontradas (${f.urls.size})")
            f.urls.forEach { sb.appendLine(it) }
        }
        if (f.others.isNotEmpty()) {
            sb.appendLine("\n### Strings interessantes (IPs, e-mails, chaves, cripto...)")
            f.others.forEach { sb.appendLine(it) }
        }
    }

    // ---------- binários ----------
    private fun readUpTo(f: File, max: Long): ByteArray {
        val size = minOf(f.length(), max).toInt()
        return f.inputStream().use { s ->
            val buf = ByteArray(size)
            var n = 0
            while (n < size) {
                val r = s.read(buf, n, size - n)
                if (r < 0) break
                n += r
            }
            buf.copyOf(n)
        }
    }

    private fun readHead(zip: ZipFile, e: ZipEntry, size: Int): ByteArray =
        zip.getInputStream(e).use { s ->
            val buf = ByteArray(size)
            var n = 0
            while (n < size) {
                val r = s.read(buf, n, size - n)
                if (r < 0) break
                n += r
            }
            buf.copyOf(n)
        }

    private fun sha256(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { s ->
            val buf = ByteArray(65536)
            while (true) {
                val n = s.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun entropy(b: ByteArray, n: Int): Double {
        if (n <= 0) return 0.0
        val c = IntArray(256)
        for (i in 0 until n) c[b[i].toInt() and 0xFF]++
        var h = 0.0
        for (x in c) if (x > 0) {
            val p = x.toDouble() / n
            h -= p * ln(p) / ln(2.0)
        }
        return h
    }

    private fun asciiStrings(b: ByteArray, min: Int): List<String> {
        val out = ArrayList<String>()
        var start = -1
        for (i in b.indices) {
            val c = b[i].toInt() and 0xFF
            if (c in 0x20..0x7E) {
                if (start < 0) start = i
            } else {
                if (start >= 0 && i - start >= min) out.add(String(b, start, minOf(i - start, 400), Charsets.US_ASCII))
                start = -1
            }
            if (out.size >= 400_000) break
        }
        if (start >= 0 && b.size - start >= min && out.size < 400_000) {
            out.add(String(b, start, minOf(b.size - start, 400), Charsets.US_ASCII))
        }
        return out
    }

    private fun magic(b: ByteArray): String {
        fun at(vararg v: Int) = v.size <= b.size && v.indices.all { (b[it].toInt() and 0xFF) == v[it] }
        return when {
            at(0x7F, 'E'.code, 'L'.code, 'F'.code) -> "ELF"
            at('M'.code, 'Z'.code) -> "PE/Windows (MZ)"
            at('d'.code, 'e'.code, 'x'.code, 0x0A) -> "DEX (Dalvik)"
            at(0xCA, 0xFE, 0xBA, 0xBE) -> "Java .class / Mach-O fat"
            at('P'.code, 'K'.code, 3, 4) -> "ZIP"
            at(0x89, 'P'.code, 'N'.code, 'G'.code) -> "PNG"
            at('%'.code, 'P'.code, 'D'.code, 'F'.code) -> "PDF"
            at(0x1F, 0x8B) -> "GZIP"
            at('7'.code, 'z'.code, 0xBC, 0xAF) -> "7z"
            at('S'.code, 'Q'.code, 'L'.code, 'i'.code, 't'.code, 'e'.code) -> "SQLite"
            at(0xFF, 0xD8, 0xFF) -> "JPEG"
            else -> "desconhecido"
        }
    }

    private fun elfInfo(b: ByteArray, sb: StringBuilder) {
        if (b.size < 20 || magic(b) != "ELF") return
        val cls = if (b[4].toInt() == 2) "64-bit" else "32-bit"
        val bb = ByteBuffer.wrap(b).order(if (b[5].toInt() == 2) ByteOrder.BIG_ENDIAN else ByteOrder.LITTLE_ENDIAN)
        val type = bb.getShort(16).toInt() and 0xFFFF
        val machine = bb.getShort(18).toInt() and 0xFFFF
        val arch = when (machine) {
            0x03 -> "x86"; 0x3E -> "x86-64"; 0x28 -> "ARM"; 0xB7 -> "AArch64"; 0x08 -> "MIPS"
            else -> "0x" + Integer.toHexString(machine)
        }
        val t = when (type) {
            1 -> "relocável"; 2 -> "executável"; 3 -> "biblioteca compartilhada"; else -> "tipo $type"
        }
        sb.appendLine("ELF $cls · $arch · $t")
    }

    private fun nativeReport(b: ByteArray, sb: StringBuilder) {
        val strs = asciiStrings(b, 4)
        val set = strs.toHashSet()
        val jni = strs.filter { it.startsWith("Java_") }.distinct().take(60)
        if (jni.isNotEmpty()) {
            sb.appendLine("Funções JNI exportadas (${jni.size}):")
            jni.forEach { sb.appendLine("  $it") }
        }
        val imports = nativeSensitive.filter { it in set }
        if (imports.isNotEmpty()) sb.appendLine("Funções sensíveis referenciadas: ${imports.joinToString(", ")}")
        val f = findInteresting(strs)
        if (f.urls.isNotEmpty()) {
            sb.appendLine("URLs:")
            f.urls.take(40).forEach { sb.appendLine("  $it") }
        }
        if (f.others.isNotEmpty()) {
            sb.appendLine("Strings interessantes:")
            f.others.take(40).forEach { sb.appendLine("  $it") }
        }
    }

    private fun binary(f: File, sb: StringBuilder) {
        val b = readUpTo(f, 30_000_000)
        val kind = magic(b)
        sb.appendLine("Tipo detectado: $kind · ${FileUtils.readableSize(f.length())}")
        sb.appendLine("SHA-256: ${sha256(f)}")
        val h = entropy(b, minOf(b.size, 2_000_000))
        sb.appendLine("Entropia (primeiros 2 MB): ${"%.2f".format(h)} / 8" +
            if (h > 7.5) " → muito alta: possivelmente comprimido, criptografado ou empacotado" else "")
        sb.appendLine("Primeiros bytes (hex): " + b.take(64).joinToString(" ") { "%02x".format(it) })
        when (kind) {
            "ELF" -> {
                elfInfo(b, sb)
                nativeReport(b, sb)
            }
            "DEX (Dalvik)" -> try {
                val d = Dex.read(b)
                dexReport(LinkedHashSet(d.strings), d.defined, sb, 1)
            } catch (e: Exception) {
                sb.appendLine("(falha ao ler DEX: ${e.message})")
            }
            else -> {
                val strs = asciiStrings(b, 4)
                val f2 = findInteresting(strs)
                if (f2.urls.isNotEmpty()) {
                    sb.appendLine("\n## URLs")
                    f2.urls.forEach { sb.appendLine(it) }
                }
                if (f2.others.isNotEmpty()) {
                    sb.appendLine("\n## Strings interessantes")
                    f2.others.forEach { sb.appendLine(it) }
                }
                sb.appendLine("\n## Amostra de strings (${strs.size} no total)")
                strs.filter { it.length >= 8 }.take(120).forEach { sb.appendLine(it) }
            }
        }
    }
}
