package com.zs.filemanager

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = Color(0xFF8AB4F8), onPrimary = Color(0xFF0B1D3A),
    primaryContainer = Color(0xFF2B3A55), onPrimaryContainer = Color(0xFFD6E3FF),
    secondary = Color(0xFF81C995), onSecondary = Color(0xFF0A2D14),
    secondaryContainer = Color(0xFF254D33), onSecondaryContainer = Color(0xFFCBEFD6),
    tertiary = Color(0xFFF2B86B), onTertiary = Color(0xFF3A2400),
    background = Color(0xFF121316), onBackground = Color(0xFFE6E8EC),
    surface = Color(0xFF121316), onSurface = Color(0xFFE6E8EC),
    surfaceVariant = Color(0xFF272B32), onSurfaceVariant = Color(0xFFA7AEBA),
    outline = Color(0xFF5B6372), outlineVariant = Color(0xFF3A4150),
    error = Color(0xFFF2B8B5), onError = Color(0xFF601410),
    surfaceContainerLowest = Color(0xFF0E0F12), surfaceContainerLow = Color(0xFF181A1E),
    surfaceContainer = Color(0xFF1D2025), surfaceContainerHigh = Color(0xFF23272D),
    surfaceContainerHighest = Color(0xFF2A2E35)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF1A5FD0), onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFD6E3FF), onPrimaryContainer = Color(0xFF001B3E),
    secondary = Color(0xFF1E7B3A), onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFCBEFD6), onSecondaryContainer = Color(0xFF00210C),
    tertiary = Color(0xFF8A5100), onTertiary = Color(0xFFFFFFFF),
    background = Color(0xFFFAFBFD), onBackground = Color(0xFF1B1D21),
    surface = Color(0xFFFAFBFD), onSurface = Color(0xFF1B1D21),
    surfaceVariant = Color(0xFFE1E5EC), onSurfaceVariant = Color(0xFF4A5160),
    outline = Color(0xFF7A8293), outlineVariant = Color(0xFFC3C9D4),
    error = Color(0xFFB3261E), onError = Color(0xFFFFFFFF),
    surfaceContainerLowest = Color(0xFFFFFFFF), surfaceContainerLow = Color(0xFFF4F6FA),
    surfaceContainer = Color(0xFFEEF1F6), surfaceContainerHigh = Color(0xFFE8ECF2),
    surfaceContainerHighest = Color(0xFFE1E5EC)
)

@Composable
fun ZsTheme(mode: String, content: @Composable () -> Unit) {
    val dark = when (mode) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}
