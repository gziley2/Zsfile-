package com.zs.filemanager

import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.DisplayMetrics
import android.util.TypedValue
import android.util.Xml
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.constraintlayout.widget.ConstraintLayout
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.io.StringReader

class Node(
    val tag: String,
    val attrs: Map<String, String>,
    val children: MutableList<Node> = mutableListOf()
)

fun parseNode(xml: String): Node? {
    val p = Xml.newPullParser()
    p.setInput(StringReader(xml))
    val stack = mutableListOf<Node>()
    var root: Node? = null
    var ev = p.eventType
    while (ev != XmlPullParser.END_DOCUMENT) {
        when (ev) {
            XmlPullParser.START_TAG -> {
                val a = HashMap<String, String>()
                for (i in 0 until p.attributeCount) a[p.getAttributeName(i)] = p.getAttributeValue(i)
                val n = Node(p.name, a)
                stack.lastOrNull()?.children?.add(n)
                if (root == null) root = n
                stack.add(n)
            }
            XmlPullParser.END_TAG -> if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex)
        }
        ev = p.next()
    }
    return root
}

private fun gravity(v: String?): Int {
    var g = 0
    v?.split('|')?.forEach {
        g = g or when (it.trim()) {
            "center" -> Gravity.CENTER
            "center_horizontal" -> Gravity.CENTER_HORIZONTAL
            "center_vertical" -> Gravity.CENTER_VERTICAL
            "left" -> Gravity.LEFT
            "right" -> Gravity.RIGHT
            "top" -> Gravity.TOP
            "bottom" -> Gravity.BOTTOM
            "start" -> Gravity.START
            "end" -> Gravity.END
            "fill" -> Gravity.FILL
            "fill_horizontal" -> Gravity.FILL_HORIZONTAL
            "fill_vertical" -> Gravity.FILL_VERTICAL
            else -> 0
        }
    }
    return g
}

/** Lê os XMLs da pasta values (strings, colors, dimens) e resolve @recursos do projeto. */
class ProjectRes(val resDir: File?) {
    private val strings = HashMap<String, String>()
    private val colors = HashMap<String, String>()
    private val dimens = HashMap<String, String>()

    init {
        resDir?.listFiles { f -> f.isDirectory && f.name.startsWith("values") }
            ?.sortedBy { it.name }
            ?.forEach { d ->
                d.listFiles { f -> f.isFile && f.extension == "xml" }?.forEach { f ->
                    try {
                        parseValues(f)
                    } catch (e: Exception) {
                    }
                }
            }
    }

    private fun parseValues(f: File) {
        val p = Xml.newPullParser()
        f.reader().use { r ->
            p.setInput(r)
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG) {
                    val name = p.getAttributeValue(null, "name")
                    val target = when (p.name) {
                        "string" -> strings
                        "color" -> colors
                        "dimen" -> dimens
                        else -> null
                    }
                    if (target != null && name != null) {
                        val v = p.nextText().trim()
                        if (name !in target) target[name] = v
                    }
                }
                ev = p.next()
            }
        }
    }

    fun str(v: String?): String? {
        if (v == null) return null
        val raw = when {
            v.startsWith("@string/") -> strings[v.removePrefix("@string/")] ?: v.removePrefix("@string/")
            v.startsWith("@android:string/") -> v.substringAfter('/')
            else -> v
        }
        return raw.removeSurrounding("\"").replace("\\n", "\n").replace("\\'", "'").replace("\\\"", "\"")
    }

    private fun normalizeHex(s: String): String {
        val h = s.drop(1)
        return if (h.length == 3 || h.length == 4) "#" + h.map { "$it$it" }.joinToString("") else s
    }

    fun color(v: String?, depth: Int = 0): Int? {
        if (v == null || depth > 5) return null
        val s = v.trim()
        return try {
            when {
                s.startsWith("#") -> Color.parseColor(normalizeHex(s))
                s.startsWith("@color/") -> color(colors[s.removePrefix("@color/")], depth + 1)
                s.startsWith("@android:color/") -> when (s.substringAfter('/')) {
                    "white" -> Color.WHITE
                    "black" -> Color.BLACK
                    "transparent" -> Color.TRANSPARENT
                    "darker_gray" -> Color.DKGRAY
                    else -> null
                }
                else -> null
            }
        } catch (e: IllegalArgumentException) {
            null
        }
    }

    fun dim(v: String?, dm: DisplayMetrics): Float? {
        if (v == null) return null
        val s = (if (v.startsWith("@dimen/")) dimens[v.removePrefix("@dimen/")] ?: return null else v).trim()
        val m = Regex("^(-?[0-9.]+)(dp|dip|sp|px|pt|in|mm)$").find(s) ?: return null
        val n = m.groupValues[1].toFloatOrNull() ?: return null
        val unit = when (m.groupValues[2]) {
            "dp", "dip" -> TypedValue.COMPLEX_UNIT_DIP
            "sp" -> TypedValue.COMPLEX_UNIT_SP
            "px" -> TypedValue.COMPLEX_UNIT_PX
            "pt" -> TypedValue.COMPLEX_UNIT_PT
            "in" -> TypedValue.COMPLEX_UNIT_IN
            else -> TypedValue.COMPLEX_UNIT_MM
        }
        return TypedValue.applyDimension(unit, n, dm)
    }

    fun findLayout(name: String): File? {
        val dirs = resDir?.listFiles { f -> f.isDirectory && f.name.startsWith("layout") }
            ?.sortedBy { it.name.length } ?: return null
        for (d in dirs) {
            val f = File(d, "$name.xml")
            if (f.exists()) return f
        }
        return null
    }

    fun drawable(ctx: Context, v: String?, depth: Int = 0): Drawable? {
        if (v == null || depth > 4) return null
        color(v)?.let { return ColorDrawable(it) }
        if (!(v.startsWith("@drawable/") || v.startsWith("@mipmap/"))) return null
        val name = v.substringAfter('/')
        val dirs = resDir?.listFiles { f ->
            f.isDirectory && (f.name.startsWith("drawable") || f.name.startsWith("mipmap"))
        }?.sortedByDescending { it.name } ?: return null
        val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
        for (d in dirs) {
            for (ext in listOf("png", "jpg", "jpeg", "webp")) {
                val f = File(d, "$name.$ext")
                if (f.exists()) {
                    BitmapFactory.decodeFile(f.path, opts)?.let { return BitmapDrawable(ctx.resources, it) }
                }
            }
        }
        for (d in dirs) {
            val f = File(d, "$name.xml")
            if (f.exists()) return xmlDrawable(ctx, f, depth)
        }
        return null
    }

    private fun xmlDrawable(ctx: Context, f: File, depth: Int): Drawable? {
        val root = try { parseNode(f.readText()) } catch (e: Exception) { null } ?: return null
        val dm = ctx.resources.displayMetrics
        if (root.tag == "selector") {
            val item = root.children.lastOrNull() ?: return null
            return drawable(ctx, item.attrs["android:drawable"] ?: item.attrs["android:color"], depth + 1)
        }
        if (root.tag != "shape") return null
        val gd = GradientDrawable()
        gd.shape = when (root.attrs["android:shape"]) {
            "oval" -> GradientDrawable.OVAL
            "line" -> GradientDrawable.LINE
            "ring" -> GradientDrawable.RING
            else -> GradientDrawable.RECTANGLE
        }
        for (c in root.children) {
            when (c.tag) {
                "solid" -> color(c.attrs["android:color"])?.let { gd.setColor(it) }
                "corners" -> dim(c.attrs["android:radius"], dm)?.let { gd.cornerRadius = it }
                "stroke" -> {
                    val w = dim(c.attrs["android:width"], dm)
                    val col = color(c.attrs["android:color"])
                    if (w != null && col != null) gd.setStroke(w.toInt(), col)
                }
            }
        }
        return gd
    }
}

/** Constrói Views reais do Android a partir do XML, sem precisar compilar o projeto. */
class LayoutBuilder(private val ctx: Context, private val res: ProjectRes) {
    private val dm = ctx.resources.displayMetrics
    private val ids = HashMap<String, Int>()

    private val relBool = mapOf(
        "layout_alignParentTop" to RelativeLayout.ALIGN_PARENT_TOP,
        "layout_alignParentBottom" to RelativeLayout.ALIGN_PARENT_BOTTOM,
        "layout_alignParentLeft" to RelativeLayout.ALIGN_PARENT_LEFT,
        "layout_alignParentRight" to RelativeLayout.ALIGN_PARENT_RIGHT,
        "layout_alignParentStart" to RelativeLayout.ALIGN_PARENT_START,
        "layout_alignParentEnd" to RelativeLayout.ALIGN_PARENT_END,
        "layout_centerInParent" to RelativeLayout.CENTER_IN_PARENT,
        "layout_centerHorizontal" to RelativeLayout.CENTER_HORIZONTAL,
        "layout_centerVertical" to RelativeLayout.CENTER_VERTICAL
    )
    private val relId = mapOf(
        "layout_above" to RelativeLayout.ABOVE,
        "layout_below" to RelativeLayout.BELOW,
        "layout_toLeftOf" to RelativeLayout.LEFT_OF,
        "layout_toRightOf" to RelativeLayout.RIGHT_OF,
        "layout_toStartOf" to RelativeLayout.START_OF,
        "layout_toEndOf" to RelativeLayout.END_OF,
        "layout_alignTop" to RelativeLayout.ALIGN_TOP,
        "layout_alignBottom" to RelativeLayout.ALIGN_BOTTOM,
        "layout_alignLeft" to RelativeLayout.ALIGN_LEFT,
        "layout_alignRight" to RelativeLayout.ALIGN_RIGHT,
        "layout_alignStart" to RelativeLayout.ALIGN_START,
        "layout_alignEnd" to RelativeLayout.ALIGN_END,
        "layout_alignBaseline" to RelativeLayout.ALIGN_BASELINE
    )

    private fun idOf(ref: String): Int = ids.getOrPut(ref.substringAfterLast('/')) { View.generateViewId() }
    private fun dp(v: Float): Int = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, dm).toInt()
    private fun px(a: Map<String, String>, key: String): Int? = res.dim(a[key], dm)?.toInt()

    private fun size(v: String?): Int = when (v) {
        "match_parent", "fill_parent" -> ViewGroup.LayoutParams.MATCH_PARENT
        "wrap_content", null -> ViewGroup.LayoutParams.WRAP_CONTENT
        else -> res.dim(v, dm)?.toInt() ?: ViewGroup.LayoutParams.WRAP_CONTENT
    }

    fun inflateInto(node: Node, parent: ViewGroup, depth: Int) {
        if (depth > 10) throw IllegalStateException("Include recursivo demais")
        when (node.tag) {
            "merge" -> {
                node.children.forEach { inflateInto(it, parent, depth + 1) }
                return
            }
            "include" -> {
                val name = node.attrs["layout"]?.substringAfter('/') ?: return
                val file = res.findLayout(name) ?: throw IllegalStateException("Layout não encontrado: $name")
                val inc = parseNode(file.readText()) ?: return
                val overrides = node.attrs.filterKeys { it.startsWith("android:layout_") || it == "android:id" }
                inflateInto(Node(inc.tag, inc.attrs + overrides, inc.children), parent, depth + 1)
                return
            }
        }
        val a = node.attrs
        val sn = node.tag.substringAfterLast('.')
        val view = createView(node, sn)
        applyCommon(view, a)
        if (view is TextView) applyText(view, a)
        if (view is CompoundButton) view.isChecked = a["android:checked"] == "true"
        if (view is ImageView) applyImage(view, a)
        if (view is ProgressBar) {
            a["android:max"]?.toIntOrNull()?.let { view.max = it }
            a["android:progress"]?.toIntOrNull()?.let { view.progress = it }
        }
        parent.addView(view, makeParams(parent, a))
        if (view is ViewGroup) node.children.forEach { inflateInto(it, view, depth + 1) }
    }

    private fun orient(a: Map<String, String>, default: Int): Int = when (a["android:orientation"]) {
        "vertical" -> LinearLayout.VERTICAL
        "horizontal" -> LinearLayout.HORIZONTAL
        else -> default
    }

    private fun createView(node: Node, sn: String): View {
        val a = node.attrs
        return when {
            sn.contains("RadioGroup") -> RadioGroup(ctx).also { it.orientation = orient(a, LinearLayout.VERTICAL) }
            sn.contains("Linear") -> LinearLayout(ctx).also {
                it.orientation = orient(a, LinearLayout.HORIZONTAL)
                gravity(a["android:gravity"]).takeIf { g -> g != 0 }?.let { g -> it.gravity = g }
                a["android:weightSum"]?.toFloatOrNull()?.let { w -> it.weightSum = w }
            }
            sn.contains("Constraint") -> ConstraintLayout(ctx)
            sn.contains("Relative") -> RelativeLayout(ctx)
            sn.contains("Scroll") ->
                if (sn.contains("Horizontal")) HorizontalScrollView(ctx)
                else ScrollView(ctx).also { it.isFillViewport = a["android:fillViewport"] == "true" }
            sn.contains("CardView") -> FrameLayout(ctx).also { f ->
                val r = res.dim(a["app:cardCornerRadius"], dm) ?: dp(4f).toFloat()
                f.background = GradientDrawable().apply {
                    cornerRadius = r
                    setColor(res.color(a["app:cardBackgroundColor"]) ?: Color.WHITE)
                    setStroke(1, 0x22000000)
                }
                f.elevation = res.dim(a["app:cardElevation"], dm) ?: 0f
                px(a, "app:contentPadding")?.let { p -> f.setPadding(p, p, p, p) }
            }
            sn.contains("RecyclerView") || sn.contains("ListView") || sn.contains("GridView") ||
                sn.contains("ViewPager") || sn.contains("WebView") || sn.contains("MapView") ||
                sn.contains("Fragment") || sn.contains("SurfaceView") || sn.contains("VideoView") -> placeholder(sn)
            sn.contains("ImageView") || sn.contains("ImageButton") -> ImageView(ctx)
            sn.contains("RadioButton") -> RadioButton(ctx)
            sn.contains("CheckBox") -> CheckBox(ctx)
            sn.contains("Switch") -> Switch(ctx)
            sn.contains("Button") -> Button(ctx)
            sn.contains("EditText") -> EditText(ctx)
            sn.contains("TextView") -> TextView(ctx)
            sn.contains("ProgressBar") -> ProgressBar(
                ctx, null,
                if (a["style"]?.contains("Horizontal") == true) android.R.attr.progressBarStyleHorizontal
                else android.R.attr.progressBarStyle
            )
            sn.contains("SeekBar") -> SeekBar(ctx)
            sn == "View" || sn == "Space" -> View(ctx)
            node.children.isNotEmpty() -> FrameLayout(ctx)
            else -> placeholder(sn)
        }
    }

    private fun placeholder(sn: String): TextView = TextView(ctx).apply {
        text = sn
        gravity = Gravity.CENTER
        setTextColor(0xFF666666.toInt())
        setBackgroundColor(0xFFE0E0E0.toInt())
        setPadding(dp(8f), dp(8f), dp(8f), dp(8f))
        minHeight = dp(48f)
    }

    private fun applyCommon(v: View, a: Map<String, String>) {
        a["android:id"]?.let { v.id = idOf(it) }
        res.drawable(ctx, a["android:background"])?.let { v.background = it }
        val pad = px(a, "android:padding")
        var l = pad ?: 0
        var t = pad ?: 0
        var r = pad ?: 0
        var b = pad ?: 0
        px(a, "android:paddingHorizontal")?.let { l = it; r = it }
        px(a, "android:paddingVertical")?.let { t = it; b = it }
        (px(a, "android:paddingLeft") ?: px(a, "android:paddingStart"))?.let { l = it }
        px(a, "android:paddingTop")?.let { t = it }
        (px(a, "android:paddingRight") ?: px(a, "android:paddingEnd"))?.let { r = it }
        px(a, "android:paddingBottom")?.let { b = it }
        if ((l or t or r or b) != 0) v.setPadding(l, t, r, b)
        when (a["android:visibility"]) {
            "gone" -> v.visibility = View.GONE
            "invisible" -> v.visibility = View.INVISIBLE
        }
        a["android:alpha"]?.toFloatOrNull()?.let { v.alpha = it }
        px(a, "android:minWidth")?.let { v.minimumWidth = it }
        px(a, "android:minHeight")?.let { v.minimumHeight = it }
        res.dim(a["android:elevation"], dm)?.let { v.elevation = it }
    }

    private fun applyText(t: TextView, a: Map<String, String>) {
        (res.str(a["android:text"]) ?: res.str(a["tools:text"]))?.let { t.text = it }
        (res.str(a["android:hint"]) ?: res.str(a["tools:hint"]))?.let { t.hint = it }
        res.dim(a["android:textSize"], dm)?.let { t.setTextSize(TypedValue.COMPLEX_UNIT_PX, it) }
        res.color(a["android:textColor"])?.let { t.setTextColor(it) }
        res.color(a["android:textColorHint"])?.let { t.setHintTextColor(it) }
        val style = a["android:textStyle"] ?: ""
        val tf = when {
            "bold" in style && "italic" in style -> Typeface.BOLD_ITALIC
            "bold" in style -> Typeface.BOLD
            "italic" in style -> Typeface.ITALIC
            else -> -1
        }
        if (tf >= 0) t.setTypeface(t.typeface, tf)
        gravity(a["android:gravity"]).takeIf { it != 0 }?.let { t.gravity = it }
        a["android:maxLines"]?.toIntOrNull()?.let { t.maxLines = it }
        a["android:lines"]?.toIntOrNull()?.let { t.setLines(it) }
        if (a["android:singleLine"] == "true") t.setSingleLine()
        if (a["android:textAllCaps"] == "true") t.setAllCaps(true)
        if (a["android:textAllCaps"] == "false") t.setAllCaps(false)
        if (a["android:ellipsize"] == "end") t.ellipsize = TextUtils.TruncateAt.END
    }

    private fun applyImage(iv: ImageView, a: Map<String, String>) {
        val src = res.drawable(ctx, a["android:src"] ?: a["app:srcCompat"] ?: a["tools:src"])
        if (src != null) {
            iv.setImageDrawable(src)
        } else {
            iv.minimumWidth = dp(48f)
            iv.minimumHeight = dp(48f)
            if (a["android:background"] == null) iv.setBackgroundColor(0x22000000)
        }
        iv.scaleType = when (a["android:scaleType"]) {
            "centerCrop" -> ImageView.ScaleType.CENTER_CROP
            "fitXY" -> ImageView.ScaleType.FIT_XY
            "centerInside" -> ImageView.ScaleType.CENTER_INSIDE
            "center" -> ImageView.ScaleType.CENTER
            "fitStart" -> ImageView.ScaleType.FIT_START
            "fitEnd" -> ImageView.ScaleType.FIT_END
            else -> ImageView.ScaleType.FIT_CENTER
        }
        if (a["android:adjustViewBounds"] == "true") iv.adjustViewBounds = true
    }

    private fun makeParams(parent: ViewGroup, a: Map<String, String>): ViewGroup.LayoutParams {
        val w = size(a["android:layout_width"])
        val h = size(a["android:layout_height"])
        val lp: ViewGroup.MarginLayoutParams = when (parent) {
            is LinearLayout -> LinearLayout.LayoutParams(w, h).also { p ->
                a["android:layout_weight"]?.toFloatOrNull()?.let { p.weight = it }
                gravity(a["android:layout_gravity"]).takeIf { it != 0 }?.let { p.gravity = it }
            }
            is RelativeLayout -> RelativeLayout.LayoutParams(w, h).also { p -> relative(p, a) }
            is ConstraintLayout -> ConstraintLayout.LayoutParams(w, h).also { p -> constraint(p, a) }
            is FrameLayout -> FrameLayout.LayoutParams(w, h).also { p ->
                gravity(a["android:layout_gravity"]).takeIf { it != 0 }?.let { p.gravity = it }
            }
            else -> ViewGroup.MarginLayoutParams(w, h)
        }
        val m = px(a, "android:layout_margin")
        var ml = m ?: 0
        var mt = m ?: 0
        var mr = m ?: 0
        var mb = m ?: 0
        px(a, "android:layout_marginHorizontal")?.let { ml = it; mr = it }
        px(a, "android:layout_marginVertical")?.let { mt = it; mb = it }
        (px(a, "android:layout_marginLeft") ?: px(a, "android:layout_marginStart"))?.let { ml = it }
        px(a, "android:layout_marginTop")?.let { mt = it }
        (px(a, "android:layout_marginRight") ?: px(a, "android:layout_marginEnd"))?.let { mr = it }
        px(a, "android:layout_marginBottom")?.let { mb = it }
        lp.setMargins(ml, mt, mr, mb)
        return lp
    }

    private fun relative(p: RelativeLayout.LayoutParams, a: Map<String, String>) {
        relBool.forEach { (k, rule) -> if (a["android:$k"] == "true") p.addRule(rule) }
        relId.forEach { (k, rule) -> a["android:$k"]?.let { p.addRule(rule, idOf(it)) } }
    }

    private fun constraint(p: ConstraintLayout.LayoutParams, a: Map<String, String>) {
        fun id(k: String): Int? {
            val v = a["app:$k"] ?: return null
            return if (v == "parent") ConstraintLayout.LayoutParams.PARENT_ID else idOf(v)
        }
        fun chain(v: String): Int = when (v) {
            "spread_inside" -> 1
            "packed" -> 2
            else -> 0
        }
        id("layout_constraintLeft_toLeftOf")?.let { p.leftToLeft = it }
        id("layout_constraintLeft_toRightOf")?.let { p.leftToRight = it }
        id("layout_constraintRight_toLeftOf")?.let { p.rightToLeft = it }
        id("layout_constraintRight_toRightOf")?.let { p.rightToRight = it }
        id("layout_constraintTop_toTopOf")?.let { p.topToTop = it }
        id("layout_constraintTop_toBottomOf")?.let { p.topToBottom = it }
        id("layout_constraintBottom_toTopOf")?.let { p.bottomToTop = it }
        id("layout_constraintBottom_toBottomOf")?.let { p.bottomToBottom = it }
        id("layout_constraintBaseline_toBaselineOf")?.let { p.baselineToBaseline = it }
        id("layout_constraintStart_toStartOf")?.let { p.startToStart = it }
        id("layout_constraintStart_toEndOf")?.let { p.startToEnd = it }
        id("layout_constraintEnd_toStartOf")?.let { p.endToStart = it }
        id("layout_constraintEnd_toEndOf")?.let { p.endToEnd = it }
        a["app:layout_constraintHorizontal_bias"]?.toFloatOrNull()?.let { p.horizontalBias = it }
        a["app:layout_constraintVertical_bias"]?.toFloatOrNull()?.let { p.verticalBias = it }
        a["app:layout_constraintDimensionRatio"]?.let { p.dimensionRatio = it }
        a["app:layout_constraintHorizontal_chainStyle"]?.let { p.horizontalChainStyle = chain(it) }
        a["app:layout_constraintVertical_chainStyle"]?.let { p.verticalChainStyle = chain(it) }
        a["app:layout_constraintHorizontal_weight"]?.toFloatOrNull()?.let { p.horizontalWeight = it }
        a["app:layout_constraintVertical_weight"]?.toFloatOrNull()?.let { p.verticalWeight = it }
    }
}

object LayoutPreview {
    fun findResDir(file: File): File? =
        generateSequence(file.parentFile) { it.parentFile }.take(6).firstOrNull { it.name == "res" }

    /** Raiz da prévia: [0] = conteúdo, [1] = faixa de erro. */
    fun createRoot(base: Context): FrameLayout {
        val ctx = ContextThemeWrapper(base, android.R.style.Theme_Material_Light_NoActionBar)
        return FrameLayout(ctx).apply {
            setBackgroundColor(Color.WHITE)
            addView(
                FrameLayout(ctx),
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            )
            addView(
                TextView(ctx).apply {
                    setTextColor(0xFFB00020.toInt())
                    setBackgroundColor(0xEEFFEBEE.toInt())
                    textSize = 12f
                    setPadding(24, 16, 24, 16)
                    visibility = View.GONE
                },
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP
                )
            )
        }
    }

    /** Se o XML tiver erro, mantém a última prévia boa e mostra o aviso no topo. */
    fun render(root: FrameLayout, xml: String, file: File, res: ProjectRes) {
        val ctx = root.context
        val banner = root.getChildAt(1) as TextView
        try {
            val node = parseNode(xml) ?: throw IllegalStateException("XML vazio")
            val content = FrameLayout(ctx)
            LayoutBuilder(ctx, res).inflateInto(node, content, 0)
            root.removeViewAt(0)
            root.addView(
                content, 0,
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            )
            banner.visibility = View.GONE
        } catch (e: Exception) {
            banner.text = "⚠ " + (e.message ?: e.javaClass.simpleName).take(200)
            banner.visibility = View.VISIBLE
        }
    }
}
