package com.zs.filemanager

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.io.File

class MainActivity : ComponentActivity() {
    private val granted = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        granted.value = hasAccess()
        setContent {
            var mode by remember { mutableStateOf(AppPrefs.theme(this@MainActivity)) }
            ZsTheme(mode) {
                Surface(Modifier.fillMaxSize()) {
                    if (granted.value) {
                        App(mode) {
                            mode = it
                            AppPrefs.setTheme(this@MainActivity, it)
                        }
                    } else {
                        PermissionScreen { requestAccess() }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        granted.value = hasAccess()
    }

    private fun hasAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) Environment.isExternalStorageManager()
        else ContextCompat.checkSelfPermission(
            this, Manifest.permission.WRITE_EXTERNAL_STORAGE
        ) == PackageManager.PERMISSION_GRANTED

    private fun requestAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            requestPermissions(
                arrayOf(
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                ), 1
            )
        }
    }
}

@Composable
fun PermissionScreen(onRequest: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(ZIcons.Folder, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(64.dp))
        Spacer(Modifier.height(16.dp))
        Text("ZS Files", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(12.dp))
        Text(
            "Para gerenciar, editar e analisar seus arquivos, o app precisa de acesso a todos os arquivos do aparelho. " +
                "Nada é enviado para a internet sem você pedir uma análise com IA.",
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onRequest) { Text("Conceder acesso") }
    }
}

@Composable
fun App(themeMode: String, onThemeChange: (String) -> Unit) {
    val context = LocalContext.current
    val root = remember { Environment.getExternalStorageDirectory() }
    var currentPath by rememberSaveable { mutableStateOf(root.absolutePath) }
    // 0 = Arquivos, 1 = Editor, 2 = Ferramentas, 3 = Ajustes
    var section by remember { mutableIntStateOf(0) }
    val tabs = remember { mutableStateListOf<EditorTab>() }
    var currentTab by remember { mutableIntStateOf(0) }
    var clipboard by remember { mutableStateOf<Clipboard?>(null) }
    var analyzeTarget by remember { mutableStateOf<AnalyzeRequest?>(null) }
    var hexTarget by remember { mutableStateOf<File?>(null) }
    var showApk by remember { mutableStateOf(false) }
    var picker by remember { mutableStateOf<String?>(null) }
    var agentTarget by remember { mutableStateOf<File?>(null) }
    val agentSessions = remember { mutableMapOf<String, AgentSession>() }

    fun toast(m: String) = Toast.makeText(context, m, Toast.LENGTH_SHORT).show()

    fun openInEditor(file: File) {
        val existing = tabs.indexOfFirst { it.file.absolutePath == file.absolutePath }
        if (existing >= 0) {
            currentTab = existing; section = 1; return
        }
        if (file.length() > 5_000_000) {
            toast("Arquivo grande: abrindo no visualizador hex"); hexTarget = file; return
        }
        if (!FileUtils.isProbablyText(file)) {
            hexTarget = file; return
        }
        try {
            val tab = EditorTab(file, file.readText())
            if (FileUtils.isLayoutXml(file)) tab.previewMode = 2
            tabs.add(tab)
            currentTab = tabs.lastIndex
            section = 1
        } catch (e: Exception) {
            toast("Erro ao abrir: ${e.message}")
        }
    }

    val req = analyzeTarget
    val agent = agentTarget
    val hex = hexTarget
    if (hex != null) {
        BackHandler { hexTarget = null }
        HexScreen(hex) { hexTarget = null }
    } else if (agent != null) {
        BackHandler { agentTarget = null }
        val sess = agentSessions.getOrPut(agent.absolutePath) { AgentSession(context, agent) }
        AgentScreen(
            session = sess,
            onBack = { agentTarget = null },
            onOpenFile = { openInEditor(it); agentTarget = null },
            onBeforeRun = {
                // salva edições pendentes dos arquivos deste projeto antes de a IA mexer
                tabs.filter { t -> t.dirty && t.file.absolutePath.startsWith(agent.absolutePath + "/") }.forEach { t -> t.save() }
            },
            onFilesChanged = { files ->
                files.forEach { f ->
                    val tab = tabs.firstOrNull { it.file.absolutePath == f.absolutePath }
                    if (tab != null && !tab.dirty && f.isFile) {
                        try { tab.reload(f.readText()) } catch (e: Exception) { }
                    }
                }
            }
        )
    } else if (req != null) {
        BackHandler { analyzeTarget = null }
        AnalysisScreen(req.file, req.textOverride, req.initialPrompt) { analyzeTarget = null }
    } else if (showApk) {
        BackHandler { showApk = false }
        ApkExtractorScreen(
            onBack = { showApk = false },
            onAnalyze = { analyzeTarget = AnalyzeRequest(it, null) },
            onShowFolder = { currentPath = it.absolutePath; showApk = false; section = 0 }
        )
    } else {
        BackHandler(enabled = section != 0) { section = 0 }
        Scaffold(
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(
                        selected = section == 0, onClick = { section = 0 },
                        icon = { Icon(ZIcons.Folder, contentDescription = null) }, label = { Text("Arquivos") }
                    )
                    NavigationBarItem(
                        selected = section == 1, onClick = { section = 1 },
                        icon = {
                            BadgedBox(badge = { if (tabs.isNotEmpty()) Badge { Text("${tabs.size}") } }) {
                                Icon(ZIcons.Code, contentDescription = null)
                            }
                        },
                        label = { Text("Editor") }
                    )
                    NavigationBarItem(
                        selected = section == 2, onClick = { section = 2 },
                        icon = { Icon(ZIcons.Tools, contentDescription = null) }, label = { Text("Ferramentas") }
                    )
                    NavigationBarItem(
                        selected = section == 3, onClick = { section = 3 },
                        icon = { Icon(ZIcons.Settings, contentDescription = null) }, label = { Text("Ajustes") }
                    )
                }
            }
        ) { inner ->
            Box(Modifier.padding(inner).fillMaxSize()) {
                when (section) {
                    0 -> FileManagerScreen(
                        root = root,
                        currentPath = currentPath,
                        onPathChange = { currentPath = it },
                        clipboard = clipboard,
                        onClipboardChange = { clipboard = it },
                        openTabs = tabs.size,
                        onShowEditor = { section = 1 },
                        onOpenFile = { openInEditor(it) },
                        onAnalyze = { analyzeTarget = AnalyzeRequest(it, null) },
                        onOpenHex = { hexTarget = it },
                        onOpenApkExtractor = { showApk = true },
                        onConvertJava = { analyzeTarget = AnalyzeRequest(it, null, PROMPT_SMALI_TO_JAVA) },
                        onAgent = { agentTarget = it }
                    )
                    1 -> if (tabs.isNotEmpty()) {
                        EditorScreen(
                            tabs = tabs,
                            current = currentTab,
                            onSelect = { currentTab = it },
                            onCloseTab = { i ->
                                tabs.removeAt(i)
                                if (tabs.isEmpty()) {
                                    section = 0
                                    currentTab = 0
                                } else {
                                    val c = if (i <= currentTab) currentTab - 1 else currentTab
                                    currentTab = c.coerceIn(0, tabs.lastIndex)
                                }
                            },
                            onBack = { section = 0 },
                            onAnalyze = { f, t -> analyzeTarget = AnalyzeRequest(f, t) },
                            onConvertJava = { f, t -> analyzeTarget = AnalyzeRequest(f, t, PROMPT_SMALI_TO_JAVA) }
                        )
                    } else {
                        EmptyEditor { section = 0 }
                    }
                    2 -> ToolsScreen(
                        onApkExtractor = { showApk = true },
                        onHex = { picker = "hex" },
                        onAnalyze = { picker = "ai" },
                        onAgent = { picker = "agent" }
                    )
                    else -> SettingsScreen(themeMode, onThemeChange)
                }
            }
        }
        val pk = picker
        if (pk != null) {
            FilePickerDialog(
                root = root,
                startPath = currentPath,
                title = when (pk) {
                    "hex" -> "Escolha um arquivo"
                    "agent" -> "Escolha a pasta do projeto"
                    else -> "Escolha um arquivo ou pasta"
                },
                allowFolder = pk == "ai" || pk == "agent",
                onPick = { f ->
                    picker = null
                    if (pk == "hex") {
                        if (f.isFile) hexTarget = f
                    } else if (pk == "agent") {
                        agentTarget = if (f.isDirectory) f else f.parentFile
                    } else {
                        analyzeTarget = AnalyzeRequest(f, null)
                    }
                },
                onDismiss = { picker = null }
            )
        }
    }
}
