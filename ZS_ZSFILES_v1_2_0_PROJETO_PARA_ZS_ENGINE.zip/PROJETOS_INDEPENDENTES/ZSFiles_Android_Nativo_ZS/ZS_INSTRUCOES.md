# Instruções do projeto (a IA lê este arquivo a cada pedido)

## O que é este projeto
ZS Files: gerenciador de arquivos Android (Kotlin + Jetpack Compose) com editor de código, prévia de layout XML,
análise com IA e assistente de projeto. O código fica em android_source/app/src/main/java/com/zs/filemanager/.

## Regras
- Responda em português do Brasil, curto.
- Mudanças pequenas e focadas; não reescreva arquivos inteiros sem necessidade.
- Use só as dependências que já estão em android_source/app/build.gradle.kts, a menos que eu peça outra.
- Não coloque `/*` dentro de comentários (o Kotlin aninha comentários e isso já quebrou o build uma vez).
- Não mexa em build/, .gradle/ e zs_build_reports/. zs_native.json e project.zeproj são gerados pela engine.

## Como eu testo
- Compilo na ZS Engine (painel Android Nativo • Gradle). Se der erro, o log fica em android_source/zs_build_reports/logs/.
