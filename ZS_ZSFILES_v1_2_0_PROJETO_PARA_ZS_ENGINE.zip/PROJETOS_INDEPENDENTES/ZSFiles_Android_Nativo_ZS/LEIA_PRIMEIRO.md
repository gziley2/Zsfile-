# ZSFiles na ZS.ENGINE STUDIO (importação do app Android)

ZSFiles é o app Android (Kotlin + Jetpack Compose) de gerenciador de arquivos com editor de código,
prévia de layout XML e análise com IA (Gemini ou Claude). Aqui ele está importado como projeto ZS,
no mesmo formato de Finanças, Aura e ShadowQuest.

## Instalar
Extraia o ZIP SOBRE a pasta que contém `ZS_ENGINE_STUDIO_ALPHA_9_20` e `PROJETOS_INDEPENDENTES`.
Ele só cria a pasta `PROJETOS_INDEPENDENTES/ZSFiles_Android_Nativo_ZS`; nada da engine é alterado.

## Abrir
ZS.ENGINE > **Abrir** > **Selecionar pasta** > `PROJETOS_INDEPENDENTES/ZSFiles_Android_Nativo_ZS`.
(Ou **Abrir ZIP** com `ZS_ZSFILES_PROJETO_PARA_ZS_ENGINE.zip`; nesse caso a engine copia para uma pasta nova.)
O código fica em `android_source/` e é preservado sem alterações.

## Compilar o APK
Painel **Android Nativo • Gradle** > Diagnosticar > confirmar > Compilar.
Precisa de: JDK 17, Android SDK (plataforma 34 e build-tools) e internet no primeiro build
(o `gradlew` da engine baixa o Gradle 8.9; o Gradle baixa as dependências).
Depois instale no celular com o botão de instalação do painel (ADB) ou copie o APK.
No primeiro uso o app pede "acesso a todos os arquivos"; a chave do Gemini/Claude é configurada em ⚙ na tela de análise.

## O que foi verificado
- Importador oficial da engine (`zs_project_opener`): reconheceu como projeto Gradle e gerou `project.zeproj`.
- Diagnóstico `gradle_native.check`: **sem problemas** (AGP 8.5.2, Kotlin 2.0.21, Compose, Gradle 8.9, módulo `app`,
  launcher `.MainActivity`). Só faltava o Android SDK no ambiente de teste.
- Simulação da compilação (dry-run) montou: `gradlew :app:assembleDebug --no-daemon`.

## O que NÃO foi verificado
- Nenhum APK foi compilado e o código Kotlin ainda não foi compilado (nem aqui, nem na engine).
  Se o Gradle mostrar linhas `e: file:///...`, envie as primeiras.
- A ZS.ENGINE abre, edita e compila o projeto; ela não executa Kotlin/Compose no desktop.
  Para rodar o app, instale o APK no aparelho.

## Novidades da v0.6
- Visualizador hexadecimal (tocar num arquivo binário, ou selecionar > ⋮ > Abrir no hex).
- Extração de 7z, RAR (RAR4), TAR, TAR.GZ/BZ2/XZ, GZ, BZ2 e XZ, além de ZIP/APK/JAR.
- minSdk 26 e novas dependências (commons-compress, xz, junrar): o primeiro build baixa essas bibliotecas.
- Ainda sem compilação real: se o Gradle mostrar linhas `e: file:///...`, envie as primeiras.

## Novidades da v0.7
- Extrator de APK: menu ⋮ da tela inicial > "Extrator de APK" (lista os apps instalados e copia o APK/.apks para /ZSFiles_APKs).
- Permissão nova no manifest: QUERY_ALL_PACKAGES (necessária para listar todos os apps).

## Novidades da v0.8
- Análise com IA de pasta de projeto agora envia o código-fonte e os assets (lista, tipo/entropia dos binários e conteúdo dos de texto),
  com um resumo no topo do que foi incluído e do que ficou de fora. Limite: 350 mil caracteres (Gemini) ou 120 mil (Claude).

## Novidades da v0.9
- Decompilação de APK/DEX para smali (baksmali) e integração com a IA de engenharia reversa
  (botão "Decompilar e incluir código (smali)" na análise de um APK).
- Novas dependências (smali-dexlib2 e smali-baksmali, do Google Maven): o primeiro build baixa essas bibliotecas.
- Continua sem compilação real; se o Gradle mostrar linhas `e: file:///...`, envie as primeiras.

## Novidades da v1.0
- A decompilação agora decodifica `res/` (layouts, menus, drawables xml) com nomes de recursos resolvidos pelo `resources.arsc`,
  gera `res/values/` (strings, colors, dimens, integers, bools, ids) e abre os layouts decodificados na prévia de layout.
- Botão "Converter para Java (IA)" para arquivos `.smali` (no editor e no gerenciador).
- O parser do resources.arsc foi testado só com dados sintéticos (formatos denso, esparso e offset16); ainda não com um APK real.

## v1.0.1 (correção)
- Corrige o erro de compilação `Syntax error: Unclosed comment` em Analyzer.kt e LayoutPreview.kt: dois comentários continham `/*`,
  e o Kotlin aceita comentários aninhados. Os outros 27 erros do log eram consequência desses dois.
- Para aplicar: extraia o ZIP novamente sobre a pasta da engine (substitui android_source) ou troque só esses dois arquivos.

## v1.0.2
- Menu ⋮ da tela inicial ganhou "Configurar IA (chave da API)" e "Ajuda". "Novo arquivo" agora abre o arquivo no editor.

## v1.0.3
- Modelo padrão do Gemini agora é `gemini-flash-latest`; Configurar IA ganhou "Buscar modelos" (lista os modelos disponíveis para a sua chave).

## v1.1.0 (versão profissional)
- Navegação por abas (Arquivos, Editor, Ferramentas, Ajustes), tema claro/escuro, ícone do app, ícones Material, busca/ordenação/ocultos no gerenciador.
- Nova dependência: material-icons-extended (o primeiro build baixa e demora mais).
- IA: tentativas automáticas em erro 503/429 do Google.
- Sem compilação real ainda: se o Gradle mostrar erros, o log fica em android_source/zs_build_reports/logs/.

## v1.2.0 (Assistente de projeto com IA)
- Novo: **Assistente de projeto (IA)**. Abra por Ferramentas > Assistente de projeto, ou selecione uma PASTA no gerenciador > ⋮ > Assistente de projeto (IA).
  A IA (Gemini ou Claude, a mesma chave dos Ajustes) lê, busca, edita e cria arquivos direto na pasta do projeto, em vários passos, como um agente.
- Antes de mexer num arquivo, o app guarda uma cópia dele. Depois de cada pedido aparece a lista de arquivos alterados:
  toque para ver o diff linha a linha, **Reverter** um arquivo, **Desfazer tudo** ou **Aceitar tudo**.
- **Instruções do projeto**: ícone (i) cria/edita `ZS_INSTRUCOES.md` na pasta do projeto (formato da ZS Engine, regras, o que não mexer). A IA lê a cada pedido.
  Há um modelo pronto com o formato `zeproj-1` / `zscene-1`; complete com os tipos de entidade e regras do seu projeto.
- **Corrigir erro do log**: botão que acha o log mais recente (zs_build_reports/logs) e manda só os trechos de erro para a IA corrigir.
- **Planejar antes**: a IA só lê e devolve um plano; você aprova e ela executa.
- Conversa salva por projeto, anexar imagem (print de erro/tela), cancelar pedido em andamento.
- Segurança: JSON e XML que ficariam inválidos por causa de uma edição são recusados; código com chaves/parênteses desbalanceados gera aviso para a IA reconferir.
  A IA não apaga arquivos, não altera arquivos binários ou maiores que 1 MB, e ignora build/.git/.gradle/zs_build_reports.
- A chave de API agora é guardada criptografada (Android Keystore). Chaves antigas são convertidas na primeira leitura.
- Sem dependências novas. O código novo está em ProjectAgent.kt, AgentScreen.kt e SecureStore.kt.
- Continua sem compilação real: se o Gradle mostrar linhas `e: file:///...`, envie as primeiras (o log fica em android_source/zs_build_reports/logs/).
